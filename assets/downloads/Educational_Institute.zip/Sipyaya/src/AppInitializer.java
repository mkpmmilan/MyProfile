import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;

public class AppInitializer extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    double x,y=0;
    @Override
    public void start(Stage primaryStage) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("view/LoginForm.fxml"));

        root.setOnMousePressed(event -> {
            x=event.getSceneX();
            y=event.getSceneY();
        });

        root.setOnMouseDragged(event -> {
            primaryStage.setX(event.getScreenX() - x);
            primaryStage.setY(event.getScreenY() - y);
            primaryStage.setOpacity(0.2);
        });

        root.setOnDragDone(event -> {
            primaryStage.setOpacity(1.0f);
        });

        root.setOnMouseReleased(event -> {
            primaryStage.setOpacity(1.0f);
        });

        primaryStage.setScene(new Scene(root));
        primaryStage.getIcons().add(new Image("assets/logo.png"));
        primaryStage.initStyle(StageStyle.UNDECORATED);
        primaryStage.show();
    }
}
