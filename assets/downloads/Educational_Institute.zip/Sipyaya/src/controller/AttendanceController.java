package controller;

import Database.DbConnection;
import controller.interfaces.AttendanceService;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import model.Attendance;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class AttendanceController implements AttendanceService {

    @Override
    public boolean markAttendance(Attendance attendance) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("INSERT INTO `Student Attendance` VALUES(?,?,?,?,?,?,?)");
        stm.setObject(1, attendance.getStudentId());
        stm.setObject(2, attendance.getStudentName());
        stm.setObject(3, attendance.getGrade());
        stm.setObject(4, attendance.getTime());
        stm.setObject(5, attendance.getDate());
        stm.setObject(6, attendance.getAttendance());
        stm.setObject(7, attendance.getSubject());
        return stm.executeUpdate() > 0;
    }

    @Override
    public ArrayList<Attendance> getAttendances() throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM `Student Attendance`");
        ResultSet rst = stm.executeQuery();
        ArrayList<Attendance> attendances = new ArrayList<>();
        while (rst.next()) {
            attendances.add(new Attendance(rst.getString(1), rst.getString(2), rst.getInt(3), rst.getString(4), rst.getString(5), rst.getString(6), rst.getString(7)));
        }
        return attendances;
    }

    @Override
    public boolean deleteAttendance(String studentId, String studentName, String subject, String date, String time) throws SQLException, ClassNotFoundException {
        ButtonType yes = new ButtonType("Yes", ButtonBar.ButtonData.OK_DONE);
        ButtonType no = new ButtonType("No", ButtonBar.ButtonData.CANCEL_CLOSE);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure whether you want to delete this attendance raw?", yes, no);
        alert.setTitle("Confirmation Alert");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.orElse(no) == yes) {
            PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("DELETE FROM `Student Attendance` WHERE StudentId=? AND StudentName=? AND SubjectName=? AND Date=? AND Time=?");
            stm.setObject(1, studentId);
            stm.setObject(2, studentName);
            stm.setObject(3, subject);
            stm.setObject(4, date);
            stm.setObject(5, time);
            return stm.executeUpdate() > 0;
        }
        return false;
    }

    @Override
    public List<Attendance> searchAttendances(String newValue) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM `Student Attendance` WHERE StudentId LIKE '%" + newValue + "%' OR StudentName LIKE '%" + newValue + "%' OR grade LIKE '%" + newValue + "%' OR Time LIKE '%" + newValue + "%' OR Date LIKE '%" + newValue + "%' OR SubjectName LIKE '%" + newValue + "%'");
        ResultSet rst = stm.executeQuery();
        ArrayList<Attendance> attendances = new ArrayList<>();
        while (rst.next()) {
            attendances.add(new Attendance(rst.getString(1), rst.getString(2), rst.getInt(3), rst.getString(4), rst.getString(5), rst.getString(6), rst.getString(7)));
        }
        return attendances;
    }
}
