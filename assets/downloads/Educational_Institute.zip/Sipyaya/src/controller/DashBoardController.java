package controller;

import animatefx.animation.ZoomIn;
import animatefx.animation.ZoomInDown;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import model.StudentDetail;
import view.TM.StudentDetailsTM;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DashBoardController {

    public Pane panel1;
    public Pane panel2;
    public Pane panel3;
    public TableView<StudentDetailsTM> tblStudentDetails;
    public TableColumn colStudentId;
    public TableColumn colStudentName;
    public TableColumn colTeacherName;
    public TableColumn colSubjects;
    public TableColumn colGrade;
    public ComboBox<String> cmbTeachers;
    public Label lblStudents;
    public Label lblTeachers;
    public Label lblSubjects;

    public void initialize() {
        loadTeachers();
        loadStudentCount();
        loadTeacherCount();
        loadSubjectCount();
        try {
            loadStudentDetailsToTable(new StudentController().getAllStudentDetails());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        cmbTeachers.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            searchStudentDetails(newValue);
        });
        new ZoomIn(panel1).play();
        new ZoomIn(panel2).play();
        new ZoomIn(panel3).play();
        new ZoomIn(tblStudentDetails).play();
    }

    private void searchStudentDetails(String newValue) {
        try {
            List<StudentDetail> students = new StudentController().searchStudentDetails(newValue);
            ObservableList<StudentDetailsTM> obList = FXCollections.observableArrayList();
            students.forEach(e -> {
                obList.add(new StudentDetailsTM(e.getStudentId(), e.getStudentName(), e.getTeacherName(), e.getSubject(), e.getGrade()));
            });
            tblStudentDetails.setItems(obList);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void loadSubjectCount() {
        try {
            new SubjectController().getSubjectCount(lblSubjects);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void loadTeacherCount() {
        try {
            new TeacherController().getTeacherCount(lblTeachers);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void loadStudentCount() {
        try {
            new StudentController().getStudentCount(lblStudents);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void loadTeachers() {
        try {
            List<String> teacherNames = new TeacherController().getTeacherNames();
            cmbTeachers.getItems().addAll(teacherNames);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void loadStudentDetailsToTable(ArrayList<StudentDetail> allStudentDetails) {
        ObservableList<StudentDetailsTM> obList = FXCollections.observableArrayList();
        allStudentDetails.forEach(e -> {
            obList.add(new StudentDetailsTM(e.getStudentId(), e.getStudentName(), e.getTeacherName(), e.getSubject(), e.getGrade()));
        });
        tblStudentDetails.setItems(obList);
        initCols();
    }

    private void initCols() {
        colStudentId.setCellValueFactory(new PropertyValueFactory<>("studentId"));
        colStudentName.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        colTeacherName.setCellValueFactory(new PropertyValueFactory<>("teacherName"));
        colSubjects.setCellValueFactory(new PropertyValueFactory<>("subject"));
        colGrade.setCellValueFactory(new PropertyValueFactory<>("grade"));
    }

    public void refreshTableOnAction(ActionEvent actionEvent) {
        try {
            cmbTeachers.getSelectionModel().clearSelection();
            loadStudentDetailsToTable(new StudentController().getAllStudentDetails());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
