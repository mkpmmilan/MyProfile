package controller;

import Database.DbConnection;
import controller.interfaces.EmployeeService;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import model.Employee;
import model.EmployeeSalary;
import view.TM.EmployeeSalaryTM;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class EmployeeController implements EmployeeService {
    @Override
    public String setEmployeeId() throws SQLException, ClassNotFoundException {
        ResultSet rst = DbConnection.getInstance().getConnection().prepareStatement("SELECT EmployeeId FROM Employee ORDER BY EmployeeId DESC LIMIT 1").executeQuery();
        if (rst.next()) {
            int tempId = Integer.parseInt(rst.getString(1).split("-")[1]);
            tempId = tempId + 1;
            if (tempId <= 9) {
                return "E00-00" + tempId;
            } else if (tempId <= 99) {
                return "E00-0" + tempId;
            } else {
                return "E00-" + tempId;
            }
        } else {
            return "E00-001";
        }
    }

    @Override
    public boolean addEmployee(Employee employee) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("INSERT INTO Employee VALUES(?,?,?,?,?,?,?)");
        stm.setObject(1, employee.getEmployeeId());
        stm.setObject(2, employee.getEmployeeName());
        stm.setObject(3, employee.getEmployeeAddress());
        stm.setObject(4, employee.getJobRole());
        stm.setObject(5, employee.getGender());
        stm.setObject(6, employee.getDateOfBirth());
        stm.setObject(7, employee.getContact());
        return stm.executeUpdate() > 0;
    }

    @Override
    public ArrayList<Employee> getAllEmployees() throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Employee");
        ResultSet rst = stm.executeQuery();
        ArrayList<Employee> employees = new ArrayList<>();
        while (rst.next()) {
            employees.add(new Employee(rst.getString(1), rst.getString(2), rst.getString(4), rst.getString(3), rst.getString(7), rst.getString(5), rst.getString(6)));
        }
        return employees;
    }

    @Override
    public List<Employee> search(String newValue) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Employee WHERE EmployeeId LIKE '%" + newValue + "%' OR EmployeeName LIKE '%" + newValue + "%' OR EmployeeAddress LIKE '%" + newValue + "%' OR JobRole LIKE '%" + newValue + "%' OR DateOfBirth LIKE '%" + newValue + "%' OR Contact LIKE '%" + newValue + "%'");
        ResultSet rst = stm.executeQuery();
        ArrayList<Employee> employees = new ArrayList<>();
        while (rst.next()) {
            employees.add(new Employee(rst.getString(1), rst.getString(2), rst.getString(4), rst.getString(3), rst.getString(7), rst.getString(5), rst.getString(6)));
        }
        return employees;
    }

    @Override
    public Employee getEmployee(String employeeId) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Employee WHERE EmployeeId=?");
        stm.setObject(1, employeeId);
        ResultSet rst = stm.executeQuery();
        Employee employee = null;
        while (rst.next()) {
            employee = new Employee(rst.getString(1), rst.getString(2), rst.getString(4), rst.getString(3), rst.getString(7), rst.getString(5), rst.getString(6));
        }
        return employee;
    }

    @Override
    public boolean updateEmployee(Employee employee) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("UPDATE Employee SET EmployeeName=?, EmployeeAddress=?, JobRole=?, Gender=?, DateOfBirth=?, Contact=? WHERE EmployeeId=?");
        stm.setObject(1, employee.getEmployeeName());
        stm.setObject(2, employee.getEmployeeAddress());
        stm.setObject(3, employee.getJobRole());
        stm.setObject(4, employee.getGender());
        stm.setObject(5, employee.getDateOfBirth());
        stm.setObject(6, employee.getContact());
        stm.setObject(7, employee.getEmployeeId());
        return stm.executeUpdate() > 0;
    }

    @Override
    public boolean deleteEmployee(String employeeId) throws SQLException, ClassNotFoundException {
        ButtonType yes = new ButtonType("Yes", ButtonBar.ButtonData.OK_DONE);
        ButtonType no = new ButtonType("No", ButtonBar.ButtonData.CANCEL_CLOSE);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure whether you want to delete this employee?", yes, no);
        alert.setTitle("Confirmation Alert");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.orElse(no) == yes) {
            PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("DELETE FROM Employee WHERE EmployeeId=?");
            stm.setObject(1, employeeId);
            return stm.executeUpdate() > 0;
        }
        return false;
    }

    @Override
    public List<String> getEmployeeNames() throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Employee");
        ResultSet rst = stm.executeQuery();
        ArrayList<String> employeeNames = new ArrayList<>();
        while (rst.next()) {
            employeeNames.add(rst.getString(2));
        }
        return employeeNames;
    }

    @Override
    public void getJobRole(String newValue, TextField txtSubject) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT JobRole FROM Employee WHERE EmployeeName=?");
        stm.setObject(1, newValue);
        ResultSet rst = stm.executeQuery();
        while (rst.next()) {
            txtSubject.setText(rst.getString(1));
        }
    }

    @Override
    public String getJobRole(String newValue) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT JobRole FROM Employee WHERE EmployeeName=?");
        stm.setObject(1, newValue);
        ResultSet rst = stm.executeQuery();
        String jobRole = null;
        while (rst.next()) {
            jobRole = rst.getString(1);
        }
        return jobRole;
    }

    @Override
    public boolean addEmployeeSalary(EmployeeSalary employeeSalary) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("INSERT INTO `Employee Salary` VALUES(?,?,?,?,?,?,?,?,?,?)");
        stm.setObject(1, employeeSalary.getEmployeeName());
        stm.setObject(2, employeeSalary.getJobRole());
        stm.setObject(3, employeeSalary.getYear());
        stm.setObject(4, employeeSalary.getMonth());
        stm.setObject(5, employeeSalary.getDate());
        stm.setObject(6, employeeSalary.getWorkingDays());
        stm.setObject(7, employeeSalary.getSalaryPerDay());
        stm.setObject(8, employeeSalary.getAllowances());
        stm.setObject(9, employeeSalary.getDeductions());
        stm.setObject(10, employeeSalary.getNetSalary());
        return stm.executeUpdate() > 0;
    }

    @Override
    public ArrayList<EmployeeSalary> getAllEmployeeSalary() throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM `Employee Salary`");
        ResultSet rst = stm.executeQuery();
        ArrayList<EmployeeSalary> employeeSalaries = new ArrayList<>();
        while (rst.next()) {
            employeeSalaries.add(new EmployeeSalary(rst.getString(1), rst.getString(2), rst.getInt(3), rst.getString(4), rst.getString(5), rst.getInt(6), rst.getDouble(7), rst.getDouble(8), rst.getDouble(9), rst.getDouble(10)));
        }
        return employeeSalaries;
    }

    @Override
    public List<EmployeeSalary> searchEmployeeSalary(Integer year, String month, TextField txtEmployeeNetSalary) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM `Employee Salary` WHERE Year=? AND Month=?");
        stm.setObject(1, year);
        stm.setObject(2, month);
        ResultSet rst = stm.executeQuery();
        ArrayList<EmployeeSalary> employeeSalaries = new ArrayList<>();
        double netSalary = 0;
        while (rst.next()) {
            employeeSalaries.add(new EmployeeSalary(rst.getString(1), rst.getString(2), rst.getInt(3), rst.getString(4), rst.getString(5), rst.getInt(6), rst.getDouble(7), rst.getDouble(8), rst.getDouble(9), rst.getDouble(10)));
            netSalary = netSalary + rst.getDouble(10);
        }
        txtEmployeeNetSalary.setText(String.valueOf(netSalary));
        return employeeSalaries;
    }

    @Override
    public boolean deleteEmployeeSalary(EmployeeSalaryTM selectedItem) throws SQLException, ClassNotFoundException {
        ButtonType yes = new ButtonType("Yes", ButtonBar.ButtonData.OK_DONE);
        ButtonType no = new ButtonType("No", ButtonBar.ButtonData.CANCEL_CLOSE);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure whether you want to delete this employee salary?", yes, no);
        alert.setTitle("Confirmation Alert");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.orElse(no) == yes) {
            PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("DELETE FROM `Employee Salary` WHERE EmployeeName=? AND Month=? AND Date=?");
            stm.setObject(1, selectedItem.getEmployeeName());
            stm.setObject(2, selectedItem.getMonth());
            stm.setObject(3, selectedItem.getDate());
            return stm.executeUpdate() > 0;
        }
        return false;
    }

    @Override
    public double getTotalSalary(int year, String month) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT SUM(NetSalary) FROM `Employee Salary` WHERE Year=? && Month=?");
        stm.setObject(1, year);
        stm.setObject(2, month);
        ResultSet rst = stm.executeQuery();
        double employeeSalary = 0;
        while (rst.next()) {
            employeeSalary = rst.getDouble(1);
        }
        return employeeSalary;
    }
    @Override
    public double getAnnualEmployeeSalary(int year) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT SUM(NetSalary) FROM `Employee Salary` WHERE Year=?");
        stm.setObject(1, year);
        ResultSet rst = stm.executeQuery();
        double employeeSalary = 0;
        while (rst.next()) {
            employeeSalary = rst.getDouble(1);
        }
        return employeeSalary;
    }

    @Override
    public double getSumOfSalary(String fDate, String tDate) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT SUM(NetSalary) FROM `Employee Salary` WHERE Date BETWEEN ? AND ?");
        stm.setObject(1, fDate);
        stm.setObject(2, tDate);
        ResultSet rst = stm.executeQuery();
        double totalSalary = 0;
        while (rst.next()) {
            totalSalary = rst.getDouble(1);
        }
        return totalSalary;
    }
}
