package controller;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.text.SimpleDateFormat;
import java.util.Date;

public class EmployeeDetailsFormController {

    public TextField txtEmployeeId;
    public TextField txtEmployeeName;
    public TextField txtAddress;
    public TextField txtJobRole;
    public TextField txtContact;
    public TextField txtGender;
    public TextField txtDateOfBirth;
    public Label lblDate;

    public void initialize() {
        loadDate();
    }

    private void loadDate() {
        Date date = new Date();
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
        lblDate.setText(f.format(date));
    }
}
