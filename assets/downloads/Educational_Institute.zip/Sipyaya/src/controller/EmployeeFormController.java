package controller;

import Notification.NotificationBuilder;
import Validation.ValidationUtil;
import animatefx.animation.ZoomIn;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.Employee;
import org.controlsfx.control.Notifications;
import view.TM.EmployeeTM;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.regex.Pattern;

public class EmployeeFormController {

    public TableView<EmployeeTM> tblEmployees;
    public JFXTextField txtEmployeeId;
    public JFXTextField txtEmployeeName;
    public JFXTextField txtJobRole;
    public JFXTextField txtEmployeeAddress;
    public JFXTextField txtContact;
    public JFXComboBox<String> cmbGender;
    public JFXDatePicker dateOfBirth;
    public JFXButton btnAddEmployee;
    public JFXTextField txtSearchEmployee;
    public TableColumn colEmployeeId;
    public TableColumn colName;
    public TableColumn colAddress;
    public TableColumn colJobRole;
    public TableColumn colContact;
    public TableColumn colDateOfBirth;

    LinkedHashMap<JFXTextField, Pattern> map = new LinkedHashMap<>();
    Pattern employeeNamePattern = Pattern.compile("^[A-z ]{3,}$");
    Pattern jobRolePattern = Pattern.compile("^[A-z ]{3,}$");
    Pattern addressPattern = Pattern.compile("^[A-z0-9, ]{3,}$");
    Pattern contactPattern = Pattern.compile("^(07)[0-9](-)[0-9]{7}$");


    public void initialize() {
        btnAddEmployee.setDisable(true);
        try {
            loadEmployeeDataToTable(new EmployeeController().getAllEmployees());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        loadEmployeeId();
        storeValidations();
        cmbGender.getItems().addAll("Male", "Female");
        txtSearchEmployee.textProperty().addListener((observable, oldValue, newValue) -> {
            search(newValue);
        });
        new ZoomIn(tblEmployees).play();
    }

    private void search(String newValue) {
        try {
            List<Employee> employees = new EmployeeController().search(newValue);
            ObservableList<EmployeeTM> obList = FXCollections.observableArrayList();
            employees.forEach(e -> {
                obList.add(new EmployeeTM(e.getEmployeeId(), e.getEmployeeName(), e.getEmployeeAddress(), e.getJobRole(), e.getContact(), e.getDateOfBirth()));
            });
            tblEmployees.setItems(obList);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void loadEmployeeDataToTable(ArrayList<Employee> allEmployees) {
        ObservableList<EmployeeTM> obList = FXCollections.observableArrayList();
        allEmployees.forEach(e -> {
            obList.add(new EmployeeTM(e.getEmployeeId(), e.getEmployeeName(), e.getEmployeeAddress(), e.getJobRole(), e.getContact(), e.getDateOfBirth()));
        });
        tblEmployees.setItems(obList);
        initCols();
    }

    private void initCols() {
        colEmployeeId.setCellValueFactory(new PropertyValueFactory<>("employeeId"));
        colName.setCellValueFactory(new PropertyValueFactory<>("employeeName"));
        colAddress.setCellValueFactory(new PropertyValueFactory<>("employeeAddress"));
        colJobRole.setCellValueFactory(new PropertyValueFactory<>("jobRole"));
        colContact.setCellValueFactory(new PropertyValueFactory<>("contact"));
        colDateOfBirth.setCellValueFactory(new PropertyValueFactory<>("dateOfBirth"));
    }

    private void loadEmployeeId() {
        try {
            txtEmployeeId.setText(new EmployeeController().setEmployeeId());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void storeValidations() {
        map.put(txtEmployeeName, employeeNamePattern);
        map.put(txtJobRole, jobRolePattern);
        map.put(txtEmployeeAddress, addressPattern);
        map.put(txtContact, contactPattern);
    }

    public void textFieldValidationOnAction(KeyEvent keyEvent) {
        Object response = ValidationUtil.validateJFXTextField(map, btnAddEmployee);
        if (keyEvent.getCode() == KeyCode.ENTER) {
            if (response instanceof TextField) {
                TextField errorText = (TextField) response;
                errorText.requestFocus();
            } else if (response instanceof Boolean) {
                Notifications confirmation = NotificationBuilder.notifyMassage("CONFIRMATION", "All the text fields are filled successfully.");
                confirmation.showConfirm();
            }
        }
    }

    public void addEmployeeDetailsOnAction(MouseEvent mouseEvent) {
        if (!cmbGender.getSelectionModel().isEmpty()) {
            if (dateOfBirth.getValue() != null) {
                Employee employee = new Employee(txtEmployeeId.getText(), txtEmployeeName.getText(), txtJobRole.getText(), txtEmployeeAddress.getText(), txtContact.getText(), cmbGender.getSelectionModel().getSelectedItem(), String.valueOf(dateOfBirth.getValue()));
                try {
                    if (new EmployeeController().addEmployee(employee)) {
                        Notifications information = NotificationBuilder.notifyMassage("CONFIRMATION", "Employee details saved successfully");
                        information.showInformation();
                        loadEmployeeId();
                        loadEmployeeDataToTable(new EmployeeController().getAllEmployees());
                        btnAddEmployee.setDisable(true);
                        txtEmployeeName.clear();
                        txtEmployeeAddress.clear();
                        txtJobRole.clear();
                        txtContact.clear();
                        dateOfBirth.getEditor().clear();
                        cmbGender.getSelectionModel().clearSelection();
                    } else {
                        Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Try again");
                        warning.showWarning();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            } else {
                Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please select date of birth");
                warning.showWarning();
            }
        } else {
            Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please select gender");
            warning.showWarning();
        }
    }

    public void clearTextFieldsOnAction(MouseEvent mouseEvent) {
        txtEmployeeName.clear();
        txtEmployeeAddress.clear();
        txtContact.clear();
        txtJobRole.clear();
        dateOfBirth.getEditor().clear();
        cmbGender.getSelectionModel().clearSelection();
    }

    public void viewEmployeeDetailsFormOnAction(ActionEvent actionEvent) {
        EmployeeTM selectedItem = tblEmployees.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            Notifications error = NotificationBuilder.notifyMassage("ERROR", "No Employee raw selected.");
            error.showError();
        } else {
            try {
                Employee employee = new EmployeeController().getEmployee(selectedItem.getEmployeeId());
                FXMLLoader loader = new FXMLLoader(this.getClass().getResource("../view/EmployeeDetailsForm.fxml"));
                Parent parent = loader.load();
                EmployeeDetailsFormController controller = loader.getController();
                controller.txtEmployeeId.setText(employee.getEmployeeId());
                controller.txtEmployeeName.setText(employee.getEmployeeName());
                controller.txtContact.setText(employee.getContact());
                controller.txtAddress.setText(employee.getEmployeeAddress());
                controller.txtGender.setText(employee.getGender());
                controller.txtDateOfBirth.setText(employee.getDateOfBirth());
                controller.txtJobRole.setText(employee.getJobRole());
                Stage stage = new Stage(StageStyle.DECORATED);
                stage.setScene(new Scene(parent));
                stage.getIcons().add(new Image("assets/logo.png"));
                stage.setTitle("Employee Details Form");
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.setResizable(false);
                stage.show();
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void refreshTableOnAction(ActionEvent actionEvent) {
        try {
            loadEmployeeDataToTable(new EmployeeController().getAllEmployees());
            txtSearchEmployee.clear();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void updateEmployeeOnAction(ActionEvent actionEvent) {
        EmployeeTM selectedItem = tblEmployees.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            Notifications error = NotificationBuilder.notifyMassage("ERROR", "No Employee raw selected.");
            error.showError();
        } else {
            try {
                Employee employee = new EmployeeController().getEmployee(selectedItem.getEmployeeId());
                FXMLLoader loader = new FXMLLoader(this.getClass().getResource("../view/UpdateEmployeeForm.fxml"));
                Parent parent = loader.load();
                UpdateEmployeeFormController controller = loader.getController();
                controller.txtEmployeeId.setText(employee.getEmployeeId());
                controller.txtName.setText(employee.getEmployeeName());
                controller.txtJobRole.setText(employee.getJobRole());
                controller.txtAddress.setText(employee.getEmployeeAddress());
                controller.txtContact.setText(employee.getContact());
                controller.dateOfBirth.setValue(LocalDate.parse(employee.getDateOfBirth()));
                controller.cmbGender.setValue(employee.getGender());
                Stage stage = new Stage(StageStyle.DECORATED);
                stage.setScene(new Scene(parent));
                stage.getIcons().add(new Image("assets/logo.png"));
                stage.setTitle("Update Employee Form");
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.setResizable(false);
                stage.show();

                stage.setOnHiding((e) -> {
                    try {
                        loadEmployeeDataToTable(new EmployeeController().getAllEmployees());
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    } catch (ClassNotFoundException ex) {
                        ex.printStackTrace();
                    }
                });
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void deleteEmployeeOnAction(ActionEvent actionEvent) {
        EmployeeTM selectedItem = tblEmployees.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            Notifications error = NotificationBuilder.notifyMassage("ERROR", "No Employee raw selected.");
            error.showError();
        } else {
            try {
                if (new EmployeeController().deleteEmployee(selectedItem.getEmployeeId())) {
                    Notifications information = NotificationBuilder.notifyMassage("CONFIRMATION", "Employee details deleted successfully");
                    information.showInformation();
                    loadEmployeeId();
                    loadEmployeeDataToTable(new EmployeeController().getAllEmployees());
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
}
