package controller;

import Database.DbConnection;
import controller.interfaces.ExpensesService;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import model.Expense;
import view.TM.ExpenseTM;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ExpensesController implements ExpensesService {

    @Override
    public boolean addExpenses(Expense expense) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("INSERT INTO Expenses VALUES(?,?,?)");
        stm.setObject(1, expense.getDate());
        stm.setObject(2, expense.getDescription());
        stm.setObject(3, expense.getCash());
        return stm.executeUpdate() > 0;
    }

    @Override
    public ArrayList<Expense> getAllExpenses() throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Expenses");
        ResultSet rst = stm.executeQuery();
        ArrayList<Expense> expenses = new ArrayList<>();
        while (rst.next()) {
            expenses.add(new Expense(rst.getString(1), rst.getString(2), rst.getDouble(3)));
        }
        return expenses;
    }

    @Override
    public List<Expense> getAllExpensesBySearch(LocalDate fromDate, LocalDate toDate, TextField txtTotalExpenses) throws SQLException, ClassNotFoundException {
        String fDate = String.valueOf(fromDate);
        String tDate = String.valueOf(toDate);
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Expenses WHERE Date BETWEEN '" + fDate + "' AND '" + tDate + "'");
        ResultSet rst = stm.executeQuery();
        ArrayList<Expense> expenses = new ArrayList<>();
        double total = 0;
        while (rst.next()) {
            expenses.add(new Expense(rst.getString(1), rst.getString(2), rst.getDouble(3)));
            total = total + rst.getDouble(3);
        }
        txtTotalExpenses.setText(String.valueOf(total));
        return expenses;
    }

    @Override
    public boolean deleteExpense(ExpenseTM selectedItem) throws SQLException, ClassNotFoundException {
        ButtonType yes = new ButtonType("Yes", ButtonBar.ButtonData.OK_DONE);
        ButtonType no = new ButtonType("No", ButtonBar.ButtonData.CANCEL_CLOSE);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure whether you want to delete this raw?", yes, no);
        alert.setTitle("Confirmation Alert");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.orElse(no) == yes) {
            PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("DELETE FROM Expenses WHERE Date=? AND Description=? AND Cash=?");
            stm.setObject(1, selectedItem.getDate());
            stm.setObject(2, selectedItem.getDescription());
            stm.setObject(3, selectedItem.getCash());
            return stm.executeUpdate() > 0;
        }
        return false;

    }

    @Override
    public double getAllCash(String day) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT SUM(Cash) FROM Expenses WHERE Date=?");
        stm.setObject(1, day);
        double expenses = 0;
        ResultSet rst = stm.executeQuery();
        while (rst.next()) {
            expenses = rst.getDouble(1);
        }
        return expenses;
    }

    @Override
    public double getExpenses(int year, String month) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT SUM(Cash) FROM Expenses WHERE YEAR(Date)=? && MONTHNAME(Date)=?");
        stm.setObject(1, year);
        stm.setObject(2, month);
        ResultSet rst = stm.executeQuery();
        double expenses = 0;
        while (rst.next()) {
            expenses = rst.getDouble(1);
        }
        return expenses;
    }
    @Override
    public double getAnnualExpenses(int year) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT SUM(Cash) FROM Expenses WHERE YEAR(Date)=?");
        stm.setObject(1, year);
        ResultSet rst = stm.executeQuery();
        double expenses = 0;
        while (rst.next()) {
            expenses = rst.getDouble(1);
        }
        return expenses;
    }

    @Override
    public double getTotalExpenses(String fDate, String tDate) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT SUM(Cash) FROM Expenses WHERE Date BETWEEN ? AND ?");
        stm.setObject(1, fDate);
        stm.setObject(2, tDate);
        ResultSet rst = stm.executeQuery();
        double totalExpenses = 0;
        while (rst.next()) {
            totalExpenses = rst.getDouble(1);
        }
        return totalExpenses;
    }
}
