package controller;

import Notification.NotificationBuilder;
import Validation.ValidationUtil;
import animatefx.animation.ZoomIn;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import model.Expense;
import org.controlsfx.control.Notifications;
import view.TM.ExpenseTM;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.regex.Pattern;

public class ExpensesFormController {
    public TableView<ExpenseTM> tblExpenses;
    public JFXDatePicker dataOfExpense;
    public JFXTextField txtDescription;
    public TextField txtCash;
    public TableColumn colDate;
    public TableColumn colDescription;
    public TableColumn colCash;
    public JFXDatePicker FromDate;
    public JFXDatePicker ToDate;
    public TextField txtTotalExpenses;

    LinkedHashMap<JFXTextField, Pattern> jfxMap = new LinkedHashMap<>();
    LinkedHashMap<TextField, Pattern> textMap = new LinkedHashMap<>();
    Pattern descriptionPattern = Pattern.compile("^[A-z0-9 &,]{3,}$");
    Pattern cashPattern = Pattern.compile("^[1-9][0-9]*([.][0-9]{2})?$");

    public void initialize() {
        storeValidation();
        try {
            loadExpensesToTable(new ExpensesController().getAllExpenses());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        new ZoomIn(tblExpenses).play();
    }

    private void loadExpensesToTable(ArrayList<Expense> allExpenses) {
        ObservableList<ExpenseTM> obList = FXCollections.observableArrayList();
        allExpenses.forEach(e -> {
            obList.add(new ExpenseTM(e.getDate(), e.getDescription(), e.getCash()));
        });
        tblExpenses.setItems(obList);
        initCols();
    }

    private void initCols() {
        colDate.setCellValueFactory(new PropertyValueFactory<>("date"));
        colDescription.setCellValueFactory(new PropertyValueFactory<>("description"));
        colCash.setCellValueFactory(new PropertyValueFactory<>("cash"));
    }

    private void storeValidation() {
        jfxMap.put(txtDescription, descriptionPattern);
        textMap.put(txtCash, cashPattern);
    }

    public void searchOnAction(ActionEvent actionEvent) {
        if (FromDate.getValue() != null && ToDate.getValue() != null) {
            try {
                List<Expense> expenses = new ExpensesController().getAllExpensesBySearch(FromDate.getValue(), ToDate.getValue(), txtTotalExpenses);
                ObservableList<ExpenseTM> obList = FXCollections.observableArrayList();
                expenses.forEach(e -> {
                    obList.add(new ExpenseTM(e.getDate(), e.getDescription(), e.getCash()));
                });
                tblExpenses.setItems(obList);
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    public void addExpensesOnAction(MouseEvent mouseEvent) {
        if (dataOfExpense.getValue() != null && !txtCash.getText().isEmpty() && !txtDescription.getText().isEmpty()) {
            Expense expense = new Expense(String.valueOf(dataOfExpense.getValue()), txtDescription.getText(), Double.parseDouble(txtCash.getText()));
            try {
                if (new ExpensesController().addExpenses(expense)) {
                    Notifications information = NotificationBuilder.notifyMassage("INFORMATION", "Expense add successfully");
                    information.showInformation();
                    dataOfExpense.setValue(null);
                    txtDescription.clear();
                    txtCash.clear();
                    loadExpensesToTable(new ExpensesController().getAllExpenses());
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        } else {
            Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please fill all the fields");
            warning.showWarning();
        }
    }

    public void clearFieldsOnAction(MouseEvent mouseEvent) {
        dataOfExpense.setValue(null);
        txtCash.clear();
        txtDescription.clear();
    }

    public void cashFieldValidationOnAction(KeyEvent keyEvent) {
        Object response = ValidationUtil.validateTextField(textMap);
        if (keyEvent.getCode() == KeyCode.ENTER) {
            if (response instanceof TextField) {
                TextField errorText = (TextField) response;
                errorText.requestFocus();
            } else if (response instanceof Boolean) {

            }
        }
    }

    public void descriptionFieldVaalidationOnAction(KeyEvent keyEvent) {
        Object response = ValidationUtil.validateJFXTextField(jfxMap);
        if (keyEvent.getCode() == KeyCode.ENTER) {
            if (response instanceof TextField) {
                TextField errorText = (TextField) response;
                errorText.requestFocus();
            } else if (response instanceof Boolean) {
                txtCash.requestFocus();
            }
        }
    }

    public void refreshOnAction(ActionEvent actionEvent) {
        try {
            loadExpensesToTable(new ExpensesController().getAllExpenses());
            FromDate.setValue(null);
            ToDate.setValue(null);
            txtTotalExpenses.clear();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void deleteOnAction(ActionEvent actionEvent) {
        ExpenseTM selectedItem = tblExpenses.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            Notifications warning = NotificationBuilder.notifyMassage("WARNING", "No data selected");
            warning.showWarning();
        } else {
            try {
                if (new ExpensesController().deleteExpense(selectedItem)) {
                    Notifications information = NotificationBuilder.notifyMassage("INFORMATION", "Deleted Successfully");
                    information.showInformation();
                    loadExpensesToTable(new ExpensesController().getAllExpenses());
                    FromDate.setValue(null);
                    ToDate.setValue(null);
                    txtTotalExpenses.clear();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
}
