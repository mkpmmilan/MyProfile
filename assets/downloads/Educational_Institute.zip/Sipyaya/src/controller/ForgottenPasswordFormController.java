package controller;

import Notification.NotificationBuilder;
import Validation.ValidationUtil;
import com.jfoenix.controls.JFXButton;
import javafx.event.ActionEvent;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import model.User;
import org.controlsfx.control.Notifications;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.regex.Pattern;

public class ForgottenPasswordFormController {
    public TextField txtUserName;
    public TextField txtFirstName;
    public TextField txtLastName;
    public TextField txtUserType;
    public JFXButton btnUpdate;
    public PasswordField txtPassword;
    public PasswordField txtConfirmPassword;

    LinkedHashMap<TextField, Pattern> map = new LinkedHashMap<>();
    Pattern userNamePattern = Pattern.compile("^[A-z0-9]{6,10}$");
    Pattern passwordPattern = Pattern.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{8,}$");
    Pattern confirmPasswordPattern = Pattern.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{8,}$");

    public void initialize() {
        btnUpdate.setDisable(true);
        storeValidation();
    }

    private void storeValidation() {
        map.put(txtUserName, userNamePattern);
        map.put(txtPassword, passwordPattern);
        map.put(txtConfirmPassword, confirmPasswordPattern);
    }

    public void textFieldValidationOnAction(KeyEvent keyEvent) {
        Object response = ValidationUtil.validateTextField(map, btnUpdate);
        if (keyEvent.getCode() == KeyCode.ENTER) {
            if (response instanceof TextField) {
                TextField errorText = (TextField) response;
                errorText.requestFocus();
            } else if (response instanceof Boolean) {

            }
        }
    }

    public void searchUserDetails(ActionEvent actionEvent) {
        if (!txtUserName.getText().isEmpty()) {
            try {
                User user = new UserController().getUser(txtUserName.getText());
                txtFirstName.setText(user.getFirstName());
                txtLastName.setText(user.getLastName());
                txtUserType.setText(user.getUserType());
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        } else {
            Notifications warning = NotificationBuilder.notifyMassage("WARNING", "First enter your username");
            warning.showWarning();
        }
    }

    public void updatePasswordOnAction(ActionEvent actionEvent) {
        if (txtPassword.getText().equals(txtConfirmPassword.getText())) {
            User user = new User(txtFirstName.getText(), txtLastName.getText(), txtUserName.getText(), txtPassword.getText(), txtUserType.getText());
            try {
                if (new UserController().updatePassword(user)) {
                    Notifications information = NotificationBuilder.notifyMassage("INFORMATION", "Password updated successfully");
                    information.showInformation();
                    txtUserName.clear();
                    txtPassword.clear();
                    txtUserType.clear();
                    txtLastName.clear();
                    txtFirstName.clear();
                    txtConfirmPassword.clear();
                    btnUpdate.setDisable(true);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        } else {
            Notifications error = NotificationBuilder.notifyMassage("ERROR", "Password is not matched,Please try again");
            error.showError();
        }
    }
}
