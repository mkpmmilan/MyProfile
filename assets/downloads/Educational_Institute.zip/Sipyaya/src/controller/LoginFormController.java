package controller;

import Database.DbConnection;
import Notification.NotificationBuilder;
import Validation.ValidationUtil;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import org.controlsfx.control.Notifications;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.regex.Pattern;

public class LoginFormController {

    public AnchorPane loginFormContext;
    public Label openSignupForm;
    public JFXButton btnLoginUser;
    public JFXComboBox<String> cmbUserType;
    public CheckBox cboxShowPassword;
    public TextField txtShowPassword;
    public PasswordField txtPassword;
    public TextField txtUsername;

    LinkedHashMap<TextField, Pattern> map = new LinkedHashMap<>();
    Pattern usernamePattern = Pattern.compile("^[A-z0-9]{6,10}$");
    Pattern passwordPattern = Pattern.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{8,}$");

    public void initialize() {
        storeValidation();
        txtShowPassword.setDisable(true);
        cmbUserType.getItems().addAll("System User", "Admin");
        btnLoginUser.setDisable(true);
        cboxShowPassword.selectedProperty().addListener((observable, oldValue, newValue) -> {
            if (cboxShowPassword.isSelected()) {
                txtShowPassword.setText(txtPassword.getText());
                txtPassword.setDisable(true);
                txtPassword.setVisible(false);
                txtShowPassword.setDisable(false);
            } else {
                txtPassword.setText(txtShowPassword.getText());
                txtPassword.setVisible(true);
                txtPassword.setDisable(false);
                txtShowPassword.setDisable(true);
            }
        });
        try {
            ResultSet rst = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM `User detail`").executeQuery();
            while (rst.next()) {
                if (rst.getString(5).equalsIgnoreCase("Admin")) {
                    openSignupForm.setDisable(true);
                    return;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void storeValidation() {
        map.put(txtUsername, usernamePattern);
        map.put(txtPassword, passwordPattern);
    }

    public void btnExitOnAction(ActionEvent actionEvent) {
        System.exit(0);
    }

    public void openSignUpForm(MouseEvent mouseEvent) throws IOException {
        URL resource = getClass().getResource("../view/SignUpForm.fxml");
        Parent load = FXMLLoader.load(resource);
        loginFormContext.getChildren().clear();
        loginFormContext.getChildren().add(load);
    }

    public void openDashBoardOnAction(ActionEvent actionEvent) throws IOException, SQLException, ClassNotFoundException {
        String uType = cmbUserType.getSelectionModel().getSelectedItem();
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM `User detail` WHERE userType=?");
        stm.setObject(1, uType);
        ResultSet rst = stm.executeQuery();
        if (!cmbUserType.getSelectionModel().isEmpty()) {
            while (rst.next()) {
                if (cmbUserType.getSelectionModel().getSelectedItem().equalsIgnoreCase("System User")) {
                    if (rst.getString(5).equals(cmbUserType.getSelectionModel().getSelectedItem())) {
                        if (txtPassword.getText().equals(rst.getString(4)) && txtUsername.getText().equals(rst.getString(3))) {

                            Stage stg = (Stage) loginFormContext.getScene().getWindow();
                            stg.close();
                            FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/MainForm.fxml"));
                            Parent parent = loader.load();
                            MainFormController controller = loader.getController();
                            controller.btnEmployee.setDisable(true);
                            controller.btnExpenses.setDisable(true);
                            controller.btnSettings.setDisable(true);
                            controller.btnSalaryManagement.setDisable(true);
                            controller.lblUsertype.setText("System User");
                            Scene scene = new Scene(parent);
                            Stage stage = new Stage();
                            stage.getIcons().add(new Image("assets/logo.png"));
                            stage.initStyle(StageStyle.UNDECORATED);
                            stage.setScene(scene);
                            stage.show();
                            Notifications information = NotificationBuilder.notifyMassage("CONFIRMATION", "Log in successful");
                            information.showInformation();

                            return;
                        }
                    }
                }

                if (cmbUserType.getSelectionModel().getSelectedItem().equalsIgnoreCase("Admin")) {
                    if (rst.getString(5).equals(cmbUserType.getSelectionModel().getSelectedItem())) {
                        if (txtPassword.getText().equals(rst.getString(4)) && txtUsername.getText().equals(rst.getString(3))) {

                            Stage stg = (Stage) loginFormContext.getScene().getWindow();
                            stg.close();
                            FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/MainForm.fxml"));
                            Parent parent = loader.load();
                            MainFormController controller = loader.getController();
                            controller.btnStudentAttendance.setDisable(true);
                            controller.btnStudentMarks.setDisable(true);
                            controller.btnStudents.setDisable(true);
                            controller.btnSubjects.setDisable(true);
                            controller.btnTeachers.setDisable(true);
                            controller.btnTimeTable.setDisable(true);
                            controller.lblUsertype.setText("Admin");
                            Scene scene = new Scene(parent);
                            Stage stage = new Stage();
                            stage.getIcons().add(new Image("assets/logo.png"));
                            stage.initStyle(StageStyle.UNDECORATED);
                            stage.setScene(scene);
                            stage.show();
                            Notifications information = NotificationBuilder.notifyMassage("CONFIRMATION", "Log in successful");
                            information.showInformation();

                            return;
                        }
                    }
                }

            }
            Notifications error = NotificationBuilder.notifyMassage("ERROR", "Username,Password or user type is not matched.Please try again");
            error.showError();
        } else {
            Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please select a user type");
            warning.showWarning();
        }
    }

    public void textFieldValidationOnAction(KeyEvent keyEvent) {
        Object response = ValidationUtil.validateTextField(map, btnLoginUser);
        if (keyEvent.getCode() == KeyCode.ENTER) {
            if (response instanceof TextField) {
                TextField errorText = (TextField) response;
                errorText.requestFocus();
            } else if (response instanceof Boolean) {
                Notifications confirmation = NotificationBuilder.notifyMassage("CONFIRMATION", "All the text fields are filled successfully.");
                confirmation.showConfirm();
            }
        }
    }

    public void openForgotPasswordForm(MouseEvent mouseEvent) throws IOException {
        Scene scene = new Scene(FXMLLoader.load(getClass().getResource("../view/ForgottenPasswordForm.fxml")));
        Stage stage = new Stage(StageStyle.DECORATED);
        stage.getIcons().add(new Image("assets/logo.png"));
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setResizable(false);
        stage.setTitle("Update Password");
        stage.setScene(scene);
        stage.show();
    }
}
