package controller;

import animatefx.animation.*;
import com.jfoenix.controls.JFXButton;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.PauseTransition;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import model.StudentDetail;
import view.TM.StudentDetailsTM;
import view.TM.StudentTM;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainFormController {

    public Pane panel1;
    public Pane panel2;
    public Pane panel3;
    public StackPane mainFormStackForm;
    public Label lblUsertype;
    public JFXButton btnEmployee;
    public JFXButton btnSalaryManagement;
    public JFXButton btnExpenses;
    public JFXButton btnSettings;
    public JFXButton btnStudents;
    public JFXButton btnSubjects;
    public JFXButton btnTeachers;
    public JFXButton btnPayments;
    public JFXButton btnStudentAttendance;
    public JFXButton btnStudentMarks;
    public JFXButton btnTimeTable;
    public JFXButton btnReports;
    public Label lblDate;
    public Label lblTime;
    public TableView<StudentDetailsTM> tblStudentDetails;
    public Label lblStudents;
    public Label lblTeachers;
    public Label lblSubjects;
    public TableColumn colStudentId;
    public TableColumn clStudentName;
    public TableColumn colTeacherName;
    public TableColumn colSubjects;
    public TableColumn colGrade;
    public ComboBox<String> cmbTeachers;
    public JFXButton btnDashboard;


    public void initialize() {
        btnDashboard.setStyle("-fx-background-color: #2980b9");
        loadDateAndTime();
        loadStudentCount();
        loadTeacherCount();
        loadSubjectCount();
        loadTeachers();
        try {
            loadStudentDetailsToTable(new StudentController().getAllStudentDetails());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        cmbTeachers.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            searchStudentDetails(newValue);
        });
        new ZoomIn(panel1).play();
        new ZoomIn(panel2).play();
        new ZoomIn(panel3).play();
        new ZoomIn(tblStudentDetails).play();
    }

    private void searchStudentDetails(String newValue) {
        try {
            List<StudentDetail> students = new StudentController().searchStudentDetails(newValue);
            ObservableList<StudentDetailsTM> obList = FXCollections.observableArrayList();
            students.forEach(e -> {
                obList.add(new StudentDetailsTM(e.getStudentId(), e.getStudentName(), e.getTeacherName(), e.getSubject(), e.getGrade()));
            });
            tblStudentDetails.setItems(obList);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void loadSubjectCount() {
        try {
            new SubjectController().getSubjectCount(lblSubjects);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void loadTeacherCount() {
        try {
            new TeacherController().getTeacherCount(lblTeachers);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void loadStudentCount() {
        try {
            new StudentController().getStudentCount(lblStudents);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void loadTeachers() {
        try {
            List<String> teacherNames = new TeacherController().getTeacherNames();
            cmbTeachers.getItems().addAll(teacherNames);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void loadStudentDetailsToTable(ArrayList<StudentDetail> allStudents) {
        ObservableList<StudentDetailsTM> obList = FXCollections.observableArrayList();
        allStudents.forEach(e -> {
            obList.add(new StudentDetailsTM(e.getStudentId(), e.getStudentName(), e.getTeacherName(), e.getSubject(), e.getGrade()));
        });
        tblStudentDetails.setItems(obList);
        initCols();
    }

    private void initCols() {
        colStudentId.setCellValueFactory(new PropertyValueFactory<>("studentId"));
        clStudentName.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        colTeacherName.setCellValueFactory(new PropertyValueFactory<>("teacherName"));
        colSubjects.setCellValueFactory(new PropertyValueFactory<>("subject"));
        colGrade.setCellValueFactory(new PropertyValueFactory<>("grade"));
    }

    private void loadDateAndTime() {
        Date date = new Date();
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
        lblDate.setText(f.format(date));

        Timeline time = new Timeline(new KeyFrame(Duration.ZERO, e -> {
            LocalTime currentTime = LocalTime.now();
            lblTime.setText(
                    currentTime.getHour() + ":" + currentTime.getMinute() + ":" + currentTime.getSecond()
            );
        }),
                new KeyFrame(Duration.seconds(1))
        );
        time.setCycleCount(Animation.INDEFINITE);
        time.play();
    }

    public void closeOnAction(MouseEvent mouseEvent) {
        System.exit(0);
    }

    public void maximizeAndRestoreDownOnAction(MouseEvent mouseEvent) {
        Stage s = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        if (s.isMaximized()) {
            s.setMaximized(false);
        } else {
            s.setMaximized(true);
        }
    }

    public void minimizeOnAction(MouseEvent mouseEvent) {
        Stage s = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        s.setIconified(true);
    }

    private void clearButtonBackground() {
        btnDashboard.setStyle("-fx-background-color: transparent");
        btnStudents.setStyle("-fx-background-color: transparent");
        btnSubjects.setStyle("-fx-background-color: transparent");
        btnTeachers.setStyle("-fx-background-color: transparent");
        btnPayments.setStyle("-fx-background-color: transparent");
        btnStudentAttendance.setStyle("-fx-background-color: transparent");
        btnStudentMarks.setStyle("-fx-background-color: transparent");
        btnTimeTable.setStyle("-fx-background-color: transparent");
        btnSalaryManagement.setStyle("-fx-background-color: transparent");
        btnExpenses.setStyle("-fx-background-color: transparent");
        btnReports.setStyle("-fx-background-color: transparent");
        btnEmployee.setStyle("-fx-background-color: transparent");
        btnSettings.setStyle("-fx-background-color: transparent");
    }

    public void dashBoardFormOnAction(ActionEvent actionEvent) throws IOException {
        clearButtonBackground();
        btnDashboard.setStyle("-fx-background-color: #2980b9");
        URL resource = getClass().getResource("../view/DashBoard.fxml");
        Parent load = FXMLLoader.load(resource);
        mainFormStackForm.getChildren().clear();
        mainFormStackForm.getChildren().add(load);
    }

    public void studentFormOnAction(ActionEvent actionEvent) throws IOException {
        clearButtonBackground();
        btnStudents.setStyle("-fx-background-color: #2980b9");
        URL resource = getClass().getResource("../view/StudentForm.fxml");
        Parent load = FXMLLoader.load(resource);
        mainFormStackForm.getChildren().clear();
        mainFormStackForm.getChildren().add(load);
    }

    public void subjectFormOnAction(ActionEvent actionEvent) throws IOException {
        clearButtonBackground();
        btnSubjects.setStyle("-fx-background-color: #2980b9");
        URL resource = getClass().getResource("../view/SubjectForm.fxml");
        Parent load = FXMLLoader.load(resource);
        mainFormStackForm.getChildren().clear();
        mainFormStackForm.getChildren().add(load);
    }

    public void teacherFormOnAction(ActionEvent actionEvent) throws IOException {
        clearButtonBackground();
        btnTeachers.setStyle("-fx-background-color: #2980b9");
        URL resource = getClass().getResource("../view/TeacherForm.fxml");
        Parent load = FXMLLoader.load(resource);
        mainFormStackForm.getChildren().clear();
        mainFormStackForm.getChildren().add(load);
    }

    public void employeeFormOnAction(ActionEvent actionEvent) throws IOException {
        clearButtonBackground();
        btnEmployee.setStyle("-fx-background-color: #2980b9");
        URL resource = getClass().getResource("../view/EmployeeForm.fxml");
        Parent load = FXMLLoader.load(resource);
        mainFormStackForm.getChildren().clear();
        mainFormStackForm.getChildren().add(load);
    }

    public void paymentFormOnAction(ActionEvent actionEvent) throws IOException {
        clearButtonBackground();
        btnPayments.setStyle("-fx-background-color: #2980b9");
        FXMLLoader resource = new FXMLLoader(getClass().getResource("../view/PaymentForm.fxml"));
        Parent load = resource.load();
        PaymentFormController controller = resource.getController();
        if (lblUsertype.getText().equalsIgnoreCase("System User")) {
            controller.deleteMenu.setDisable(true);
        }
        mainFormStackForm.getChildren().clear();
        mainFormStackForm.getChildren().add(load);
    }

    public void attendanceFormOnAction(ActionEvent actionEvent) throws IOException {
        clearButtonBackground();
        btnStudentAttendance.setStyle("-fx-background-color: #2980b9");
        URL resource = getClass().getResource("../view/StudentAttendanceForm.fxml");
        Parent load = FXMLLoader.load(resource);
        mainFormStackForm.getChildren().clear();
        mainFormStackForm.getChildren().add(load);
    }

    public void StudentMarksFormOnAction(ActionEvent actionEvent) throws IOException {
        clearButtonBackground();
        btnStudentMarks.setStyle("-fx-background-color: #2980b9");
        URL resource = getClass().getResource("../view/StudentMarksForm.fxml");
        Parent load = FXMLLoader.load(resource);
        mainFormStackForm.getChildren().clear();
        mainFormStackForm.getChildren().add(load);
    }

    public void salaryFormOnAction(ActionEvent actionEvent) throws IOException {
        clearButtonBackground();
        btnSalaryManagement.setStyle("-fx-background-color: #2980b9");
        URL resource = getClass().getResource("../view/SalaryManagementForm.fxml");
        Parent load = FXMLLoader.load(resource);
        mainFormStackForm.getChildren().clear();
        mainFormStackForm.getChildren().add(load);
    }

    public void timeTableFormOnAction(ActionEvent actionEvent) throws IOException {
        clearButtonBackground();
        btnTimeTable.setStyle("-fx-background-color: #2980b9");
        URL resource = getClass().getResource("../view/TimeTableManageForm.fxml");
        Parent load = FXMLLoader.load(resource);
        mainFormStackForm.getChildren().clear();
        mainFormStackForm.getChildren().add(load);
    }

    public void expensesFormOnAction(ActionEvent actionEvent) throws IOException {
        clearButtonBackground();
        btnExpenses.setStyle("-fx-background-color: #2980b9");
        URL resource = getClass().getResource("../view/ExpensesForm.fxml");
        Parent load = FXMLLoader.load(resource);
        mainFormStackForm.getChildren().clear();
        mainFormStackForm.getChildren().add(load);
    }

    public void logOutOnAction(MouseEvent mouseEvent) throws IOException {
        Stage stg = (Stage) mainFormStackForm.getScene().getWindow();
        stg.close();
        URL resource = getClass().getResource("../view/LoginForm.fxml");
        Parent load = FXMLLoader.load(resource);
        Scene scene = new Scene(load);
        Stage stage = new Stage();
        stage.initStyle(StageStyle.UNDECORATED);
        stage.getIcons().add(new Image("assets/logo.png"));
        stage.setScene(scene);
        stage.show();
    }

    public void refreshTableOnAction(ActionEvent actionEvent) {
        try {
            cmbTeachers.getSelectionModel().clearSelection();
            loadStudentDetailsToTable(new StudentController().getAllStudentDetails());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void reportsFormOnAction(ActionEvent actionEvent) throws IOException {
        clearButtonBackground();
        btnReports.setStyle("-fx-background-color: #2980b9");
        URL resource = getClass().getResource("../view/ReportsForm.fxml");
        Parent load = FXMLLoader.load(resource);
        mainFormStackForm.getChildren().clear();
        mainFormStackForm.getChildren().add(load);
    }

    public void settingFormOnAction(ActionEvent actionEvent) throws IOException {
        clearButtonBackground();
        btnSettings.setStyle("-fx-background-color: #2980b9");
        URL resource = getClass().getResource("../view/SettingsForm.fxml");
        Parent load = FXMLLoader.load(resource);
        mainFormStackForm.getChildren().clear();
        mainFormStackForm.getChildren().add(load);
    }

    public void aboutFormOnAction(MouseEvent mouseEvent) throws IOException {
        Scene scene = new Scene(FXMLLoader.load(getClass().getResource("../view/About.fxml")));
        Stage stage = new Stage(StageStyle.UNDECORATED);
        stage.getIcons().add(new Image("assets/logo.png"));
        stage.setTitle("About");
        stage.setScene(scene);
        stage.show();
        PauseTransition delay = new PauseTransition(Duration.seconds(5));
        delay.setOnFinished(event -> stage.close());
        delay.play();
    }
}
