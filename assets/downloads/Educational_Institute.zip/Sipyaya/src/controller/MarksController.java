package controller;

import Database.DbConnection;
import controller.interfaces.MarksService;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import model.EvaluationMark;
import view.TM.EvaluationMarkTM;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;

public class MarksController implements MarksService {
    @Override
    public boolean addMarks(EvaluationMark mark) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("INSERT INTO `Evaluation Mark` VALUES(?,?,?,?,?,?,?,?)");
        stm.setObject(1, mark.getStudentId());
        stm.setObject(2, mark.getStudentName());
        stm.setObject(3, mark.getSubName());
        stm.setObject(4, mark.getGrade());
        stm.setObject(5, mark.getMonth());
        stm.setObject(6, mark.getIssuedDate());
        stm.setObject(7, mark.getMark());
        stm.setObject(8, mark.getTeacherName());
        return stm.executeUpdate() > 0;
    }

    @Override
    public ArrayList<EvaluationMark> getMarks() throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM `Evaluation Mark`");
        ResultSet rst = stm.executeQuery();
        ArrayList<EvaluationMark> marks = new ArrayList<>();
        while (rst.next()) {
            marks.add(new EvaluationMark(rst.getString(1), rst.getString(2), rst.getString(3), rst.getInt(4), rst.getString(5), rst.getString(6), rst.getInt(7), rst.getString(8)));
        }
        return marks;
    }

    @Override
    public boolean updateMarks(EvaluationMark mark) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("UPDATE `Evaluation Mark` SET Month=?, Marks=? WHERE StudentId=? AND StudentName=? AND IssuedDate=? AND SubjectName=?");
        stm.setObject(1, mark.getMonth());
        stm.setObject(2, mark.getMark());
        stm.setObject(3, mark.getStudentId());
        stm.setObject(4, mark.getStudentName());
        stm.setObject(5, mark.getIssuedDate());
        stm.setObject(6, mark.getSubName());
        return stm.executeUpdate() > 0;
    }

    @Override
    public boolean deleteMarks(EvaluationMarkTM selectedItem) throws SQLException, ClassNotFoundException {
        ButtonType yes = new ButtonType("Yes", ButtonBar.ButtonData.OK_DONE);
        ButtonType no = new ButtonType("No", ButtonBar.ButtonData.CANCEL_CLOSE);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure whether you want to delete this student marks?", yes, no);
        alert.setTitle("Confirmation Alert");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.orElse(no) == yes) {
            PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("DELETE FROM `Evaluation Mark` WHERE IssuedDate=? AND StudentName=? AND SubjectName=? AND StudentId=?");
            stm.setObject(1, selectedItem.getDate());
            stm.setObject(2, selectedItem.getStudentName());
            stm.setObject(3, selectedItem.getSubName());
            stm.setObject(4, selectedItem.getStudentId());
            return stm.executeUpdate() > 0;
        }
        return false;
    }
}
