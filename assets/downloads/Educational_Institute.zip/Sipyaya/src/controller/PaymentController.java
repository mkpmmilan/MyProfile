package controller;

import Database.DbConnection;
import controller.interfaces.PaymentService;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import model.Payment;
import model.Student;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class PaymentController implements PaymentService {

    @Override
    public ArrayList<Payment> getAllPayments() throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Payment");
        ResultSet rst = stm.executeQuery();
        ArrayList<Payment> payments = new ArrayList<>();
        while (rst.next()) {
            payments.add(new Payment(rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4), rst.getInt(5), rst.getString(6), rst.getString(7), rst.getString(8), rst.getDouble(9), rst.getString(10)));
        }
        return payments;
    }

    @Override
    public boolean deletePayment(String cardNo) throws SQLException, ClassNotFoundException {
        ButtonType yes = new ButtonType("Yes", ButtonBar.ButtonData.OK_DONE);
        ButtonType no = new ButtonType("No", ButtonBar.ButtonData.CANCEL_CLOSE);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure whether you want to delete this payment?", yes, no);
        alert.setTitle("Confirmation Alert");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.orElse(no) == yes) {
            PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("DELETE FROM Payment WHERE cardNo=?");
            stm.setObject(1, cardNo);
            return stm.executeUpdate() > 0;
        }
        return false;
    }

    @Override
    public boolean setPayment(Payment payment) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("INSERT INTO Payment VALUES(?,?,?,?,?,?,?,?,?,?)");
        stm.setObject(1, payment.getStudentId());
        stm.setObject(2, payment.getStudentName());
        stm.setObject(3, payment.getCardNo());
        stm.setObject(4, payment.getSubject());
        stm.setObject(5, payment.getGrade());
        stm.setObject(6, payment.getDate());
        stm.setObject(7, payment.getTime());
        stm.setObject(8, payment.getMonth());
        stm.setObject(9, payment.getCash());
        stm.setObject(10, payment.getTeacher());
        return stm.executeUpdate() > 0;
    }

    @Override
    public List<Payment> searchPaymentsDetails(String studentId, String studentName, String subject) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Payment WHERE studentId LIKE '%" + studentId + "%' AND studentName LIKE '%" + studentName + "%' AND subjectName LIKE '%" + subject + "%'");
        ResultSet rst = stm.executeQuery();
        ArrayList<Payment> payments = new ArrayList<>();
        while (rst.next()) {
            payments.add(new Payment(rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4), rst.getInt(5), rst.getString(6), rst.getString(7), rst.getString(8), rst.getDouble(9), rst.getString(10)));
        }
        return payments;
    }

    @Override
    public List<Payment> searchPayments(String newValue) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Payment WHERE studentId LIKE '%" + newValue + "%' OR studentName LIKE '%" + newValue + "%' OR grade LIKE '%" + newValue + "%' OR cardNo LIKE '%" + newValue + "%' OR subjectName LIKE '%" + newValue + "%' OR Month LIKE '%" + newValue + "%' OR Cash LIKE '%" + newValue + "%' OR Date LIKE '%" + newValue + "%' OR TeacherName LIKE '%" + newValue + "%'");
        ResultSet rst = stm.executeQuery();
        ArrayList<Payment> payments = new ArrayList<>();
        while (rst.next()) {
            payments.add(new Payment(rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4), rst.getInt(5), rst.getString(6), rst.getString(7), rst.getString(8), rst.getDouble(9), rst.getString(10)));
        }
        return payments;
    }

    @Override
    public List<Payment> getSearchPayments(LocalDate fromDateValue, LocalDate toDateValue, TextField txtTotalCash) throws SQLException, ClassNotFoundException {
        String fDate = String.valueOf(fromDateValue);
        String tDate = String.valueOf(toDateValue);
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Payment WHERE Date BETWEEN '" + fDate + "' AND '" + tDate + "'");
        ResultSet rst = stm.executeQuery();
        double totalCash = 0;
        ArrayList<Payment> payments = new ArrayList<>();
        while (rst.next()) {
            payments.add(new Payment(rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4), rst.getInt(5), rst.getString(6), rst.getString(7), rst.getString(8), rst.getDouble(9), rst.getString(10)));
            totalCash = totalCash + rst.getDouble(9);
        }
        txtTotalCash.setText(String.valueOf(totalCash));
        return payments;
    }

    @Override
    public double getPayments(String monthValue, Integer yearValue, String teacherName) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Payment WHERE Month=? AND YEAR(Date)=? AND TeacherName=?");
        stm.setObject(1, monthValue);
        stm.setObject(2, yearValue);
        stm.setObject(3, teacherName);
        ResultSet rst = stm.executeQuery();
        double totalClassFees = 0;
        while (rst.next()) {
            totalClassFees = totalClassFees + rst.getDouble(9);
        }
        return totalClassFees;
    }

    @Override
    public double getPaymentCash(String day) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT SUM(Cash) FROM Payment WHERE Date=?");
        stm.setObject(1, day);
        double paymentCash = 0;
        ResultSet rst = stm.executeQuery();
        while (rst.next()) {
            paymentCash = rst.getDouble(1);
        }
        return paymentCash;
    }

    @Override
    public double getTotalPayment(int year, String month) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT SUM(Cash) FROM Payment WHERE YEAR(Date)=? && MONTHNAME(Date)=?");
        stm.setObject(1, year);
        stm.setObject(2, month);
        ResultSet rst = stm.executeQuery();
        double payments = 0;
        while (rst.next()) {
            payments = rst.getDouble(1);
        }
        return payments;
    }

    @Override
    public double getAnnualPayments(int year) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT SUM(Cash) FROM Payment WHERE YEAR(Date)=?");
        stm.setObject(1, year);
        ResultSet rst = stm.executeQuery();
        double payments = 0;
        while (rst.next()) {
            payments = rst.getDouble(1);
        }
        return payments;
    }

    @Override
    public double getSumOfPayments(int grade, String fDate, String tDate) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT SUM(Cash) FROM Payment WHERE grade=? && Date BETWEEN ? AND ?");
        stm.setObject(1, grade);
        stm.setObject(2, fDate);
        stm.setObject(3, tDate);
        ResultSet rst = stm.executeQuery();
        double totalPayment = 0;
        while (rst.next()) {
            totalPayment = rst.getDouble(1);
        }
        return totalPayment;
    }
}
