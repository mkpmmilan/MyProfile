package controller;

import Notification.NotificationBuilder;
import Validation.ValidationUtil;
import animatefx.animation.ZoomIn;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import model.Payment;
import model.Student;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
import org.controlsfx.control.Notifications;
import view.TM.PaymentTM;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;

public class PaymentFormController {
    public TableView<PaymentTM> tblPayments;
    public MenuItem deleteMenu;
    public JFXTextField txtSearchStudentId;
    public JFXTextField txtStudentName;
    public JFXTextField txtCardNo;
    public JFXComboBox<String> cmbMonth;
    public TextField txtCash;
    public JFXButton btnAddPayment;
    public JFXButton btnClear;
    public TableColumn colStudentId;
    public TableColumn colStudentName;
    public TableColumn colGrade;
    public TableColumn colCardNo;
    public TableColumn colSubject;
    public TableColumn colMonth;
    public TableColumn colCash;
    public JFXTextField txtSearch;
    public JFXTextField txtGrade;
    public TableColumn colDate;
    public TableColumn colTeacher;
    public JFXComboBox<String> cmbSubject;
    public JFXComboBox<String> cmbTeacher;
    public JFXDatePicker fromDate;
    public JFXDatePicker toDate;
    public TextField txtTotalCash;

    LinkedHashMap<JFXTextField, Pattern> jfxTextFieldPatternLinkedHashMap = new LinkedHashMap<>();
    LinkedHashMap<TextField, Pattern> textFieldPatternLinkedHashMap = new LinkedHashMap<>();
    Pattern searchStudentIdPattern = Pattern.compile("^(S00-)[0-9]{3}$");
    Pattern cardNoPattern = Pattern.compile("^[0-9]{5}$");

    public void initialize() {
        try {
            loadPaymentDetailsToTable(new PaymentController().getAllPayments());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        cmbMonth.getItems().addAll("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
        btnAddPayment.setDisable(true);
        storeValidations();
        txtSearch.textProperty().addListener((observable, oldValue, newValue) -> {
            search(newValue);
        });
        cmbMonth.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (!txtSearchStudentId.getText().isEmpty() && !cmbSubject.getSelectionModel().isEmpty() && !cmbTeacher.getSelectionModel().isEmpty() && !txtCardNo.getText().isEmpty() && !txtCash.getText().isEmpty()) {
                btnAddPayment.setDisable(false);
            }
        });
        cmbSubject.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            searchPaymentDetailsOnAction(newValue);
            if (!txtSearchStudentId.getText().isEmpty() && !cmbTeacher.getSelectionModel().isEmpty() && !txtCardNo.getText().isEmpty() && !cmbMonth.getSelectionModel().isEmpty() && !txtCash.getText().isEmpty()) {
                btnAddPayment.setDisable(false);
            }
        });
        cmbTeacher.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            searchClassFees(newValue);
            if (!txtSearchStudentId.getText().isEmpty() && !cmbSubject.getSelectionModel().isEmpty() && !txtCardNo.getText().isEmpty() && !cmbMonth.getSelectionModel().isEmpty() && !txtCash.getText().isEmpty()) {
                btnAddPayment.setDisable(false);
            }
        });
        new ZoomIn(tblPayments).play();
    }

    private void searchClassFees(String newValue) {
        try {
            new TeacherController().getClassFees(newValue, txtCash);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void search(String newValue) {
        try {
            List<Payment> payments = new PaymentController().searchPayments(newValue);
            ObservableList<PaymentTM> obList = FXCollections.observableArrayList();
            payments.forEach(e -> {
                obList.add(new PaymentTM(e.getStudentId(), e.getStudentName(), e.getGrade(), e.getCardNo(), e.getSubject(), e.getMonth(), e.getCash(), e.getDate(), e.getTeacher()));
            });
            tblPayments.setItems(obList);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void loadPaymentDetailsToTable(ArrayList<Payment> allPayments) {
        ObservableList<PaymentTM> obList = FXCollections.observableArrayList();
        allPayments.forEach(e -> {
            obList.add(new PaymentTM(e.getStudentId(), e.getStudentName(), e.getGrade(), e.getCardNo(), e.getSubject(), e.getMonth(), e.getCash(), e.getDate(), e.getTeacher()));
        });
        tblPayments.setItems(obList);
        initCols();
    }

    private void initCols() {
        colStudentId.setCellValueFactory(new PropertyValueFactory<>("studentId"));
        colStudentName.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        colGrade.setCellValueFactory(new PropertyValueFactory<>("grade"));
        colCardNo.setCellValueFactory(new PropertyValueFactory<>("cardNo"));
        colMonth.setCellValueFactory(new PropertyValueFactory<>("month"));
        colSubject.setCellValueFactory(new PropertyValueFactory<>("subject"));
        colCash.setCellValueFactory(new PropertyValueFactory<>("cash"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("date"));
        colTeacher.setCellValueFactory(new PropertyValueFactory<>("teacher"));
    }

    private void storeValidations() {
        jfxTextFieldPatternLinkedHashMap.put(txtSearchStudentId, searchStudentIdPattern);
        jfxTextFieldPatternLinkedHashMap.put(txtCardNo, cardNoPattern);
    }

    public void searchStudentDetailsOnAction(ActionEvent actionEvent) {
        try {
            cmbSubject.getItems().clear();
            cmbTeacher.getItems().clear();
            Student student = new StudentController().getStudent(txtSearchStudentId.getText());
            if (student == null) {
                Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Student not found.Please try again");
                warning.showWarning();
            } else {
                txtStudentName.setText(student.getStudentName());
                txtGrade.setText(String.valueOf(student.getGrade()));

                String subject = student.getSubjectName();
                String[] subjects = subject.split("[,]");
                cmbSubject.getItems().addAll(subjects);

                String teacher = student.getTeacherName();
                String[] teachers = teacher.split("[,]");
                cmbTeacher.getItems().addAll(teachers);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    public void jfxTextFieldsValidationOnAction(KeyEvent keyEvent) {
        Object response = ValidationUtil.validateJFXTextField(jfxTextFieldPatternLinkedHashMap, btnAddPayment);
        btnAddPayment.setDisable(true);
        if (keyEvent.getCode() == KeyCode.ENTER) {
            if (response instanceof TextField) {
                TextField errorText = (TextField) response;
                errorText.requestFocus();
            } else if (response instanceof Boolean) {
                if (!txtCash.getText().isEmpty() && !cmbMonth.getSelectionModel().isEmpty() && !cmbSubject.getSelectionModel().isEmpty() && !cmbTeacher.getSelectionModel().isEmpty()) {
                    btnAddPayment.setDisable(false);
                }
            }
        }
    }

    public void textFieldValidationOnAction(KeyEvent keyEvent) {
        btnAddPayment.setDisable(true);
        for (TextField textFieldKey : textFieldPatternLinkedHashMap.keySet()) {
            Pattern patternValue = textFieldPatternLinkedHashMap.get(textFieldKey);
            if (!patternValue.matcher(textFieldKey.getText()).matches()) {
                if (!textFieldKey.getText().isEmpty()) {
                    textFieldKey.setStyle("-fx-text-fill: red");
                    return;
                }
            }
            textFieldKey.setStyle("-fx-text-fill: green");
        }
        if (!txtSearchStudentId.getText().isEmpty() && !cmbSubject.getSelectionModel().isEmpty() && !txtCardNo.getText().isEmpty() && !cmbTeacher.getSelectionModel().isEmpty() && !cmbMonth.getSelectionModel().isEmpty() && !txtCash.getText().isEmpty()) {
            btnAddPayment.setDisable(false);
        }
    }

    public void addPaymentOnAction(MouseEvent mouseEvent) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hh:mm:ss");
        String time = simpleDateFormat.format(new Date());
        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(new Date());
        if (!cmbMonth.getSelectionModel().isEmpty()) {
            if (!txtSearchStudentId.getText().isEmpty() && !cmbSubject.getSelectionModel().isEmpty() && !txtCardNo.getText().isEmpty() && !cmbTeacher.getSelectionModel().isEmpty()) {
                Payment payment = new Payment(txtSearchStudentId.getText(), txtStudentName.getText(), txtCardNo.getText(), cmbSubject.getSelectionModel().getSelectedItem(), Integer.parseInt(txtGrade.getText()), date, time, cmbMonth.getSelectionModel().getSelectedItem(), Double.parseDouble(txtCash.getText()), cmbTeacher.getSelectionModel().getSelectedItem());
                try {
                    if (new PaymentController().setPayment(payment)) {
                        Notifications information = NotificationBuilder.notifyMassage("INFORMATION", "Payment Saved Successfully");
                        information.showInformation();

                        String studentId = txtSearchStudentId.getText();
                        String studentName = txtStudentName.getText();
                        int grade = Integer.parseInt(txtGrade.getText());
                        String subject = cmbSubject.getValue();
                        String teacher = cmbTeacher.getValue();
                        String month = cmbMonth.getValue();
                        String cardNo = txtCardNo.getText();
                        double cash = Double.parseDouble(txtCash.getText());

                        HashMap map = new HashMap();
                        map.put("cardNo", cardNo);
                        map.put("paymentMonth", month);
                        map.put("stuId", studentId);
                        map.put("stuName", studentName);
                        map.put("stuGrade", grade);
                        map.put("paymentSubject", subject);
                        map.put("paymentTeacher", teacher);
                        map.put("paymentCash", cash);

                        JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/PaymentsDetails.jrxml"));
                        JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                        JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, new JREmptyDataSource(1));
                        JasperViewer.viewReport(jasperPrint, false);


                        txtSearchStudentId.clear();
                        txtStudentName.clear();
                        txtGrade.clear();
                        txtCardNo.clear();
                        cmbSubject.getItems().clear();
                        txtCash.clear();
                        cmbMonth.getSelectionModel().clearSelection();
                        cmbTeacher.getItems().clear();
                        btnAddPayment.setDisable(true);
                        loadPaymentDetailsToTable(new PaymentController().getAllPayments());
                    } else {

                    }
                } catch (SQLIntegrityConstraintViolationException e) {
                    Notifications error = NotificationBuilder.notifyMassage("ERROR", "Card No is exists.Please try again");
                    error.showError();
                } catch (SQLException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } catch (JRException e) {
                    e.printStackTrace();
                }
            }
        } else {
            Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please select month");
            warning.showWarning();
        }
    }

    public void searchPaymentDetailsOnAction(String newValue) {
        try {
            List<Payment> payments = new PaymentController().searchPaymentsDetails(txtSearchStudentId.getText(), txtStudentName.getText(), newValue);
            ObservableList<PaymentTM> obList = FXCollections.observableArrayList();
            payments.forEach(e -> {
                obList.add(new PaymentTM(e.getStudentId(), e.getStudentName(), e.getGrade(), e.getCardNo(), e.getSubject(), e.getMonth(), e.getCash(), e.getDate(), e.getTeacher()));
            });
            tblPayments.setItems(obList);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void clearOnAction(ActionEvent actionEvent) {
        txtSearchStudentId.clear();
        txtCash.clear();
        txtStudentName.clear();
        txtGrade.clear();
        txtCardNo.clear();
        cmbSubject.getItems().clear();
        cmbMonth.getSelectionModel().clearSelection();
        btnAddPayment.setDisable(true);
        cmbTeacher.getItems().clear();
        try {
            loadPaymentDetailsToTable(new PaymentController().getAllPayments());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void refreshTableOnAction(ActionEvent actionEvent) {
        try {
            loadPaymentDetailsToTable(new PaymentController().getAllPayments());
            txtSearch.clear();
            fromDate.setValue(null);
            toDate.setValue(null);
            txtTotalCash.clear();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void deletePaymentOnAction(ActionEvent actionEvent) {
        PaymentTM selectedItem = tblPayments.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            Notifications error = NotificationBuilder.notifyMassage("ERROR", "No Payment raw selected.");
            error.showError();
        } else {
            try {
                if (new PaymentController().deletePayment(selectedItem.getCardNo())) {
                    Notifications information = NotificationBuilder.notifyMassage("INFORMATION", "Payment details deleted successfully");
                    information.showInformation();
                    loadPaymentDetailsToTable(new PaymentController().getAllPayments());
                    txtSearch.clear();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    public void searchOnAction(ActionEvent actionEvent) {
        if (fromDate.getValue() != null && toDate.getValue() != null) {
            try {
                List<Payment> payments = new PaymentController().getSearchPayments(fromDate.getValue(), toDate.getValue(), txtTotalCash);
                ObservableList<PaymentTM> obList = FXCollections.observableArrayList();
                payments.forEach(e -> {
                    obList.add(new PaymentTM(e.getStudentId(), e.getStudentName(), e.getGrade(), e.getCardNo(), e.getSubject(), e.getMonth(), e.getCash(), e.getDate(), e.getTeacher()));
                });
                tblPayments.setItems(obList);
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
}
