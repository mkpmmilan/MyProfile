package controller;

import Database.DbConnection;
import Notification.NotificationBuilder;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDatePicker;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.*;
import model.Student;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
import org.controlsfx.control.Notifications;

import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.List;

public class ReportsFormController {

    public ToggleGroup tgReports;
    public ComboBox<String> cmbStudent;
    public ComboBox<String> cmbTeacher;
    public ComboBox<String> cmbEmployee;
    public ComboBox<String> cmbIncomeReports;
    public TextField txtSearchStudentId;
    public ComboBox<String> cmbTeacherName;
    public ComboBox<String> cmbEmployeeName;
    public Spinner<Integer> spYear;
    public Spinner<String> spMonth;
    public JFXDatePicker fromDate;
    public JFXDatePicker toDate;
    public JFXButton btnGenerateReport;
    public ComboBox<String> cmbSubject;
    public TextField txtStudentName;
    public ComboBox<Integer> cmbGrade;
    public ComboBox<Integer> cmbTeacherGrade;
    public JFXDatePicker date;
    public ComboBox<Integer> cmbIncomeReportsGrade;


    public void initialize() {
        disableComponents();
        loadTeacherNames();
        loadEmployeeNames();

        SpinnerValueFactory<Integer> yearValues = new SpinnerValueFactory.IntegerSpinnerValueFactory(2021, 2099);
        spYear.setValueFactory(yearValues);

        ObservableList<String> months = FXCollections.observableArrayList();
        months.addAll("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
        SpinnerValueFactory<String> monthValues = new SpinnerValueFactory.ListSpinnerValueFactory<>(months);
        spMonth.setValueFactory(monthValues);

        cmbGrade.getItems().addAll(6, 7, 8, 9, 10, 11);
        cmbTeacherGrade.getItems().addAll(6, 7, 8, 9, 10, 11);
        cmbIncomeReportsGrade.getItems().addAll(6, 7, 8, 9, 10, 11);
        cmbStudent.getItems().addAll("Student Wise Payment Report", "Student Wise Evaluation Marks", "Student Wise Attendance Report", "Grade Wise Student Evaluation Marks", "Unpaid Students in Current Month");
        cmbTeacher.getItems().addAll("Teacher Wise Students Report", "Teacher Wise Evaluation Marks", "Teacher Wise Time Table", "Teacher Salary Report", "Teacher Wise Pay Slip");
        cmbEmployee.getItems().addAll("Employee Details Report", "Employee Salary Report", "Employee Wise Pay Slip");
        cmbIncomeReports.getItems().addAll("Daily Income Report", "Monthly Income Report", "Annual Income Report", "Grade Wise Student Payments", "Total Teacher Salary Report", "Total Employee Salary Report", "Total Expenses Report");

        tgReports.selectedToggleProperty().addListener((observable, oldValue, newValue) -> {
            RadioButton selectedButton = (RadioButton) tgReports.getSelectedToggle();
            if (selectedButton.getText().equalsIgnoreCase("Student")) {
                clearAllComponents();
                cmbIncomeReportsGrade.setDisable(true);
                cmbTeacherGrade.setDisable(true);
                cmbStudent.setDisable(false);
                cmbTeacher.setDisable(true);
                cmbEmployee.setDisable(true);
                cmbIncomeReports.setDisable(true);
                txtSearchStudentId.setDisable(true);
                cmbTeacherName.setDisable(true);
                txtStudentName.setDisable(true);
                cmbEmployeeName.setDisable(true);
                spYear.setDisable(true);
                spMonth.setDisable(true);
                fromDate.setDisable(true);
                toDate.setDisable(true);
                cmbGrade.setDisable(true);
                cmbSubject.setDisable(true);
                btnGenerateReport.setDisable(true);
                date.setDisable(true);
            } else if (selectedButton.getText().equalsIgnoreCase("Teacher")) {
                clearAllComponents();
                cmbIncomeReportsGrade.setDisable(true);
                cmbTeacherGrade.setDisable(true);
                cmbStudent.setDisable(true);
                cmbTeacher.setDisable(false);
                cmbEmployee.setDisable(true);
                cmbIncomeReports.setDisable(true);
                txtSearchStudentId.setDisable(true);
                cmbTeacherName.setDisable(true);
                txtStudentName.setDisable(true);
                cmbEmployeeName.setDisable(true);
                spYear.setDisable(true);
                spMonth.setDisable(true);
                fromDate.setDisable(true);
                toDate.setDisable(true);
                cmbGrade.setDisable(true);
                cmbSubject.setDisable(true);
                btnGenerateReport.setDisable(true);
                date.setDisable(true);
            } else if (selectedButton.getText().equalsIgnoreCase("Employee")) {
                clearAllComponents();
                cmbIncomeReportsGrade.setDisable(true);
                cmbTeacherGrade.setDisable(true);
                cmbStudent.setDisable(true);
                cmbTeacher.setDisable(true);
                cmbEmployee.setDisable(false);
                cmbIncomeReports.setDisable(true);
                txtSearchStudentId.setDisable(true);
                cmbTeacherName.setDisable(true);
                txtStudentName.setDisable(true);
                cmbEmployeeName.setDisable(true);
                spYear.setDisable(true);
                spMonth.setDisable(true);
                fromDate.setDisable(true);
                toDate.setDisable(true);
                cmbGrade.setDisable(true);
                cmbSubject.setDisable(true);
                btnGenerateReport.setDisable(true);
                date.setDisable(true);
            } else if (selectedButton.getText().equalsIgnoreCase("Income Reports")) {
                clearAllComponents();
                cmbIncomeReportsGrade.setDisable(true);
                cmbTeacherGrade.getSelectionModel().clearSelection();
                cmbStudent.setDisable(true);
                cmbTeacher.setDisable(true);
                cmbEmployee.setDisable(true);
                cmbIncomeReports.setDisable(false);
                txtSearchStudentId.setDisable(true);
                cmbTeacherName.setDisable(true);
                txtStudentName.setDisable(true);
                cmbEmployeeName.setDisable(true);
                spYear.setDisable(true);
                spMonth.setDisable(true);
                fromDate.setDisable(true);
                toDate.setDisable(true);
                cmbGrade.setDisable(true);
                cmbSubject.setDisable(true);
                btnGenerateReport.setDisable(true);
                date.setDisable(true);
            }
        });
        cmbStudent.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                if (newValue.equalsIgnoreCase("Student Wise Payment Report")) {
                    txtSearchStudentId.clear();
                    txtStudentName.clear();
                    cmbSubject.getItems().clear();
                    cmbGrade.getSelectionModel().clearSelection();
                    fromDate.setValue(null);
                    toDate.setValue(null);
                    date.setValue(null);
                    cmbIncomeReportsGrade.setDisable(true);
                    date.setDisable(true);
                    cmbTeacher.setDisable(true);
                    cmbEmployee.setDisable(true);
                    cmbIncomeReports.setDisable(true);
                    txtSearchStudentId.setDisable(false);
                    cmbTeacherName.setDisable(true);
                    txtStudentName.setDisable(false);
                    cmbEmployeeName.setDisable(true);
                    spYear.setDisable(true);
                    spMonth.setDisable(true);
                    fromDate.setDisable(false);
                    toDate.setDisable(false);
                    cmbGrade.setDisable(true);
                    cmbSubject.setDisable(false);
                    btnGenerateReport.setDisable(false);
                    cmbTeacherGrade.setDisable(true);
                } else if (newValue.equalsIgnoreCase("Student Wise Evaluation Marks")) {
                    txtSearchStudentId.clear();
                    txtStudentName.clear();
                    cmbSubject.getItems().clear();
                    cmbGrade.getSelectionModel().clearSelection();
                    fromDate.setValue(null);
                    toDate.setValue(null);
                    date.setValue(null);
                    cmbIncomeReportsGrade.setDisable(true);
                    date.setDisable(true);
                    cmbTeacher.setDisable(true);
                    cmbEmployee.setDisable(true);
                    cmbIncomeReports.setDisable(true);
                    txtSearchStudentId.setDisable(false);
                    cmbTeacherName.setDisable(true);
                    txtStudentName.setDisable(false);
                    cmbEmployeeName.setDisable(true);
                    spYear.setDisable(true);
                    spMonth.setDisable(true);
                    fromDate.setDisable(false);
                    toDate.setDisable(false);
                    cmbGrade.setDisable(true);
                    cmbSubject.setDisable(false);
                    btnGenerateReport.setDisable(false);
                    cmbTeacherGrade.setDisable(true);
                } else if (newValue.equalsIgnoreCase("Student Wise Attendance Report")) {
                    txtSearchStudentId.clear();
                    txtStudentName.clear();
                    cmbSubject.getItems().clear();
                    cmbGrade.getSelectionModel().clearSelection();
                    fromDate.setValue(null);
                    toDate.setValue(null);
                    date.setValue(null);
                    cmbIncomeReportsGrade.setDisable(true);
                    date.setDisable(true);
                    cmbTeacher.setDisable(true);
                    cmbEmployee.setDisable(true);
                    cmbIncomeReports.setDisable(true);
                    txtSearchStudentId.setDisable(false);
                    cmbTeacherName.setDisable(true);
                    txtStudentName.setDisable(false);
                    cmbEmployeeName.setDisable(true);
                    spYear.setDisable(true);
                    spMonth.setDisable(true);
                    fromDate.setDisable(false);
                    toDate.setDisable(false);
                    cmbGrade.setDisable(true);
                    cmbSubject.setDisable(false);
                    btnGenerateReport.setDisable(false);
                    cmbTeacherGrade.setDisable(true);
                } else if (newValue.equalsIgnoreCase("Grade Wise Student Evaluation Marks")) {
                    txtSearchStudentId.clear();
                    txtStudentName.clear();
                    cmbSubject.getItems().clear();
                    cmbGrade.getSelectionModel().clearSelection();
                    fromDate.setValue(null);
                    toDate.setValue(null);
                    date.setValue(null);
                    date.setDisable(true);
                    try {
                        List<String> subjects = new SubjectController().getSubjectNames();
                        cmbSubject.getItems().addAll(subjects);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }
                    cmbTeacher.setDisable(true);
                    cmbEmployee.setDisable(true);
                    cmbIncomeReports.setDisable(true);
                    txtSearchStudentId.setDisable(true);
                    cmbTeacherName.setDisable(true);
                    txtStudentName.setDisable(true);
                    cmbEmployeeName.setDisable(true);
                    spYear.setDisable(true);
                    spMonth.setDisable(true);
                    fromDate.setDisable(false);
                    toDate.setDisable(false);
                    cmbGrade.setDisable(false);
                    cmbSubject.setDisable(false);
                    btnGenerateReport.setDisable(false);
                    cmbTeacherGrade.setDisable(true);
                    cmbIncomeReportsGrade.setDisable(true);
                } else if (newValue.equalsIgnoreCase("Unpaid Students in Current Month")) {
                    txtSearchStudentId.clear();
                    txtStudentName.clear();
                    cmbSubject.getItems().clear();
                    cmbGrade.getSelectionModel().clearSelection();
                    fromDate.setValue(null);
                    toDate.setValue(null);
                    date.setValue(null);
                    cmbIncomeReportsGrade.setDisable(true);
                    date.setDisable(true);
                    cmbTeacher.setDisable(true);
                    cmbEmployee.setDisable(true);
                    cmbIncomeReports.setDisable(true);
                    txtSearchStudentId.setDisable(true);
                    cmbTeacherName.setDisable(true);
                    txtStudentName.setDisable(true);
                    cmbEmployeeName.setDisable(true);
                    spYear.setDisable(true);
                    spMonth.setDisable(true);
                    fromDate.setDisable(true);
                    toDate.setDisable(true);
                    cmbGrade.setDisable(true);
                    cmbSubject.setDisable(true);
                    btnGenerateReport.setDisable(false);
                    cmbTeacherGrade.setDisable(true);
                }
            }
        });

        cmbTeacher.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                if (newValue.equalsIgnoreCase("Teacher Wise Students Report")) {
                    cmbTeacherName.getSelectionModel().clearSelection();
                    cmbTeacherGrade.getSelectionModel().clearSelection();
                    fromDate.setValue(null);
                    toDate.setValue(null);
                    date.setValue(null);
                    date.setDisable(true);
                    cmbStudent.setDisable(true);
                    cmbEmployee.setDisable(true);
                    cmbIncomeReports.setDisable(true);
                    txtSearchStudentId.setDisable(true);
                    cmbTeacherName.setDisable(false);
                    txtStudentName.setDisable(true);
                    cmbEmployeeName.setDisable(true);
                    spYear.setDisable(true);
                    spMonth.setDisable(true);
                    fromDate.setDisable(true);
                    toDate.setDisable(true);
                    cmbGrade.setDisable(true);
                    cmbSubject.setDisable(true);
                    btnGenerateReport.setDisable(false);
                    cmbTeacherGrade.setDisable(false);
                    cmbIncomeReportsGrade.setDisable(true);
                } else if (newValue.equalsIgnoreCase("Teacher Wise Evaluation Marks")) {
                    cmbTeacherName.getSelectionModel().clearSelection();
                    cmbTeacherGrade.getSelectionModel().clearSelection();
                    fromDate.setValue(null);
                    toDate.setValue(null);
                    date.setValue(null);
                    date.setDisable(true);
                    cmbStudent.setDisable(true);
                    cmbEmployee.setDisable(true);
                    cmbIncomeReports.setDisable(true);
                    txtSearchStudentId.setDisable(true);
                    cmbTeacherName.setDisable(false);
                    txtStudentName.setDisable(true);
                    cmbEmployeeName.setDisable(true);
                    spYear.setDisable(true);
                    spMonth.setDisable(true);
                    fromDate.setDisable(false);
                    toDate.setDisable(false);
                    cmbGrade.setDisable(true);
                    cmbSubject.setDisable(true);
                    btnGenerateReport.setDisable(false);
                    cmbTeacherGrade.setDisable(false);
                    cmbIncomeReportsGrade.setDisable(true);
                } else if (newValue.equalsIgnoreCase("Teacher Wise Time Table")) {
                    cmbTeacherName.getSelectionModel().clearSelection();
                    cmbTeacherGrade.getSelectionModel().clearSelection();
                    fromDate.setValue(null);
                    toDate.setValue(null);
                    date.setValue(null);
                    date.setDisable(true);
                    cmbStudent.setDisable(true);
                    cmbEmployee.setDisable(true);
                    cmbIncomeReports.setDisable(true);
                    txtSearchStudentId.setDisable(true);
                    cmbTeacherName.setDisable(false);
                    txtStudentName.setDisable(true);
                    cmbEmployeeName.setDisable(true);
                    spYear.setDisable(true);
                    spMonth.setDisable(true);
                    fromDate.setDisable(false);
                    toDate.setDisable(false);
                    cmbGrade.setDisable(true);
                    cmbSubject.setDisable(true);
                    btnGenerateReport.setDisable(false);
                    cmbTeacherGrade.setDisable(true);
                    cmbIncomeReportsGrade.setDisable(true);
                } else if (newValue.equalsIgnoreCase("Teacher Salary Report")) {
                    cmbTeacherName.getSelectionModel().clearSelection();
                    cmbTeacherGrade.getSelectionModel().clearSelection();
                    fromDate.setValue(null);
                    toDate.setValue(null);
                    date.setValue(null);
                    date.setDisable(true);
                    cmbStudent.setDisable(true);
                    cmbEmployee.setDisable(true);
                    cmbIncomeReports.setDisable(true);
                    txtSearchStudentId.setDisable(true);
                    cmbTeacherName.setDisable(false);
                    txtStudentName.setDisable(true);
                    cmbEmployeeName.setDisable(true);
                    spYear.setDisable(true);
                    spMonth.setDisable(true);
                    fromDate.setDisable(false);
                    toDate.setDisable(false);
                    cmbGrade.setDisable(true);
                    cmbSubject.setDisable(true);
                    btnGenerateReport.setDisable(false);
                    cmbTeacherGrade.setDisable(true);
                    cmbIncomeReportsGrade.setDisable(true);
                } else if (newValue.equalsIgnoreCase("Teacher Wise Pay Slip")) {
                    cmbTeacherName.getSelectionModel().clearSelection();
                    cmbTeacherGrade.getSelectionModel().clearSelection();
                    fromDate.setValue(null);
                    toDate.setValue(null);
                    date.setValue(null);
                    date.setDisable(true);
                    cmbStudent.setDisable(true);
                    cmbEmployee.setDisable(true);
                    cmbIncomeReports.setDisable(true);
                    txtSearchStudentId.setDisable(true);
                    cmbTeacherName.setDisable(false);
                    txtStudentName.setDisable(true);
                    cmbEmployeeName.setDisable(true);
                    spYear.setDisable(false);
                    spMonth.setDisable(false);
                    fromDate.setDisable(true);
                    toDate.setDisable(true);
                    cmbGrade.setDisable(true);
                    cmbSubject.setDisable(true);
                    btnGenerateReport.setDisable(false);
                    cmbTeacherGrade.setDisable(true);
                    cmbIncomeReportsGrade.setDisable(true);
                }
            }
        });

        cmbEmployee.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                if (newValue.equalsIgnoreCase("Employee Details Report")) {
                    cmbEmployeeName.getSelectionModel().clearSelection();
                    fromDate.setValue(null);
                    toDate.setValue(null);
                    date.setDisable(true);
                    cmbStudent.setDisable(true);
                    cmbTeacher.setDisable(true);
                    cmbIncomeReports.setDisable(true);
                    txtSearchStudentId.setDisable(true);
                    cmbTeacherName.setDisable(true);
                    txtStudentName.setDisable(true);
                    cmbEmployeeName.setDisable(false);
                    spYear.setDisable(true);
                    spMonth.setDisable(true);
                    fromDate.setDisable(true);
                    toDate.setDisable(true);
                    cmbGrade.setDisable(true);
                    cmbSubject.setDisable(true);
                    btnGenerateReport.setDisable(false);
                    cmbTeacherGrade.setDisable(true);
                    cmbIncomeReportsGrade.setDisable(true);
                } else if (newValue.equalsIgnoreCase("Employee Salary Report")) {
                    cmbEmployeeName.getSelectionModel().clearSelection();
                    fromDate.setValue(null);
                    toDate.setValue(null);
                    date.setDisable(true);
                    cmbStudent.setDisable(true);
                    cmbTeacher.setDisable(true);
                    cmbIncomeReports.setDisable(true);
                    txtSearchStudentId.setDisable(true);
                    cmbTeacherName.setDisable(true);
                    txtStudentName.setDisable(true);
                    cmbEmployeeName.setDisable(false);
                    spYear.setDisable(true);
                    spMonth.setDisable(true);
                    fromDate.setDisable(false);
                    toDate.setDisable(false);
                    cmbGrade.setDisable(true);
                    cmbSubject.setDisable(true);
                    btnGenerateReport.setDisable(false);
                    cmbTeacherGrade.setDisable(true);
                    cmbIncomeReportsGrade.setDisable(true);
                } else if (newValue.equalsIgnoreCase("Employee Wise Pay Slip")) {
                    cmbEmployeeName.getSelectionModel().clearSelection();
                    fromDate.setValue(null);
                    toDate.setValue(null);
                    date.setDisable(true);
                    cmbStudent.setDisable(true);
                    cmbTeacher.setDisable(true);
                    cmbIncomeReports.setDisable(true);
                    txtSearchStudentId.setDisable(true);
                    cmbTeacherName.setDisable(true);
                    txtStudentName.setDisable(true);
                    cmbEmployeeName.setDisable(false);
                    spYear.setDisable(false);
                    spMonth.setDisable(false);
                    fromDate.setDisable(true);
                    toDate.setDisable(true);
                    cmbGrade.setDisable(true);
                    cmbSubject.setDisable(true);
                    btnGenerateReport.setDisable(false);
                    cmbTeacherGrade.setDisable(true);
                    cmbIncomeReportsGrade.setDisable(true);
                }
            }
        });
        cmbIncomeReports.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                if (newValue.equalsIgnoreCase("Daily Income Report")) {
                    fromDate.setValue(null);
                    toDate.setValue(null);
                    date.setValue(null);
                    cmbIncomeReportsGrade.getSelectionModel().clearSelection();
                    cmbIncomeReportsGrade.setDisable(true);
                    cmbStudent.setDisable(true);
                    cmbTeacher.setDisable(true);
                    cmbEmployee.setDisable(true);
                    txtSearchStudentId.setDisable(true);
                    cmbTeacherName.setDisable(true);
                    txtStudentName.setDisable(true);
                    cmbEmployeeName.setDisable(true);
                    spYear.setDisable(true);
                    spMonth.setDisable(true);
                    fromDate.setDisable(true);
                    toDate.setDisable(true);
                    cmbGrade.setDisable(true);
                    cmbSubject.setDisable(true);
                    btnGenerateReport.setDisable(false);
                    cmbTeacherGrade.setDisable(true);
                    date.setDisable(false);
                } else if (newValue.equalsIgnoreCase("Monthly Income Report")) {
                    fromDate.setValue(null);
                    toDate.setValue(null);
                    date.setValue(null);
                    cmbIncomeReportsGrade.getSelectionModel().clearSelection();
                    cmbIncomeReportsGrade.setDisable(true);
                    cmbStudent.setDisable(true);
                    cmbTeacher.setDisable(true);
                    cmbEmployee.setDisable(true);
                    txtSearchStudentId.setDisable(true);
                    cmbTeacherName.setDisable(true);
                    txtStudentName.setDisable(true);
                    cmbEmployeeName.setDisable(true);
                    spYear.setDisable(false);
                    spMonth.setDisable(false);
                    fromDate.setDisable(true);
                    toDate.setDisable(true);
                    cmbGrade.setDisable(true);
                    cmbSubject.setDisable(true);
                    btnGenerateReport.setDisable(false);
                    cmbTeacherGrade.setDisable(true);
                    date.setDisable(true);
                } else if (newValue.equalsIgnoreCase("Annual Income Report")) {
                    fromDate.setValue(null);
                    toDate.setValue(null);
                    date.setValue(null);
                    cmbIncomeReportsGrade.getSelectionModel().clearSelection();
                    cmbIncomeReportsGrade.setDisable(true);
                    cmbStudent.setDisable(true);
                    cmbTeacher.setDisable(true);
                    cmbEmployee.setDisable(true);
                    txtSearchStudentId.setDisable(true);
                    cmbTeacherName.setDisable(true);
                    txtStudentName.setDisable(true);
                    cmbEmployeeName.setDisable(true);
                    spYear.setDisable(false);
                    spMonth.setDisable(true);
                    fromDate.setDisable(true);
                    toDate.setDisable(true);
                    cmbGrade.setDisable(true);
                    cmbSubject.setDisable(true);
                    btnGenerateReport.setDisable(false);
                    cmbTeacherGrade.setDisable(true);
                    date.setDisable(true);
                } else if (newValue.equalsIgnoreCase("Grade Wise Student Payments")) {
                    fromDate.setValue(null);
                    toDate.setValue(null);
                    date.setValue(null);
                    cmbIncomeReportsGrade.getSelectionModel().clearSelection();
                    cmbIncomeReportsGrade.setDisable(false);
                    cmbStudent.setDisable(true);
                    cmbTeacher.setDisable(true);
                    cmbEmployee.setDisable(true);
                    txtSearchStudentId.setDisable(true);
                    cmbTeacherName.setDisable(true);
                    txtStudentName.setDisable(true);
                    cmbEmployeeName.setDisable(true);
                    spYear.setDisable(true);
                    spMonth.setDisable(true);
                    fromDate.setDisable(false);
                    toDate.setDisable(false);
                    cmbGrade.setDisable(true);
                    cmbSubject.setDisable(true);
                    btnGenerateReport.setDisable(false);
                    cmbTeacherGrade.setDisable(true);
                    date.setDisable(true);
                } else if (newValue.equalsIgnoreCase("Total Teacher Salary Report")) {
                    fromDate.setValue(null);
                    toDate.setValue(null);
                    date.setValue(null);
                    cmbIncomeReportsGrade.getSelectionModel().clearSelection();
                    cmbIncomeReportsGrade.setDisable(true);
                    cmbStudent.setDisable(true);
                    cmbTeacher.setDisable(true);
                    cmbEmployee.setDisable(true);
                    txtSearchStudentId.setDisable(true);
                    cmbTeacherName.setDisable(true);
                    txtStudentName.setDisable(true);
                    cmbEmployeeName.setDisable(true);
                    spYear.setDisable(true);
                    spMonth.setDisable(true);
                    fromDate.setDisable(false);
                    toDate.setDisable(false);
                    cmbGrade.setDisable(true);
                    cmbSubject.setDisable(true);
                    btnGenerateReport.setDisable(false);
                    cmbTeacherGrade.setDisable(true);
                    date.setDisable(true);
                } else if (newValue.equalsIgnoreCase("Total Employee Salary Report")) {
                    fromDate.setValue(null);
                    toDate.setValue(null);
                    date.setValue(null);
                    cmbIncomeReportsGrade.getSelectionModel().clearSelection();
                    cmbIncomeReportsGrade.setDisable(true);
                    cmbStudent.setDisable(true);
                    cmbTeacher.setDisable(true);
                    cmbEmployee.setDisable(true);
                    txtSearchStudentId.setDisable(true);
                    cmbTeacherName.setDisable(true);
                    txtStudentName.setDisable(true);
                    cmbEmployeeName.setDisable(true);
                    spYear.setDisable(true);
                    spMonth.setDisable(true);
                    fromDate.setDisable(false);
                    toDate.setDisable(false);
                    cmbGrade.setDisable(true);
                    cmbSubject.setDisable(true);
                    btnGenerateReport.setDisable(false);
                    cmbTeacherGrade.setDisable(true);
                    date.setDisable(true);
                } else if (newValue.equalsIgnoreCase("Total Expenses Report")) {
                    fromDate.setValue(null);
                    toDate.setValue(null);
                    date.setValue(null);
                    cmbIncomeReportsGrade.getSelectionModel().clearSelection();
                    cmbIncomeReportsGrade.setDisable(true);
                    cmbStudent.setDisable(true);
                    cmbTeacher.setDisable(true);
                    cmbEmployee.setDisable(true);
                    txtSearchStudentId.setDisable(true);
                    cmbTeacherName.setDisable(true);
                    txtStudentName.setDisable(true);
                    cmbEmployeeName.setDisable(true);
                    spYear.setDisable(true);
                    spMonth.setDisable(true);
                    fromDate.setDisable(false);
                    toDate.setDisable(false);
                    cmbGrade.setDisable(true);
                    cmbSubject.setDisable(true);
                    btnGenerateReport.setDisable(false);
                    cmbTeacherGrade.setDisable(true);
                    date.setDisable(true);
                }
            }
        });
    }

    private void clearAllComponents() {
        cmbIncomeReportsGrade.getSelectionModel().clearSelection();
        date.setValue(null);
        cmbStudent.getSelectionModel().clearSelection();
        txtSearchStudentId.clear();
        txtStudentName.clear();
        cmbSubject.getItems().clear();
        cmbGrade.getSelectionModel().clearSelection();
        cmbTeacherGrade.getSelectionModel().clearSelection();
        fromDate.setValue(null);
        toDate.setValue(null);
        cmbTeacher.getSelectionModel().clearSelection();
        cmbTeacherName.getSelectionModel().clearSelection();
        cmbEmployeeName.getSelectionModel().clearSelection();
        cmbEmployee.getSelectionModel().clearSelection();
        cmbIncomeReports.getSelectionModel().clearSelection();
    }

    private void loadEmployeeNames() {
        try {
            List<String> employeeNames = new EmployeeController().getEmployeeNames();
            cmbEmployeeName.getItems().addAll(employeeNames);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void loadTeacherNames() {
        try {
            List<String> teacherNames = new TeacherController().getTeacherNames();
            cmbTeacherName.getItems().addAll(teacherNames);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void disableComponents() {
        cmbIncomeReportsGrade.setDisable(true);
        date.setDisable(true);
        cmbTeacherGrade.setDisable(true);
        cmbStudent.setDisable(true);
        cmbTeacher.setDisable(true);
        cmbEmployee.setDisable(true);
        cmbIncomeReports.setDisable(true);
        txtSearchStudentId.setDisable(true);
        cmbTeacherName.setDisable(true);
        txtStudentName.setDisable(true);
        cmbEmployeeName.setDisable(true);
        spYear.setDisable(true);
        spMonth.setDisable(true);
        fromDate.setDisable(true);
        toDate.setDisable(true);
        cmbGrade.setDisable(true);
        cmbSubject.setDisable(true);
        btnGenerateReport.setDisable(true);
    }

    public void generateReportsOnAction(ActionEvent actionEvent) {
        RadioButton selectedButton = (RadioButton) tgReports.getSelectedToggle();
        if (selectedButton.getText().equalsIgnoreCase("Student")) {
            if (cmbStudent.getValue().equalsIgnoreCase("Student Wise Payment Report")) {
                if (!txtSearchStudentId.getText().isEmpty() && !txtStudentName.getText().isEmpty() && !cmbSubject.getSelectionModel().isEmpty() && fromDate.getValue() != null && toDate.getValue() != null) {
                    try {
                        String Id = txtSearchStudentId.getText();
                        String name = txtStudentName.getText();
                        String subject = cmbSubject.getValue();
                        String fDate = String.valueOf(fromDate.getValue());
                        String tDate = String.valueOf(toDate.getValue());

                        HashMap map = new HashMap();
                        map.put("searchId", Id);
                        map.put("searchName", name);
                        map.put("searchSub", subject);
                        map.put("fromDate", fDate);
                        map.put("toDate", tDate);

                        JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/StudentWisePayments.jrxml"));
                        JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                        JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, DbConnection.getInstance().getConnection());
                        JasperViewer.viewReport(jasperPrint, false);

                        txtSearchStudentId.clear();
                        txtStudentName.clear();
                        cmbSubject.getItems().clear();
                        cmbGrade.getSelectionModel().clearSelection();
                        fromDate.setValue(null);
                        toDate.setValue(null);

                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (JRException e) {
                        e.printStackTrace();
                    }
                } else {
                    Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please fill all the fields");
                    warning.showWarning();
                }
            } else if (cmbStudent.getValue().equalsIgnoreCase("Student Wise Evaluation Marks")) {
                if (!txtSearchStudentId.getText().isEmpty() && !txtStudentName.getText().isEmpty() && !cmbSubject.getSelectionModel().isEmpty() && fromDate.getValue() != null && toDate.getValue() != null) {
                    try {
                        String studentId = txtSearchStudentId.getText();
                        String studentName = txtStudentName.getText();
                        String subjectName = cmbSubject.getSelectionModel().getSelectedItem();
                        String fDate = String.valueOf(fromDate.getValue());
                        String tDate = String.valueOf(toDate.getValue());

                        HashMap map = new HashMap();
                        map.put("studentId", studentId);
                        map.put("studentName", studentName);
                        map.put("subject", subjectName);
                        map.put("fDate", fDate);
                        map.put("tDate", tDate);

                        JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/StudentWiseEvaluationMarks.jrxml"));
                        JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                        JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, DbConnection.getInstance().getConnection());
                        JasperViewer.viewReport(jasperPrint, false);

                        txtSearchStudentId.clear();
                        txtStudentName.clear();
                        cmbSubject.getItems().clear();
                        cmbGrade.getSelectionModel().clearSelection();
                        fromDate.setValue(null);
                        toDate.setValue(null);

                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (JRException e) {
                        e.printStackTrace();
                    }
                } else {
                    Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please fill all the fields");
                    warning.showWarning();
                }
            } else if (cmbStudent.getValue().equalsIgnoreCase("Student Wise Attendance Report")) {
                if (!txtSearchStudentId.getText().isEmpty() && !txtStudentName.getText().isEmpty() && !cmbSubject.getSelectionModel().isEmpty() && fromDate.getValue() != null && toDate.getValue() != null) {
                    try {
                        String studentId = txtSearchStudentId.getText();
                        String studentName = txtStudentName.getText();
                        String subjectName = cmbSubject.getSelectionModel().getSelectedItem();
                        String fDate = String.valueOf(fromDate.getValue());
                        String tDate = String.valueOf(toDate.getValue());

                        HashMap map = new HashMap();
                        map.put("sId", studentId);
                        map.put("sName", studentName);
                        map.put("subjectName", subjectName);
                        map.put("fromDate", fDate);
                        map.put("toDate", tDate);

                        JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/StudentWiseAttendance.jrxml"));
                        JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                        JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, DbConnection.getInstance().getConnection());
                        JasperViewer.viewReport(jasperPrint, false);

                        txtSearchStudentId.clear();
                        txtStudentName.clear();
                        cmbSubject.getItems().clear();
                        cmbGrade.getSelectionModel().clearSelection();
                        fromDate.setValue(null);
                        toDate.setValue(null);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (JRException e) {
                        e.printStackTrace();
                    }
                } else {
                    Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please fill all the fields");
                    warning.showWarning();
                }
            } else if (cmbStudent.getValue().equalsIgnoreCase("Grade Wise Student Evaluation Marks")) {
                if (!cmbSubject.getSelectionModel().isEmpty() && !cmbGrade.getSelectionModel().isEmpty() && fromDate.getValue() != null && toDate.getValue() != null) {
                    try {
                        String subject = cmbSubject.getValue();
                        int grade = cmbGrade.getValue();
                        String fDate = String.valueOf(fromDate.getValue());
                        String tDate = String.valueOf(toDate.getValue());

                        HashMap map = new HashMap();
                        map.put("subject", subject);
                        map.put("grade", grade);
                        map.put("fromDate", fDate);
                        map.put("toDate", tDate);

                        JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/GradeWiseStudentMarks.jrxml"));
                        JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                        JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, DbConnection.getInstance().getConnection());
                        JasperViewer.viewReport(jasperPrint, false);

                        cmbSubject.getSelectionModel().clearSelection();
                        cmbGrade.getSelectionModel().clearSelection();
                        fromDate.setValue(null);
                        toDate.setValue(null);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (JRException e) {
                        e.printStackTrace();
                    }
                } else {
                    Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please fill all the fields");
                    warning.showWarning();
                }
            } else if (cmbStudent.getValue().equalsIgnoreCase("Unpaid Students in Current Month")) {
                try {
                    JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/CurrentMonthUnPaidStudents.jrxml"));
                    JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                    JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, null, DbConnection.getInstance().getConnection());
                    JasperViewer.viewReport(jasperPrint, false);
                } catch (JRException e) {
                    e.printStackTrace();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }
        if (selectedButton.getText().equalsIgnoreCase("Teacher")) {
            if (cmbTeacher.getValue().equalsIgnoreCase("Teacher Wise Students Report")) {
                if (!cmbTeacherName.getSelectionModel().isEmpty() && !cmbTeacherGrade.getSelectionModel().isEmpty()) {
                    try {
                        String teacherName = cmbTeacherName.getValue();
                        int grade = cmbTeacherGrade.getValue();

                        HashMap map = new HashMap();
                        map.put("teacherName", teacherName);
                        map.put("grade", grade);

                        JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/TeacherWiseStudents.jrxml"));
                        JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                        JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, DbConnection.getInstance().getConnection());
                        JasperViewer.viewReport(jasperPrint, false);

                        cmbTeacherName.getSelectionModel().clearSelection();
                        cmbTeacherGrade.getSelectionModel().clearSelection();

                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (JRException e) {
                        e.printStackTrace();
                    }
                } else {
                    Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please fill all the fields");
                    warning.showWarning();
                }
            } else if (cmbTeacher.getValue().equalsIgnoreCase("Teacher Wise Evaluation Marks")) {
                if (!cmbTeacherName.getSelectionModel().isEmpty() && !cmbTeacherGrade.getSelectionModel().isEmpty() && fromDate != null && toDate != null) {
                    try {
                        String teacherName = cmbTeacherName.getValue();
                        int grade = cmbTeacherGrade.getValue();
                        String fDate = String.valueOf(fromDate.getValue());
                        String tDate = String.valueOf(toDate.getValue());

                        HashMap map = new HashMap();
                        map.put("teacherName", teacherName);
                        map.put("grade", grade);
                        map.put("fromDate", fDate);
                        map.put("toDate", tDate);

                        JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/TeacherWiseEvaluationMark.jrxml"));
                        JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                        JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, DbConnection.getInstance().getConnection());
                        JasperViewer.viewReport(jasperPrint, false);

                        cmbTeacherName.getSelectionModel().clearSelection();
                        cmbTeacherGrade.getSelectionModel().clearSelection();
                        fromDate.setValue(null);
                        toDate.setValue(null);

                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (JRException e) {
                        e.printStackTrace();
                    }
                } else {
                    Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please fill all the fields");
                    warning.showWarning();
                }
            } else if (cmbTeacher.getValue().equalsIgnoreCase("Teacher Wise Time Table")) {
                if (!cmbTeacherName.getSelectionModel().isEmpty() && fromDate.getValue() != null && toDate.getValue() != null) {
                    try {
                        String teacherName = cmbTeacherName.getValue();
                        String fDate = String.valueOf(fromDate.getValue());
                        String tDate = String.valueOf(toDate.getValue());

                        HashMap map = new HashMap();
                        map.put("teacherName", teacherName);
                        map.put("fromDate", fDate);
                        map.put("toDate", tDate);

                        JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/TeacherWiseTimeTable.jrxml"));
                        JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                        JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, DbConnection.getInstance().getConnection());
                        JasperViewer.viewReport(jasperPrint, false);

                        cmbTeacherName.getSelectionModel().clearSelection();
                        fromDate.setValue(null);
                        toDate.setValue(null);

                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (JRException e) {
                        e.printStackTrace();
                    }
                } else {
                    Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please fill all the fields");
                    warning.showWarning();
                }
            } else if (cmbTeacher.getValue().equalsIgnoreCase("Teacher Salary Report")) {
                if (!cmbTeacherName.getSelectionModel().isEmpty() && fromDate.getValue() != null && toDate.getValue() != null) {
                    try {
                        String teacherName = cmbTeacherName.getValue();
                        String fDate = String.valueOf(fromDate.getValue());
                        String tDate = String.valueOf(toDate.getValue());

                        HashMap map = new HashMap();
                        map.put("teacherName", teacherName);
                        map.put("fromDate", fDate);
                        map.put("toDate", tDate);

                        JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/TeacherSalaryReport.jrxml"));
                        JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                        JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, DbConnection.getInstance().getConnection());
                        JasperViewer.viewReport(jasperPrint, false);

                        cmbTeacherName.getSelectionModel().clearSelection();
                        fromDate.setValue(null);
                        toDate.setValue(null);

                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (JRException e) {
                        e.printStackTrace();
                    }
                } else {
                    Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please fill all the fields");
                    warning.showWarning();
                }
            } else if (cmbTeacher.getValue().equalsIgnoreCase("Teacher Wise Pay Slip")) {
                if (!cmbTeacherName.getSelectionModel().isEmpty()) {
                    try {
                        String teacherName = cmbTeacherName.getValue();
                        String subject = new TeacherController().getSubject(cmbTeacherName.getValue());
                        int year = spYear.getValue();
                        String month = spMonth.getValue();

                        HashMap map = new HashMap();
                        map.put("teacherName", teacherName);
                        map.put("subject", subject);
                        map.put("year", year);
                        map.put("month", month);

                        JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/TeacherWisePaySlip.jrxml"));
                        JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                        JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, DbConnection.getInstance().getConnection());
                        JasperViewer.viewReport(jasperPrint, false);

                        cmbTeacherName.getSelectionModel().clearSelection();

                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (JRException e) {
                        e.printStackTrace();
                    }
                } else {
                    Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please fill all the fields");
                    warning.showWarning();
                }
            }
        }
        if (selectedButton.getText().equalsIgnoreCase("Employee")) {
            if (cmbEmployee.getValue().equalsIgnoreCase("Employee Details Report")) {
                if (!cmbEmployeeName.getSelectionModel().isEmpty()) {
                    try {
                        String employeeName = cmbEmployeeName.getValue();

                        HashMap map = new HashMap();
                        map.put("name", employeeName);

                        JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/EmployeeDetailsReport.jrxml"));
                        JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                        JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, DbConnection.getInstance().getConnection());
                        JasperViewer.viewReport(jasperPrint, false);

                        cmbEmployeeName.getSelectionModel().clearSelection();

                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (JRException e) {
                        e.printStackTrace();
                    }
                } else {
                    Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please fill all the fields");
                    warning.showWarning();
                }
            } else if (cmbEmployee.getValue().equalsIgnoreCase("Employee Salary Report")) {
                if (!cmbEmployeeName.getSelectionModel().isEmpty() && fromDate.getValue() != null && toDate.getValue() != null) {
                    try {
                        String employeeName = cmbEmployeeName.getValue();
                        String fDate = String.valueOf(fromDate.getValue());
                        String tDate = String.valueOf(toDate.getValue());

                        HashMap map = new HashMap();
                        map.put("name", employeeName);
                        map.put("fromDate", fDate);
                        map.put("toDate", tDate);

                        JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/EmployeeSalaryReport.jrxml"));
                        JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                        JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, DbConnection.getInstance().getConnection());
                        JasperViewer.viewReport(jasperPrint, false);

                        cmbEmployeeName.getSelectionModel().clearSelection();
                        fromDate.setValue(null);
                        toDate.setValue(null);

                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (JRException e) {
                        e.printStackTrace();
                    }

                } else {
                    Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please fill all the fields");
                    warning.showWarning();
                }
            } else if (cmbEmployee.getValue().equalsIgnoreCase("Employee Wise Pay Slip")) {
                if (!cmbEmployeeName.getSelectionModel().isEmpty()) {
                    try {
                        String name = cmbEmployeeName.getValue();
                        String jobRole = new EmployeeController().getJobRole(cmbEmployeeName.getValue());
                        int year = spYear.getValue();
                        String month = spMonth.getValue();

                        HashMap map = new HashMap();
                        map.put("name", name);
                        map.put("jobRole", jobRole);
                        map.put("year", year);
                        map.put("month", month);

                        JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/EmployeeWisePaySlip.jrxml"));
                        JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                        JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, DbConnection.getInstance().getConnection());
                        JasperViewer.viewReport(jasperPrint, false);

                        cmbEmployeeName.getSelectionModel().clearSelection();

                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (JRException e) {
                        e.printStackTrace();
                    }
                } else {
                    Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please fill all the fields");
                    warning.showWarning();
                }
            }
        }
        if (selectedButton.getText().equalsIgnoreCase("Income Reports")) {
            if (cmbIncomeReports.getValue().equalsIgnoreCase("Daily Income Report")) {
                if (date.getValue() != null) {
                    try {
                        NumberFormat nf = NumberFormat.getInstance();
                        nf.setMinimumFractionDigits(2);
                        String day = String.valueOf(date.getValue());

                        double registrationFee = new StudentController().getRegistrationFees(day);
                        double paymentCash = new PaymentController().getPaymentCash(day);
                        double expenses = new ExpensesController().getAllCash(day);
                        double income = registrationFee + paymentCash;
                        double netIncome = income - expenses;

                        String regFee = nf.format(registrationFee);
                        String classFees = nf.format(paymentCash);
                        String expense = nf.format(expenses);
                        String total = nf.format(income);
                        String netTotal = nf.format(netIncome);

                        HashMap map = new HashMap();
                        map.put("date", day);
                        map.put("registrationFee", regFee);
                        map.put("payments", classFees);
                        map.put("grossIncome", total);
                        map.put("expenses", expense);
                        map.put("netIncome", netTotal);

                        JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/DailyCashReport.jrxml"));
                        JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                        JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, new JREmptyDataSource(1));
                        JasperViewer.viewReport(jasperPrint, false);

                        date.setValue(null);

                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (JRException e) {
                        e.printStackTrace();
                    }

                } else {
                    Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please fill all the fields");
                    warning.showWarning();
                }
            } else if (cmbIncomeReports.getValue().equalsIgnoreCase("Monthly Income Report")) {
                try {
                    NumberFormat nf = NumberFormat.getInstance();
                    nf.setMinimumFractionDigits(2);
                    int year = spYear.getValue();
                    String month = spMonth.getValue();

                    double registrationFee = new StudentController().getRegistrationCash(year, month);
                    double paymentCash = new PaymentController().getTotalPayment(year, month);
                    double expenses = new ExpensesController().getExpenses(year, month);
                    double teacherSalary = new TeacherController().getTotalSalary(year, month);
                    double employeeSalary = new EmployeeController().getTotalSalary(year, month);
                    double income = registrationFee + paymentCash;
                    double netIncome = income - (teacherSalary + employeeSalary + expenses);

                    String regFee = nf.format(registrationFee);
                    String payment = nf.format(paymentCash);
                    String expense = nf.format(expenses);
                    String tSalary = nf.format(teacherSalary);
                    String eSalary = nf.format(employeeSalary);
                    String grossIncome = nf.format(income);
                    String totalIncome = nf.format(netIncome);

                    HashMap map = new HashMap();
                    map.put("year", year);
                    map.put("month", month);
                    map.put("registrationFee", regFee);
                    map.put("payments", payment);
                    map.put("grossIncome", grossIncome);
                    map.put("teacherSalary", tSalary);
                    map.put("employeeSalary", eSalary);
                    map.put("expenses", expense);
                    map.put("netIncome", totalIncome);

                    JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/MonthlyIncomeReport.jrxml"));
                    JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                    JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, new JREmptyDataSource(1));
                    JasperViewer.viewReport(jasperPrint, false);


                } catch (SQLException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } catch (JRException e) {
                    e.printStackTrace();
                }
            } else if (cmbIncomeReports.getValue().equalsIgnoreCase("Annual Income Report")) {
                try {
                    NumberFormat nf = NumberFormat.getInstance();
                    nf.setMinimumFractionDigits(2);
                    int year = spYear.getValue();

                    double registrationFees = new StudentController().getAnnualRegistrationFee(year);
                    double paymentCash = new PaymentController().getAnnualPayments(year);
                    double expenses = new ExpensesController().getAnnualExpenses(year);
                    double teacherSalary = new TeacherController().getAnnualTeacherSalary(year);
                    double employeeSalary = new EmployeeController().getAnnualEmployeeSalary(year);
                    double income = registrationFees + paymentCash;
                    double netIncome = income - (teacherSalary + employeeSalary + expenses);

                    String regFee = nf.format(registrationFees);
                    String payment = nf.format(paymentCash);
                    String expense = nf.format(expenses);
                    String tSalary = nf.format(teacherSalary);
                    String eSalary = nf.format(employeeSalary);
                    String grossIncome = nf.format(income);
                    String totalIncome = nf.format(netIncome);

                    HashMap map = new HashMap();
                    map.put("year", year);
                    map.put("registrationFee", regFee);
                    map.put("payments", payment);
                    map.put("grossIncome", grossIncome);
                    map.put("teacherSalary", tSalary);
                    map.put("employeeSalary", eSalary);
                    map.put("expenses", expense);
                    map.put("netIncome", totalIncome);

                    JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/AnnualIncomeReport.jrxml"));
                    JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                    JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, new JREmptyDataSource(1));
                    JasperViewer.viewReport(jasperPrint, false);


                } catch (SQLException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } catch (JRException e) {
                    e.printStackTrace();
                }
            } else if (cmbIncomeReports.getValue().equalsIgnoreCase("Grade Wise Student Payments")) {
                if (!cmbIncomeReportsGrade.getSelectionModel().isEmpty() && fromDate.getValue() != null && toDate.getValue() != null) {
                    try {
                        NumberFormat nf = NumberFormat.getInstance();
                        nf.setMinimumFractionDigits(2);

                        int grade = cmbIncomeReportsGrade.getValue();
                        String fDate = String.valueOf(fromDate.getValue());
                        String tDate = String.valueOf(toDate.getValue());
                        double totalPayments = new PaymentController().getSumOfPayments(grade, fDate, tDate);
                        String sumOfPayments = nf.format(totalPayments);

                        HashMap map = new HashMap();
                        map.put("grade", grade);
                        map.put("fromDate", fDate);
                        map.put("toDate", tDate);
                        map.put("totalPayments", sumOfPayments);

                        JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/GradeWiseStudentPayments.jrxml"));
                        JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                        JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, DbConnection.getInstance().getConnection());
                        JasperViewer.viewReport(jasperPrint, false);


                        cmbIncomeReportsGrade.getSelectionModel().clearSelection();
                        fromDate.setValue(null);
                        toDate.setValue(null);

                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (JRException e) {
                        e.printStackTrace();
                    }
                } else {
                    Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please fill all the fields");
                    warning.showWarning();
                }
            } else if (cmbIncomeReports.getValue().equalsIgnoreCase("Total Teacher Salary Report")) {
                if (fromDate.getValue() != null && toDate.getValue() != null) {
                    try {
                        NumberFormat nf = NumberFormat.getInstance();
                        nf.setMinimumFractionDigits(2);

                        String fDate = String.valueOf(fromDate.getValue());
                        String tDate = String.valueOf(toDate.getValue());
                        double totalSalary = new TeacherController().getSumOfSalary(fDate, tDate);

                        String tSalary = nf.format(totalSalary);

                        HashMap map = new HashMap();
                        map.put("fromDate", fDate);
                        map.put("toDate", tDate);
                        map.put("totalSalary", tSalary);

                        JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/TotalTeacherSalaryReport.jrxml"));
                        JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                        JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, DbConnection.getInstance().getConnection());
                        JasperViewer.viewReport(jasperPrint, false);


                        fromDate.setValue(null);
                        toDate.setValue(null);

                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (JRException e) {
                        e.printStackTrace();
                    }
                } else {
                    Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please fill all the fields");
                    warning.showWarning();
                }
            } else if (cmbIncomeReports.getValue().equalsIgnoreCase("Total Employee Salary Report")) {
                if (fromDate.getValue() != null && toDate.getValue() != null) {
                    try {
                        NumberFormat nf = NumberFormat.getInstance();
                        nf.setMinimumFractionDigits(2);

                        String fDate = String.valueOf(fromDate.getValue());
                        String tDate = String.valueOf(toDate.getValue());
                        double totalSalary = new EmployeeController().getSumOfSalary(fDate, tDate);

                        String tSalary = nf.format(totalSalary);

                        HashMap map = new HashMap();
                        map.put("fromDate", fDate);
                        map.put("toDate", tDate);
                        map.put("totalSalary", tSalary);

                        JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/TotalEmployeeSalaryReport.jrxml"));
                        JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                        JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, DbConnection.getInstance().getConnection());
                        JasperViewer.viewReport(jasperPrint, false);

                        fromDate.setValue(null);
                        toDate.setValue(null);

                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (JRException e) {
                        e.printStackTrace();
                    }

                } else {
                    Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please fill all the fields");
                    warning.showWarning();
                }
            } else if (cmbIncomeReports.getValue().equalsIgnoreCase("Total Expenses Report")) {
                if (fromDate.getValue() != null && toDate.getValue() != null) {
                    try {
                        NumberFormat nf = NumberFormat.getInstance();
                        nf.setMinimumFractionDigits(2);

                        String fDate = String.valueOf(fromDate.getValue());
                        String tDate = String.valueOf(toDate.getValue());
                        double totalExpenses = new ExpensesController().getTotalExpenses(fDate, tDate);

                        String tExpenses = nf.format(totalExpenses);

                        HashMap map = new HashMap();
                        map.put("fromDate", fDate);
                        map.put("toDate", tDate);
                        map.put("totalExpenses", tExpenses);

                        JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/TotalExpensesReport.jrxml"));
                        JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                        JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, DbConnection.getInstance().getConnection());
                        JasperViewer.viewReport(jasperPrint, false);

                        fromDate.setValue(null);
                        toDate.setValue(null);

                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (JRException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    public void searchStudentNamesOnAction(ActionEvent actionEvent) {
        try {
            cmbSubject.getItems().clear();
            Student student = new StudentController().getStudent(txtSearchStudentId.getText());
            if (student == null) {
                Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Student not found.try again");
                warning.showWarning();
            } else {
                txtStudentName.setText(student.getStudentName());

                String subject = student.getSubjectName();
                String[] subjects = subject.split("[,]");
                cmbSubject.getItems().addAll(subjects);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
}
