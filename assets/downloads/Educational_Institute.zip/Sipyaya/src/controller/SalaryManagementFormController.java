package controller;

import Notification.NotificationBuilder;
import Validation.ValidationUtil;
import com.jfoenix.controls.JFXButton;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import model.EmployeeSalary;
import model.TeacherSalary;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
import org.controlsfx.control.Notifications;
import view.TM.EmployeeSalaryTM;
import view.TM.TeacherSalaryTM;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;

public class SalaryManagementFormController {
    public TableView<EmployeeSalaryTM> tblEmployeeSalary;
    public TableView<TeacherSalaryTM> tblTeacherSalary;
    public ComboBox<String> cmbDesignation;
    public ComboBox<String> cmbName;
    public TextField txtSubject;
    public Spinner<Integer> spYear;
    public Spinner<String> spMonth;
    public TextField txtWorkingDays;
    public TextField txtSalaryPerDay;
    public TextField txtAllowances;
    public TextField txtEmployeeDeductions;
    public TextField txtTotalEmployeeSalary;
    public JFXButton btnCreateEmployeePayroll;
    public JFXButton btnCreateTeacherPayroll;
    public TextField txtTotalClassFees;
    public TextField txtTeacherDeductions;
    public TextField txtTeacherTotalSalary;
    public TextField txtPercentage;
    public Label lblType;
    public TableColumn colTeacherName;
    public TableColumn colTeacherSalaryDate;
    public TableColumn colTeacherSalaryMonth;
    public TableColumn colTotalClassFees;
    public TableColumn colTeacherNetSalary;
    public TableColumn colEmployeeName;
    public TableColumn colJobRole;
    public TableColumn colWorkingDays;
    public TableColumn colSalaryPerDay;
    public TableColumn colMonth;
    public TableColumn colEmployeeDate;
    public TableColumn colEmployeeNetSalary;
    public Spinner<Integer> spSearchTeacherYear;
    public Spinner<String> spSearchTeacherMonth;
    public TextField txtTeacherNetSalary;
    public Spinner<Integer> spSearchEmployeeYear;
    public Spinner<String> spSearchEmployeeMonth;
    public TextField txtEmployeeNetSalary;

    LinkedHashMap<TextField, Pattern> employeeMap = new LinkedHashMap<>();
    LinkedHashMap<TextField, Pattern> teacherMap = new LinkedHashMap<>();
    Pattern workingDaysPattern = Pattern.compile("^[1-9][0-9]?$");
    Pattern salaryPerDayPattern = Pattern.compile("^[1-9][0-9]*([.][0-9])?$");
    Pattern allowancePattern = Pattern.compile("^[0-9][0-9]*([.][0-9])?$");
    Pattern employeeDeductionPattern = Pattern.compile("^[0-9][0-9]*([.][0-9])?$");
    Pattern teacherDeductionPattern = Pattern.compile("^[0-9][0-9]*([.][0-9])?$");

    public void initialize() {
        storeEmployeeValidations();
        storeTeacherValidations();
        disableAllFields();
        cmbDesignation.getItems().addAll("Teacher", "Employee");

        try {
            loadTeacherSalaryToTable(new TeacherController().getAllTeacherSalary());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        try {
            loadEmployeeSalaryToTable(new EmployeeController().getAllEmployeeSalary());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


        SpinnerValueFactory<Integer> employeeYearValues = new SpinnerValueFactory.IntegerSpinnerValueFactory(2021, 2099, 2021);
        spSearchEmployeeYear.setValueFactory(employeeYearValues);

        ObservableList<String> employeeMonths = FXCollections.observableArrayList();
        employeeMonths.addAll("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
        SpinnerValueFactory<String> employeeMonthValues = new SpinnerValueFactory.ListSpinnerValueFactory<>(employeeMonths);
        spSearchEmployeeMonth.setValueFactory(employeeMonthValues);

        SpinnerValueFactory<Integer> teacherYearValues = new SpinnerValueFactory.IntegerSpinnerValueFactory(2021, 2099, 2021);
        spSearchTeacherYear.setValueFactory(teacherYearValues);

        ObservableList<String> teacherMonths = FXCollections.observableArrayList();
        teacherMonths.addAll("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
        SpinnerValueFactory<String> teacherMonthValues = new SpinnerValueFactory.ListSpinnerValueFactory<>(teacherMonths);
        spSearchTeacherMonth.setValueFactory(teacherMonthValues);

        SpinnerValueFactory<Integer> yearValues = new SpinnerValueFactory.IntegerSpinnerValueFactory(2021, 2099);
        spYear.setValueFactory(yearValues);

        ObservableList<String> months = FXCollections.observableArrayList();
        months.addAll("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
        SpinnerValueFactory<String> monthValues = new SpinnerValueFactory.ListSpinnerValueFactory<>(months);
        spMonth.setValueFactory(monthValues);

        cmbDesignation.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            txtTeacherTotalSalary.clear();
            txtTotalClassFees.clear();
            txtTotalEmployeeSalary.clear();
            txtTeacherDeductions.clear();
            txtAllowances.clear();
            txtEmployeeDeductions.clear();
            txtSalaryPerDay.clear();
            txtWorkingDays.clear();
            txtSubject.clear();
            if (newValue != null && newValue.equalsIgnoreCase("Teacher")) {
                searchTeacherNames();
                disableFieldsInTeacher();
                lblType.setText("Subject");
            } else if (newValue != null && newValue.equalsIgnoreCase("Employee")) {
                searchEmployeeNames();
                disableFieldsInEmployee();
                lblType.setText("Job Role");
            }
        });
        cmbName.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (cmbDesignation.getValue().equalsIgnoreCase("Teacher") && newValue != null) {
                txtTotalClassFees.clear();
                txtTeacherDeductions.clear();
                txtTeacherTotalSalary.clear();
                SearchSubject(newValue);
            } else if (newValue != null) {
                txtTotalClassFees.clear();
                txtTeacherDeductions.clear();
                txtTeacherTotalSalary.clear();
                txtSubject.clear();
                searchJobRole(newValue);
            }
        });

    }

    private void loadTeacherSalaryToTable(ArrayList<TeacherSalary> teacherSalaries) {
        ObservableList<TeacherSalaryTM> obList = FXCollections.observableArrayList();
        teacherSalaries.forEach(e -> {
            obList.add(new TeacherSalaryTM(e.getTeacherName(), e.getDate(), e.getMonth(), e.getTotalClassFees(), e.getNetSalary()));
        });
        tblTeacherSalary.setItems(obList);
        initTeacherTableCols();

    }

    private void loadEmployeeSalaryToTable(ArrayList<EmployeeSalary> employeeSalaries) {
        ObservableList<EmployeeSalaryTM> obList = FXCollections.observableArrayList();
        employeeSalaries.forEach(e -> {
            obList.add(new EmployeeSalaryTM(e.getEmployeeName(), e.getJobRole(), e.getWorkingDays(), e.getSalaryPerDay(), e.getMonth(), e.getDate(), e.getNetSalary()));
        });
        tblEmployeeSalary.setItems(obList);
        initEmployeeTableCols();
    }

    private void initEmployeeTableCols() {
        colEmployeeName.setCellValueFactory(new PropertyValueFactory<>("employeeName"));
        colJobRole.setCellValueFactory(new PropertyValueFactory<>("jobRole"));
        colWorkingDays.setCellValueFactory(new PropertyValueFactory<>("workingDays"));
        colSalaryPerDay.setCellValueFactory(new PropertyValueFactory<>("salaryPerDay"));
        colMonth.setCellValueFactory(new PropertyValueFactory<>("month"));
        colEmployeeDate.setCellValueFactory(new PropertyValueFactory<>("date"));
        colEmployeeNetSalary.setCellValueFactory(new PropertyValueFactory<>("netSalary"));

    }

    private void initTeacherTableCols() {
        colTeacherName.setCellValueFactory(new PropertyValueFactory<>("teacherName"));
        colTeacherSalaryDate.setCellValueFactory(new PropertyValueFactory<>("date"));
        colTeacherSalaryMonth.setCellValueFactory(new PropertyValueFactory<>("month"));
        colTotalClassFees.setCellValueFactory(new PropertyValueFactory<>("totalClassFees"));
        colTeacherNetSalary.setCellValueFactory(new PropertyValueFactory<>("netSalary"));
    }

    private void searchJobRole(String newValue) {
        try {
            new EmployeeController().getJobRole(newValue, txtSubject);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void storeEmployeeValidations() {
        employeeMap.put(txtWorkingDays, workingDaysPattern);
        employeeMap.put(txtSalaryPerDay, salaryPerDayPattern);
        employeeMap.put(txtAllowances, allowancePattern);
        employeeMap.put(txtEmployeeDeductions, employeeDeductionPattern);
    }

    private void storeTeacherValidations() {
        teacherMap.put(txtTeacherDeductions, teacherDeductionPattern);
    }

    private void SearchSubject(String newValue) {
        try {
            new TeacherController().getSubject(newValue, txtSubject);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void disableAllFields() {
        txtWorkingDays.setDisable(true);
        txtSalaryPerDay.setDisable(true);
        txtAllowances.setDisable(true);
        txtEmployeeDeductions.setDisable(true);
        txtTotalEmployeeSalary.setDisable(true);
        btnCreateEmployeePayroll.setDisable(true);
        txtTotalClassFees.setDisable(true);
        txtTeacherDeductions.setDisable(true);
        txtTeacherTotalSalary.setDisable(true);
        btnCreateTeacherPayroll.setDisable(true);
    }

    private void disableFieldsInEmployee() {
        txtWorkingDays.setDisable(false);
        txtSalaryPerDay.setDisable(false);
        txtAllowances.setDisable(false);
        txtEmployeeDeductions.setDisable(false);
        txtTotalEmployeeSalary.setDisable(false);
        btnCreateEmployeePayroll.setDisable(true);
        txtTotalClassFees.setDisable(true);
        txtTeacherDeductions.setDisable(true);
        txtTeacherTotalSalary.setDisable(true);
    }

    private void disableFieldsInTeacher() {
        txtWorkingDays.setDisable(true);
        txtSalaryPerDay.setDisable(true);
        txtAllowances.setDisable(true);
        txtEmployeeDeductions.setDisable(true);
        txtTotalEmployeeSalary.setDisable(true);
        btnCreateEmployeePayroll.setDisable(true);
        txtTotalClassFees.setDisable(false);
        txtTeacherDeductions.setDisable(false);
        txtTeacherTotalSalary.setDisable(false);
    }

    private void searchEmployeeNames() {
        try {
            cmbName.getItems().clear();
            List<String> employeeNames = new EmployeeController().getEmployeeNames();
            cmbName.getItems().addAll(employeeNames);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void searchTeacherNames() {
        try {
            cmbName.getItems().clear();
            List<String> teacherNames = new TeacherController().getTeacherNames();
            cmbName.getItems().addAll(teacherNames);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void searchTotalClassFeesOnAction(MouseEvent mouseEvent) {
        if (!cmbDesignation.getSelectionModel().isEmpty()) {
            if (cmbDesignation.getValue().equalsIgnoreCase("Teacher")) {
                if (!cmbName.getSelectionModel().isEmpty() && spYear.getValue() != 0 && spMonth.getValue() != null) {
                    try {
                        double totalClassFees = new PaymentController().getPayments(spMonth.getValue(), spYear.getValue(), cmbName.getSelectionModel().getSelectedItem());
                        txtTotalClassFees.setText(String.valueOf(totalClassFees));
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            } else {
                Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please select details and try again");
                warning.showWarning();
            }
        } else {
            Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please select details and try again");
            warning.showWarning();
        }
    }

    public void employeeFieldsValidation(KeyEvent keyEvent) {
        Object response = ValidationUtil.validateTextField(employeeMap, btnCreateEmployeePayroll);
        if (keyEvent.getCode() == KeyCode.ENTER) {
            if (response instanceof TextField) {
                TextField errorText = (TextField) response;
                errorText.requestFocus();
            } else if (response instanceof Boolean) {

            }
        }
    }

    public void teacherFieldsValidation(KeyEvent keyEvent) {
        Object response = ValidationUtil.validateTextField(teacherMap, btnCreateTeacherPayroll);
        if (keyEvent.getCode() == KeyCode.ENTER) {
            if (response instanceof TextField) {
                TextField errorText = (TextField) response;
                errorText.requestFocus();
            } else if (response instanceof Boolean) {

            }
        }
    }

    public void makeTeacherTotalSalaryOnAction(MouseEvent mouseEvent) {
        if (!txtTotalClassFees.getText().isEmpty() && !txtTeacherDeductions.getText().isEmpty()) {
            double totalClassFees = Double.parseDouble(txtTotalClassFees.getText());
            double teacherDeductions = Double.parseDouble(txtTeacherDeductions.getText());
            double percentage = Double.parseDouble(txtPercentage.getText());
            double teacherTotalSalary = (totalClassFees * percentage) - teacherDeductions;
            txtTeacherTotalSalary.setText(String.valueOf(teacherTotalSalary));
        } else {
            Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Fill all fields and try again");
            warning.showWarning();
        }
    }

    public void makeEmployeeTotalSalaryOnAction(MouseEvent mouseEvent) {
        if (cmbDesignation.getValue().equalsIgnoreCase("Employee") && !cmbName.getSelectionModel().isEmpty()) {
            if (!txtWorkingDays.getText().isEmpty() && !txtSalaryPerDay.getText().isEmpty() && !txtAllowances.getText().isEmpty() && !txtEmployeeDeductions.getText().isEmpty()) {
                int workingDays = Integer.parseInt(txtWorkingDays.getText());
                double salaryPerDay = Double.parseDouble(txtSalaryPerDay.getText());
                double allowances = Double.parseDouble(txtAllowances.getText());
                double employeeDeductions = Double.parseDouble(txtEmployeeDeductions.getText());
                double employeeSalary = (workingDays * salaryPerDay) + allowances - employeeDeductions;
                txtTotalEmployeeSalary.setText(String.valueOf(employeeSalary));
            } else {
                Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Fill all fields and try again");
                warning.showWarning();
            }
        } else {
            Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Fill all fields and try again");
            warning.showWarning();
        }
    }

    public void createEmployeePayrollOnAction(ActionEvent actionEvent) {
        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(new Date());
        if (!txtTotalEmployeeSalary.getText().isEmpty() && !cmbName.getSelectionModel().isEmpty()) {
            EmployeeSalary employeeSalary = new EmployeeSalary(cmbName.getValue(), txtSubject.getText(), spYear.getValue(), spMonth.getValue(), date, Integer.parseInt(txtWorkingDays.getText()), Double.parseDouble(txtSalaryPerDay.getText()), Double.parseDouble(txtAllowances.getText()), Double.parseDouble(txtEmployeeDeductions.getText()), Double.parseDouble(txtTotalEmployeeSalary.getText()));
            try {
                if (new EmployeeController().addEmployeeSalary(employeeSalary)) {
                    Notifications information = NotificationBuilder.notifyMassage("INFORMATION", "Salary saved successfully");
                    information.showInformation();

                    String designation = cmbDesignation.getValue();
                    String name = cmbName.getValue();
                    String jobRole = txtSubject.getText();
                    int year = spYear.getValue();
                    String month = spMonth.getValue();
                    int workingDays = Integer.parseInt(txtWorkingDays.getText());
                    double salaryPerDay = Double.parseDouble(txtSalaryPerDay.getText());
                    double allowances = Double.parseDouble(txtAllowances.getText());
                    double deductions = Double.parseDouble(txtEmployeeDeductions.getText());
                    double netSalary = Double.parseDouble(txtTotalEmployeeSalary.getText());

                    HashMap map = new HashMap();
                    map.put("employeeName", name);
                    map.put("designation", designation);
                    map.put("jobRole", jobRole);
                    map.put("year", year);
                    map.put("month", month);
                    map.put("workingDays", workingDays);
                    map.put("salaryPerDay", salaryPerDay);
                    map.put("allowances", allowances);
                    map.put("deductions", deductions);
                    map.put("netSalary", netSalary);

                    JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/EmployeePaySlip.jrxml"));
                    JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                    JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, new JREmptyDataSource(1));
                    JasperViewer.viewReport(jasperPrint, false);

                    loadEmployeeSalaryToTable(new EmployeeController().getAllEmployeeSalary());
                    txtWorkingDays.clear();
                    txtSalaryPerDay.clear();
                    txtAllowances.clear();
                    txtEmployeeDeductions.clear();
                    txtTotalEmployeeSalary.clear();
                    btnCreateEmployeePayroll.setDisable(true);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (JRException e) {
                e.printStackTrace();
            }
        } else {
            Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please generate total salary");
            warning.showWarning();
        }
    }

    public void createTeacherPayrollOnAction(ActionEvent actionEvent) {
        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(new Date());
        if (!txtTeacherTotalSalary.getText().isEmpty() && !cmbName.getSelectionModel().isEmpty()) {
            TeacherSalary teacherSalary = new TeacherSalary(cmbName.getSelectionModel().getSelectedItem(), spYear.getValue(), spMonth.getValue(), date, Double.parseDouble(txtTotalClassFees.getText()), Double.parseDouble(txtPercentage.getText()), Double.parseDouble(txtTeacherDeductions.getText()), Double.parseDouble(txtTeacherTotalSalary.getText()));
            try {
                if (new TeacherController().addTeacherSalary(teacherSalary)) {
                    Notifications information = NotificationBuilder.notifyMassage("INFORMATION", "Salary saved successfully");
                    information.showInformation();

                    String designation = cmbDesignation.getValue();
                    String name = cmbName.getValue();
                    String subjectName = txtSubject.getText();
                    int y = spYear.getValue();
                    String monthName = spMonth.getValue();
                    double totalClassFee = Double.parseDouble(txtTotalClassFees.getText());
                    double deductions = Double.parseDouble(txtTeacherDeductions.getText());
                    double totalSalary = Double.parseDouble(txtTeacherTotalSalary.getText());


                    HashMap salaryMap = new HashMap();
                    salaryMap.put("teacherName", name);
                    salaryMap.put("designate", designation);
                    salaryMap.put("subject", subjectName);
                    salaryMap.put("y", y);
                    salaryMap.put("monthName", monthName);
                    salaryMap.put("classFees", totalClassFee);
                    salaryMap.put("deduction", deductions);
                    salaryMap.put("teacherSalary", totalSalary);


                    JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/TeacherPaySlip.jrxml"));
                    JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                    JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, salaryMap, new JREmptyDataSource(1));
                    JasperViewer.viewReport(jasperPrint, false);


                    loadTeacherSalaryToTable(new TeacherController().getAllTeacherSalary());
                    txtTotalClassFees.clear();
                    txtTeacherDeductions.clear();
                    txtTeacherTotalSalary.clear();
                    btnCreateTeacherPayroll.setDisable(true);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (JRException e) {
                e.printStackTrace();
            }
        } else {
            Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please generate total salary");
            warning.showWarning();
        }
    }

    public void searchTeacherSalary(MouseEvent mouseEvent) {
        try {
            List<TeacherSalary> teacherSalaries = new TeacherController().searchTeacherSalary(spSearchTeacherYear.getValue(), spSearchTeacherMonth.getValue(), txtTeacherNetSalary);
            ObservableList<TeacherSalaryTM> obList = FXCollections.observableArrayList();
            teacherSalaries.forEach(e -> {
                obList.add(new TeacherSalaryTM(e.getTeacherName(), e.getDate(), e.getMonth(), e.getTotalClassFees(), e.getNetSalary()));
            });
            tblTeacherSalary.setItems(obList);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void searchEmployeeSalary(MouseEvent mouseEvent) {
        try {
            List<EmployeeSalary> employeeSalaries = new EmployeeController().searchEmployeeSalary(spSearchEmployeeYear.getValue(), spSearchEmployeeMonth.getValue(), txtEmployeeNetSalary);
            ObservableList<EmployeeSalaryTM> obList = FXCollections.observableArrayList();
            employeeSalaries.forEach(e -> {
                obList.add(new EmployeeSalaryTM(e.getEmployeeName(), e.getJobRole(), e.getWorkingDays(), e.getSalaryPerDay(), e.getMonth(), e.getDate(), e.getNetSalary()));
            });
            tblEmployeeSalary.setItems(obList);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void refreshEmployeeSalaryTable(ActionEvent actionEvent) {
        try {
            loadEmployeeSalaryToTable(new EmployeeController().getAllEmployeeSalary());
            txtEmployeeNetSalary.clear();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void deleteEmployeeSalaryOnAction(ActionEvent actionEvent) {
        EmployeeSalaryTM selectedItem = tblEmployeeSalary.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            Notifications warning = NotificationBuilder.notifyMassage("WARNING", "No data selected");
            warning.showWarning();
        } else {
            try {
                if (new EmployeeController().deleteEmployeeSalary(selectedItem)) {
                    Notifications information = NotificationBuilder.notifyMassage("INFORMATION", "Deleted successfully");
                    information.showInformation();
                    loadEmployeeSalaryToTable(new EmployeeController().getAllEmployeeSalary());
                    txtEmployeeNetSalary.clear();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    public void refreshTeacherSalaryTable(ActionEvent actionEvent) {
        try {
            loadTeacherSalaryToTable(new TeacherController().getAllTeacherSalary());
            txtTeacherNetSalary.clear();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void deleteTeacherSalaryOnAction(ActionEvent actionEvent) {
        TeacherSalaryTM selectedItem = tblTeacherSalary.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            Notifications warning = NotificationBuilder.notifyMassage("WARNING", "No data selected");
            warning.showWarning();
        } else {
            try {
                if (new TeacherController().deleteSalary(selectedItem)) {
                    Notifications information = NotificationBuilder.notifyMassage("INFORMATION", "Deleted successfully");
                    information.showInformation();
                    loadTeacherSalaryToTable(new TeacherController().getAllTeacherSalary());
                    txtTeacherNetSalary.clear();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
}
