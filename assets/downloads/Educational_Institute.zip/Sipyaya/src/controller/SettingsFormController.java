package controller;

import Notification.NotificationBuilder;
import Validation.ValidationUtil;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import javafx.event.ActionEvent;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import model.User;
import org.controlsfx.control.Notifications;

import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.LinkedHashMap;
import java.util.regex.Pattern;

public class SettingsFormController {

    public JFXComboBox<String> cmbUserType;
    public JFXButton btnRegisterUser;
    public TextField txtFirstName;
    public TextField txtLastName;
    public TextField txtUserName;
    public PasswordField txtPassword;
    public PasswordField txtConfirmPassword;

    LinkedHashMap<TextField, Pattern> map = new LinkedHashMap<>();
    Pattern firstNamePattern = Pattern.compile("^[A-z]{3,}$");
    Pattern lastNamePattern = Pattern.compile("^[A-z]{3,}$");
    Pattern userNamePattern = Pattern.compile("^[A-z0-9]{6,10}$");
    Pattern passwordPattern = Pattern.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{8,}$");
    Pattern confirmPasswordPattern = Pattern.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{8,}$");

    public void initialize() {
        btnRegisterUser.setDisable(true);
        storeValidation();
        cmbUserType.getItems().addAll("System User", "Admin");
    }

    private void storeValidation() {
        map.put(txtFirstName, firstNamePattern);
        map.put(txtLastName, lastNamePattern);
        map.put(txtUserName, userNamePattern);
        map.put(txtPassword, passwordPattern);
        map.put(txtConfirmPassword, confirmPasswordPattern);
    }

    public void textFieldValidationOnAction(KeyEvent keyEvent) {
        Object response = ValidationUtil.validateTextField(map, btnRegisterUser);
        if (keyEvent.getCode() == KeyCode.ENTER) {
            if (response instanceof TextField) {
                TextField errorText = (TextField) response;
                errorText.requestFocus();
            } else if (response instanceof Boolean) {
                Notifications confirmation = NotificationBuilder.notifyMassage("CONFIRMATION", "All the text fields are filled successfully.");
                confirmation.showConfirm();
            }
        }
    }

    public void registerUserOnAction(ActionEvent actionEvent) {
        if (txtPassword.getText().equals(txtConfirmPassword.getText())) {
            if (!cmbUserType.getSelectionModel().isEmpty()) {
                User user = new User(txtFirstName.getText(), txtLastName.getText(), txtUserName.getText(), txtPassword.getText(), cmbUserType.getSelectionModel().getSelectedItem());
                try {
                    if (UserController.signupUser(user)) {
                        txtFirstName.clear();
                        txtLastName.clear();
                        txtUserName.clear();
                        txtPassword.clear();
                        txtConfirmPassword.clear();
                        cmbUserType.getSelectionModel().clearSelection();
                        Notifications information = NotificationBuilder.notifyMassage("CONFIRMATION", "Saved Successfully");
                        information.showInformation();

                    } else {

                    }
                } catch (SQLIntegrityConstraintViolationException e) {
                    Notifications error = NotificationBuilder.notifyMassage("ERROR", "User name is exists.Please try again");
                    error.showError();
                } catch (SQLException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            } else {
                Notifications error = NotificationBuilder.notifyMassage("ERROR", "Please select a user type");
                error.showError();
            }
        } else {
            Notifications error = NotificationBuilder.notifyMassage("ERROR", "Password is not matched,Please try again");
            error.showError();
        }
    }
}
