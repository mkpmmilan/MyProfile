package controller;

import Database.DbConnection;
import controller.interfaces.StudentService;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import model.*;
import view.TM.EvaluationMarkTM;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class StudentController implements StudentService {
    @Override
    public String setStudentId() throws SQLException, ClassNotFoundException {
        ResultSet rst = DbConnection.getInstance().getConnection().prepareStatement("SELECT Sid FROM Student ORDER BY Sid DESC LIMIT 1").executeQuery();
        if (rst.next()) {
            int tempId = Integer.parseInt(rst.getString(1).split("-")[1]);
            tempId = tempId + 1;
            if (tempId <= 9) {
                return "S00-00" + tempId;
            } else if (tempId <= 99) {
                return "S00-0" + tempId;
            } else {
                return "S00-" + tempId;
            }
        } else {
            return "S00-001";
        }
    }

    @Override
    public boolean addStudent(Student student) {
        Connection connection = null;
        try {
            connection = DbConnection.getInstance().getConnection();
            connection.setAutoCommit(false);
            PreparedStatement stm = connection.prepareStatement("INSERT INTO Student VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            stm.setObject(1, student.getStudentId());
            stm.setObject(2, student.getSurname());
            stm.setObject(3, student.getStudentName());
            stm.setObject(4, student.getStudentEmail());
            stm.setObject(5, student.getAddress());
            stm.setObject(6, student.getDateOfBirth());
            stm.setObject(7, student.getGrade());
            stm.setObject(8, student.getGender());
            stm.setObject(9, student.getGuardianName());
            stm.setObject(10, student.getGuardianContact());
            stm.setObject(11, student.getTeacherName());
            stm.setObject(12, student.getSubjectName());
            stm.setObject(13, student.getAdmissionDate());
            stm.setObject(14, student.getRegistrationFee());

            if (stm.executeUpdate() > 0) {
                StudentDetail studentDetail = new StudentDetail(student.getStudentId(), student.getStudentName(), student.getTeacherName(), student.getSubjectName(), student.getGrade());
                if (addStudentDetails(studentDetail)) {
                    connection.commit();
                    return true;
                } else {
                    connection.rollback();
                    return false;
                }
            } else {
                connection.rollback();
                return false;
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    @Override
    public ArrayList<Student> getAllStudents() throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Student");
        ResultSet rst = stm.executeQuery();
        ArrayList<Student> students = new ArrayList<>();
        while (rst.next()) {
            students.add(new Student(rst.getString(1), rst.getString(3), rst.getString(5), rst.getString(10), rst.getInt(7), rst.getString(12), rst.getString(11)));
        }
        return students;
    }

    @Override
    public List<Student> searchStudents(String newValue) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Student WHERE Sid LIKE '%" + newValue + "%' OR StudentName LIKE '%" + newValue + "%' OR Address LIKE '%" + newValue + "%' OR GuardianContact LIKE '%" + newValue + "%' OR Grade LIKE '%" + newValue + "%' OR SubjectName LIKE '%" + newValue + "%' OR TeacherName LIKE '%" + newValue + "%'");
        ResultSet rst = stm.executeQuery();
        ArrayList<Student> students = new ArrayList<>();
        while (rst.next()) {
            students.add(new Student(rst.getString(1), rst.getString(3), rst.getString(5), rst.getString(10), rst.getInt(7), rst.getString(12), rst.getString(11)));
        }
        return students;
    }

    @Override
    public Student getStudent(String studentId) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Student WHERE Sid=?");
        stm.setObject(1, studentId);
        ResultSet rst = stm.executeQuery();
        Student student = null;
        while (rst.next()) {
            student = new Student(rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4), rst.getString(5), rst.getString(6), rst.getInt(7), rst.getString(8), rst.getString(9), rst.getString(10), rst.getString(11), rst.getString(12));
        }
        return student;
    }

    @Override
    public boolean updateStudent(Student student) {
        Connection connection = null;
        try {
            connection = DbConnection.getInstance().getConnection();
            connection.setAutoCommit(false);
            PreparedStatement stm = connection.prepareStatement("UPDATE Student SET Surname=?, StudentName=?, studentEmail=?, Address=?, DateOfBirth=?, Grade=?, Gender=?, GuardianName=?, GuardianContact=?, TeacherName=?, SubjectName=? WHERE Sid=?");
            stm.setObject(1, student.getSurname());
            stm.setObject(2, student.getStudentName());
            stm.setObject(3, student.getStudentEmail());
            stm.setObject(4, student.getAddress());
            stm.setObject(5, student.getDateOfBirth());
            stm.setObject(6, student.getGrade());
            stm.setObject(7, student.getGender());
            stm.setObject(8, student.getGuardianName());
            stm.setObject(9, student.getGuardianContact());
            stm.setObject(10, student.getTeacherName());
            stm.setObject(11, student.getSubjectName());
            stm.setObject(12, student.getStudentId());
            if (stm.executeUpdate() > 0) {
                if (updateStudentDetails(student)) {
                    connection.commit();
                    return true;
                } else {
                    connection.rollback();
                    return false;
                }
            } else {
                connection.rollback();
                return false;
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    @Override
    public Student searchStudentWithAdmissionDate(String studentId) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Student WHERE Sid=?");
        stm.setObject(1, studentId);
        ResultSet rst = stm.executeQuery();
        Student student = null;
        while (rst.next()) {
            student = new Student(rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4), rst.getString(5), rst.getString(6), rst.getInt(7), rst.getString(8), rst.getString(9), rst.getString(10), rst.getString(11), rst.getString(12), rst.getString(13));
        }
        return student;
    }

    @Override
    public boolean deleteStudent(String studentId) throws SQLException, ClassNotFoundException {
        ButtonType yes = new ButtonType("Yes", ButtonBar.ButtonData.OK_DONE);
        ButtonType no = new ButtonType("No", ButtonBar.ButtonData.CANCEL_CLOSE);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure whether you want to delete this student?", yes, no);
        alert.setTitle("Confirmation Alert");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.orElse(no) == yes) {
            PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("DELETE FROM Student WHERE Sid=?");
            stm.setObject(1, studentId);
            return stm.executeUpdate() > 0;
        }
        return false;
    }

    @Override
    public ArrayList<StudentDetail> getAllStudentDetails() throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM `Student Detail`");
        ResultSet rst = stm.executeQuery();
        ArrayList<StudentDetail> students = new ArrayList<>();
        while (rst.next()) {
            students.add(new StudentDetail(rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4), rst.getInt(5)));
        }
        return students;
    }

    @Override
    public void getStudentCount(Label lblStudents) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT COUNT(*) FROM Student");
        ResultSet rst = stm.executeQuery();
        while (rst.next()) {
            lblStudents.setText(rst.getString(1));
        }
    }

    @Override
    public boolean updateStudentDetails(Student student) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("UPDATE `Student Detail` SET StudentName=?, TeacherName=?, Subject=?, grade=? WHERE StudentId=?");
        stm.setObject(1, student.getStudentName());
        stm.setObject(2, student.getTeacherName());
        stm.setObject(3, student.getSubjectName());
        stm.setObject(4, student.getGrade());
        stm.setObject(5, student.getStudentId());
        return stm.executeUpdate() > 0;
    }

    @Override
    public boolean addStudentDetails(StudentDetail studentDetail) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("INSERT INTO `Student Detail` VALUES(?,?,?,?,?)");
        stm.setObject(1, studentDetail.getStudentId());
        stm.setObject(2, studentDetail.getStudentName());
        stm.setObject(3, studentDetail.getTeacherName());
        stm.setObject(4, studentDetail.getSubject());
        stm.setObject(5, studentDetail.getGrade());
        return stm.executeUpdate() > 0;
    }

    @Override
    public List<StudentDetail> searchStudentDetails(String newValue) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM `Student Detail` WHERE TeacherName LIKE '%" + newValue + "%'");
        ResultSet rst = stm.executeQuery();
        ArrayList<StudentDetail> students = new ArrayList<>();
        while (rst.next()) {
            students.add(new StudentDetail(rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4), rst.getInt(5)));
        }
        return students;
    }

    @Override
    public double getRegistrationFees(String day) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT SUM(RegistrationFee) FROM Student WHERE admissionDate=?");
        stm.setObject(1, day);
        double registrationFee = 0;
        ResultSet rst = stm.executeQuery();
        while (rst.next()) {
            registrationFee = rst.getDouble(1);
        }
        return registrationFee;
    }

    @Override
    public double getRegistrationCash(int year, String month) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT SUM(RegistrationFee) FROM Student WHERE YEAR(admissionDate)=? && MONTHNAME(admissionDate)=?");
        stm.setObject(1, year);
        stm.setObject(2, month);
        ResultSet rst = stm.executeQuery();
        double registrationFees = 0;
        while (rst.next()) {
            registrationFees = rst.getDouble(1);
        }
        return registrationFees;
    }

    @Override
    public double getAnnualRegistrationFee(int year) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT SUM(RegistrationFee) FROM Student WHERE YEAR(admissionDate)=?");
        stm.setObject(1, year);
        ResultSet rst = stm.executeQuery();
        double registrationFees = 0;
        while (rst.next()) {
            registrationFees = rst.getDouble(1);
        }
        return registrationFees;
    }
}
