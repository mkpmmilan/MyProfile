package controller;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.text.SimpleDateFormat;
import java.util.Date;

public class StudentDetailsFormController {
    public TextField txtStudentId;
    public TextField txtSurname;
    public TextField txtStudentName;
    public TextField txtAddress;
    public TextField txtEmail;
    public TextField txtGuardianName;
    public TextField txtContact;
    public TextField txtDateOfBirth;
    public TextField txtGender;
    public TextField txtGrade;
    public TextField txtAdmissionDate;
    public TextField txtTeachers;
    public TextField txtSubjects;
    public Label lblDate;

    public void initialize() {
        loadDate();
    }

    private void loadDate() {
        Date date = new Date();
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
        lblDate.setText(f.format(date));
    }
}
