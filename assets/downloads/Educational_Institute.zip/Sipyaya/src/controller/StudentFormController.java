package controller;


import Notification.NotificationBuilder;
import Validation.ValidationUtil;
import animatefx.animation.ZoomIn;
import com.jfoenix.controls.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.Student;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
import org.controlsfx.control.Notifications;
import view.TM.StudentTM;

import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;
import java.util.regex.Pattern;


public class StudentFormController {

    public JFXTextField txtsubjects;
    public JFXTextField txtTeachers;
    public JFXTextField txtGuardianName;
    public JFXTextField txtContact;
    public JFXTextField txtAddress;
    public JFXTextField txtEmail;
    public JFXTextField txtStudentName;
    public JFXTextField txtSurname;
    public JFXButton btnAddStudent;
    public JFXTextField txtStudentId;
    public JFXDatePicker dateOfBirth;
    public JFXComboBox<Integer> cmbGrade;
    public JFXComboBox<String> cmbGender;
    public TextField txtRegistrationFee;
    public TableColumn colStudentId;
    public TableColumn colName;
    public TableColumn colAddress;
    public TableColumn colContact;
    public TableColumn colGrade;
    public TableColumn colSubjects;
    public TableColumn colTeachers;
    public JFXTextField txtSearchStudent;
    public ComboBox<String> cmbSubjects;
    public ComboBox<String> cmbTeachers;
    public TableView<StudentTM> tblStudents;

    LinkedHashMap<JFXTextField, Pattern> map = new LinkedHashMap<>();
    Pattern surnamePattern = Pattern.compile("^[A-z ]{3,}$");
    Pattern studentNamePattern = Pattern.compile("^[A-z ]{3,}$");
    Pattern emailPattern = Pattern.compile("^[a-z0-9]{3,}(@)[a-z]{3,}(.)[a-z]{2,3}$");
    Pattern addressPattern = Pattern.compile("^[A-z0-9, ]{3,}$");
    Pattern contactPattern = Pattern.compile("^(07)[0-9](-)[0-9]{7}$");
    Pattern guardianNamePattern = Pattern.compile("^[A-z .]{4,}$");
    Pattern teacherPattern = Pattern.compile("^([a-z& A-Z]+(,[a-z& A-Z]+)*)$");
    Pattern subjectPattern = Pattern.compile("^([a-z& A-Z]+(,[a-z& A-Z]+)*)$");


    public void initialize() {
        cmbGrade.getItems().addAll(6, 7, 8, 9, 10, 11);
        cmbGender.getItems().addAll("Male", "Female");
        btnAddStudent.setDisable(true);
        storeValidations();
        loadStudentId();
        try {
            setStudentDataToTable(new StudentController().getAllStudents());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        loadSubjects();
        txtSearchStudent.textProperty().addListener((observable, oldValue, newValue) -> {
            search(newValue);
        });
        cmbSubjects.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            cmbTeachers.getItems().clear();
            searchTeacher(newValue);
        });
        dateOfBirth.valueProperty().addListener((observable, oldValue, newValue) -> {
            if (!txtGuardianName.getText().isEmpty() && !cmbGrade.getSelectionModel().isEmpty() && !cmbGender.getSelectionModel().isEmpty()) {
                btnAddStudent.setDisable(false);
            }
        });
        cmbGender.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (!txtGuardianName.getText().isEmpty() && !cmbGrade.getSelectionModel().isEmpty() && dateOfBirth.getValue() != null) {
                btnAddStudent.setDisable(false);
            }
        });
        cmbGrade.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (!txtGuardianName.getText().isEmpty() && !cmbGender.getSelectionModel().isEmpty() && dateOfBirth.getValue() != null) {
                btnAddStudent.setDisable(false);
            }
        });
        new ZoomIn(tblStudents).play();
    }

    private void searchTeacher(String newValue) {
        try {
            List<String> teacherNames = new TeacherController().getTeacherNamesBySubjects(newValue);
            cmbTeachers.getItems().addAll(teacherNames);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void search(String newValue) {
        try {
            List<Student> students = new StudentController().searchStudents(newValue);
            ObservableList<StudentTM> obList = FXCollections.observableArrayList();
            students.forEach(e -> {
                obList.add(new StudentTM(e.getStudentId(), e.getStudentName(), e.getAddress(), e.getGuardianContact(), e.getGrade(), e.getSubjectName(), e.getTeacherName()));
            });
            tblStudents.setItems(obList);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void setStudentDataToTable(ArrayList<Student> allStudents) {
        ObservableList<StudentTM> obList = FXCollections.observableArrayList();
        allStudents.forEach(e -> {
            obList.add(new StudentTM(e.getStudentId(), e.getStudentName(), e.getAddress(), e.getGuardianContact(), e.getGrade(), e.getSubjectName(), e.getTeacherName()));
        });
        tblStudents.setItems(obList);
        initTable();
    }

    private void initTable() {
        colStudentId.setCellValueFactory(new PropertyValueFactory<>("studentId"));
        colName.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        colAddress.setCellValueFactory(new PropertyValueFactory<>("address"));
        colContact.setCellValueFactory(new PropertyValueFactory<>("guardianContact"));
        colGrade.setCellValueFactory(new PropertyValueFactory<>("grade"));
        colSubjects.setCellValueFactory(new PropertyValueFactory<>("subjectName"));
        colTeachers.setCellValueFactory(new PropertyValueFactory<>("teacherName"));
    }

    private void loadSubjects() {
        try {
            List<String> subjectNames = new SubjectController().getSubjectNames();
            cmbSubjects.getItems().addAll(subjectNames);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void loadStudentId() {
        try {
            txtStudentId.setText(new StudentController().setStudentId());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void storeValidations() {
        map.put(txtSurname, surnamePattern);
        map.put(txtStudentName, studentNamePattern);
        map.put(txtEmail, emailPattern);
        map.put(txtAddress, addressPattern);
        map.put(txtsubjects, subjectPattern);
        map.put(txtTeachers, teacherPattern);
        map.put(txtContact, contactPattern);
        map.put(txtGuardianName, guardianNamePattern);
    }

    public void textFieldValidationOnAction(KeyEvent keyEvent) {
        Object response = ValidationUtil.validateJFXTextField(map, btnAddStudent);
        if (keyEvent.getCode() == KeyCode.ENTER) {
            if (response instanceof TextField) {
                TextField errorText = (TextField) response;
                errorText.requestFocus();
            } else if (response instanceof Boolean) {
                Notifications confirmation = NotificationBuilder.notifyMassage("CONFIRMATION", "All the text fields are filled successfully.");
                confirmation.showConfirm();
            }
        }
    }

    public void addStudentOnAction(MouseEvent mouseEvent) throws SQLException, ClassNotFoundException, JRException {
        Date date = new Date();
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
        if (dateOfBirth.getValue() != null) {
            if (!cmbGrade.getSelectionModel().isEmpty()) {
                if (!cmbGender.getSelectionModel().isEmpty()) {
                    Student student = new Student(txtStudentId.getText(), txtSurname.getText(), txtStudentName.getText(), txtEmail.getText(), txtAddress.getText(), String.valueOf(dateOfBirth.getValue()), cmbGrade.getSelectionModel().getSelectedItem(), cmbGender.getSelectionModel().getSelectedItem(), txtGuardianName.getText(), txtContact.getText(), txtTeachers.getText(), txtsubjects.getText(), f.format(date), Double.parseDouble(txtRegistrationFee.getText()));
                    if (new StudentController().addStudent(student)) {
                        Notifications information = NotificationBuilder.notifyMassage("CONFIRMATION", "Student details saved successfully");
                        information.showInformation();

                        String id = txtStudentId.getText();
                        String name = txtStudentName.getText();
                        String address = txtAddress.getText();
                        String email = txtEmail.getText();
                        String guardName = txtGuardianName.getText();
                        String contact = txtContact.getText();
                        String dOfBirth = String.valueOf(dateOfBirth.getValue());
                        int grade = cmbGrade.getValue();
                        String gender = cmbGender.getValue();
                        String subject = txtsubjects.getText();
                        String teacher = txtTeachers.getText();
                        double registerFee = Double.parseDouble(txtRegistrationFee.getText());

                        HashMap map = new HashMap();
                        map.put("studentId", id);
                        map.put("name", name);
                        map.put("address", address);
                        map.put("email", email);
                        map.put("guardianName", guardName);
                        map.put("contact", contact);
                        map.put("dateOfBirth", dOfBirth);
                        map.put("grade", grade);
                        map.put("gender", gender);
                        map.put("subjects", subject);
                        map.put("teachers", teacher);
                        map.put("registrationFee", registerFee);

                        JasperDesign jasperDesign = JRXmlLoader.load(this.getClass().getResourceAsStream("/view/reports/StudentRegistration.jrxml"));
                        JasperReport compileReport = JasperCompileManager.compileReport(jasperDesign);
                        JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, map, new JREmptyDataSource(1));
                        JasperViewer.viewReport(jasperPrint, false);

                        btnAddStudent.setDisable(true);
                        loadStudentId();
                        setStudentDataToTable(new StudentController().getAllStudents());
                        txtStudentName.clear();
                        txtsubjects.clear();
                        txtTeachers.clear();
                        txtSurname.clear();
                        txtAddress.clear();
                        txtContact.clear();
                        txtEmail.clear();
                        txtGuardianName.clear();
                        dateOfBirth.getEditor().clear();
                        cmbGender.getSelectionModel().clearSelection();
                        cmbGrade.getSelectionModel().clearSelection();
                    } else {
                        Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Try again");
                        warning.showWarning();
                    }
                } else {
                    Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please select gender");
                    warning.showWarning();
                }
            } else {
                Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please select grade");
                warning.showWarning();
            }
        } else {
            Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please select date of birth");
            warning.showWarning();
        }
    }

    public void clearOnAction(ActionEvent actionEvent) {
        txtStudentName.clear();
        txtsubjects.clear();
        txtTeachers.clear();
        txtSurname.clear();
        txtAddress.clear();
        txtContact.clear();
        txtEmail.clear();
        txtGuardianName.clear();
        dateOfBirth.getEditor().clear();
        cmbGender.getSelectionModel().clearSelection();
        cmbGrade.getSelectionModel().clearSelection();
        btnAddStudent.setDisable(true);
    }

    public void refreshTableDataOnAction(ActionEvent actionEvent) {
        try {
            setStudentDataToTable(new StudentController().getAllStudents());
            txtSearchStudent.clear();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void editStudentOnAction(ActionEvent actionEvent) {
        StudentTM selectedItem = tblStudents.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            Notifications error = NotificationBuilder.notifyMassage("ERROR", "No Student raw selected.");
            error.showError();
        } else {
            try {
                Student student = new StudentController().getStudent(selectedItem.getStudentId());
                FXMLLoader loader = new FXMLLoader(this.getClass().getResource("../view/UpdateStudentForm.fxml"));
                Parent parent = loader.load();
                UpdateStudentFormController controller = loader.getController();
                controller.txtStudentId.setText(student.getStudentId());
                controller.txtSurname.setText(student.getSurname());
                controller.txtStudentName.setText(student.getStudentName());
                controller.txtAddress.setText(student.getAddress());
                controller.txtEmail.setText(student.getStudentEmail());
                controller.txtGuardianName.setText(student.getGuardianName());
                controller.txtGuardianContact.setText(student.getGuardianContact());
                controller.txtSubjects.setText(student.getSubjectName());
                controller.txtTeachers.setText(student.getTeacherName());
                controller.dateOfBirth.setValue(LocalDate.parse(student.getDateOfBirth()));
                controller.cmbGender.setValue(student.getGender());
                controller.cmbGrade.setValue(student.getGrade());
                Stage stage = new Stage(StageStyle.DECORATED);
                stage.setScene(new Scene(parent));
                stage.getIcons().add(new Image("assets/logo.png"));
                stage.setTitle("Update Student Form");
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.setResizable(false);
                stage.show();

                stage.setOnHiding((e) -> {
                    try {
                        setStudentDataToTable(new StudentController().getAllStudents());
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    } catch (ClassNotFoundException ex) {
                        ex.printStackTrace();
                    }
                });
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public void addSubjectAndTeacherNameToTextField(MouseEvent mouseEvent) {
        if (!cmbSubjects.getSelectionModel().isEmpty() && !cmbTeachers.getSelectionModel().isEmpty()) {
            String concat1 = txtsubjects.getText().concat(cmbSubjects.getSelectionModel().getSelectedItem());
            txtsubjects.setText(concat1 + ",");
            String concat2 = txtTeachers.getText().concat(cmbTeachers.getSelectionModel().getSelectedItem());
            txtTeachers.setText(concat2 + ",");
            cmbSubjects.getSelectionModel().clearSelection();
        }
    }

    public void viewStudentOnAction(ActionEvent actionEvent) {
        StudentTM selectedItem = tblStudents.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            Notifications error = NotificationBuilder.notifyMassage("ERROR", "No Student raw selected.");
            error.showError();
        } else {
            try {
                Student student = new StudentController().searchStudentWithAdmissionDate(selectedItem.getStudentId());
                FXMLLoader loader = new FXMLLoader(this.getClass().getResource("../view/StudentDetailsForm.fxml"));
                Parent parent = loader.load();
                StudentDetailsFormController controller = loader.getController();
                controller.txtStudentId.setText(student.getStudentId());
                controller.txtSurname.setText(student.getSurname());
                controller.txtStudentName.setText(student.getStudentName());
                controller.txtAddress.setText(student.getAddress());
                controller.txtContact.setText(student.getGuardianContact());
                controller.txtEmail.setText(student.getStudentEmail());
                controller.txtAdmissionDate.setText(student.getAdmissionDate());
                controller.txtDateOfBirth.setText(student.getDateOfBirth());
                controller.txtGender.setText(student.getGender());
                controller.txtGrade.setText(String.valueOf(student.getGrade()));
                controller.txtGuardianName.setText(student.getGuardianName());
                controller.txtTeachers.setText(student.getTeacherName());
                controller.txtSubjects.setText(student.getSubjectName());
                Stage stage = new Stage(StageStyle.DECORATED);
                stage.setScene(new Scene(parent));
                stage.getIcons().add(new Image("assets/logo.png"));
                stage.setTitle("Student Details Form");
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.setResizable(false);
                stage.show();
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void deleteStudentOnAction(ActionEvent actionEvent) {
        StudentTM selectedItem = tblStudents.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            Notifications error = NotificationBuilder.notifyMassage("ERROR", "No Student raw selected.");
            error.showError();
        } else {
            try {
                if (new StudentController().deleteStudent(selectedItem.getStudentId())) {
                    Notifications information = NotificationBuilder.notifyMassage("CONFIRMATION", "Student details deleted successfully");
                    information.showInformation();
                    loadStudentId();
                    setStudentDataToTable(new StudentController().getAllStudents());
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
}
