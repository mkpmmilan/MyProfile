package controller;

import Notification.NotificationBuilder;
import Validation.ValidationUtil;
import animatefx.animation.ZoomIn;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.EvaluationMark;
import model.Student;
import org.controlsfx.control.Notifications;
import view.TM.EvaluationMarkTM;

import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;

public class StudentMarksFormController {

    public TableView<EvaluationMarkTM> tblStudentMarks;
    public JFXTextField txtSearchStudentId;
    public JFXTextField txtStudentName;
    public JFXTextField txtGrade;
    public JFXComboBox<String> cmbMonth;
    public TextField txtMarks;
    public JFXButton btnAddMarks;
    public JFXComboBox<String> cmbSubject;
    public TableColumn colStudentId;
    public TableColumn colStudentName;
    public TableColumn colGrade;
    public TableColumn colSubject;
    public TableColumn colMonth;
    public TableColumn colMarks;
    public JFXTextField txtSearch;
    public JFXComboBox<String> cmbTeacher;

    LinkedHashMap<JFXTextField, Pattern> JfxMap = new LinkedHashMap<>();
    LinkedHashMap<TextField, Pattern> textMap = new LinkedHashMap<>();
    Pattern studentIdPattern = Pattern.compile("^(S00-)[0-9]{3}$");
    Pattern marksPattern = Pattern.compile("^([0-9]{1,2}|100)$");

    public void initialize() {
        btnAddMarks.setDisable(true);
        cmbMonth.getItems().addAll("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
        storeValidations();
        try {
            loadMarksToTable(new MarksController().getMarks());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        cmbSubject.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (!txtSearchStudentId.getText().isEmpty() && !cmbMonth.getSelectionModel().isEmpty() && !txtMarks.getText().isEmpty() && !cmbTeacher.getSelectionModel().isEmpty()) {
                btnAddMarks.setDisable(false);
            }
        });
        cmbMonth.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (!txtSearchStudentId.getText().isEmpty() && !cmbSubject.getSelectionModel().isEmpty() && !txtMarks.getText().isEmpty() && !cmbTeacher.getSelectionModel().isEmpty()) {
                btnAddMarks.setDisable(false);
            }
        });
        cmbTeacher.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (!txtSearchStudentId.getText().isEmpty() && !cmbSubject.getSelectionModel().isEmpty() && !txtMarks.getText().isEmpty() && !cmbMonth.getSelectionModel().isEmpty()) {
                btnAddMarks.setDisable(false);
            }
        });
        new ZoomIn(tblStudentMarks).play();
    }

    private void loadMarksToTable(ArrayList<EvaluationMark> marks) {
        ObservableList<EvaluationMarkTM> obList = FXCollections.observableArrayList();
        marks.forEach(e -> {
            obList.add(new EvaluationMarkTM(e.getStudentId(), e.getStudentName(), e.getGrade(), e.getSubName(), e.getMonth(), e.getMark(), e.getIssuedDate(), e.getTeacherName()));
        });
        tblStudentMarks.setItems(obList);
        initCols();
    }

    private void initCols() {
        colStudentId.setCellValueFactory(new PropertyValueFactory<>("studentId"));
        colStudentName.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        colGrade.setCellValueFactory(new PropertyValueFactory<>("grade"));
        colSubject.setCellValueFactory(new PropertyValueFactory<>("subName"));
        colMonth.setCellValueFactory(new PropertyValueFactory<>("month"));
        colMarks.setCellValueFactory(new PropertyValueFactory<>("mark"));
    }

    private void storeValidations() {
        JfxMap.put(txtSearchStudentId, studentIdPattern);
        textMap.put(txtMarks, marksPattern);
    }

    public void jfxTextFieldValidationOnAction(KeyEvent keyEvent) {
        Object response = ValidationUtil.validateJFXTextField(JfxMap, btnAddMarks);
        btnAddMarks.setDisable(true);
        if (keyEvent.getCode() == KeyCode.ENTER) {
            if (response instanceof TextField) {
                TextField errorText = (TextField) response;
                errorText.requestFocus();
            } else if (response instanceof Boolean) {
                if (!txtMarks.getText().isEmpty() && !cmbSubject.getSelectionModel().isEmpty() && !cmbMonth.getSelectionModel().isEmpty() && !cmbTeacher.getSelectionModel().isEmpty()) {
                    btnAddMarks.setDisable(false);
                }
            }
        }
    }

    public void textFieldValidationOnAction(KeyEvent keyEvent) {
        btnAddMarks.setDisable(true);
        for (TextField textFieldKey : textMap.keySet()) {
            Pattern patternValue = textMap.get(textFieldKey);
            if (!patternValue.matcher(textFieldKey.getText()).matches()) {
                if (!textFieldKey.getText().isEmpty()) {
                    textFieldKey.setStyle("-fx-text-fill: red");
                    return;
                }
            }
            textFieldKey.setStyle("-fx-text-fill: green");
        }
        if (!txtSearchStudentId.getText().isEmpty() && !cmbSubject.getSelectionModel().isEmpty() && !cmbMonth.getSelectionModel().isEmpty() && !txtMarks.getText().isEmpty() && !cmbTeacher.getSelectionModel().isEmpty()) {
            btnAddMarks.setDisable(false);
        }
    }

    public void searchStudentDetailsOnAction(ActionEvent actionEvent) {
        try {
            cmbSubject.getItems().clear();
            cmbTeacher.getItems().clear();
            Student student = new StudentController().getStudent(txtSearchStudentId.getText());
            if (student == null) {
                Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Student not found.Please try again");
                warning.showWarning();
            } else {
                txtStudentName.setText(student.getStudentName());
                txtGrade.setText(String.valueOf(student.getGrade()));

                String sub = student.getSubjectName();
                String[] subjects = sub.split("[,]");
                cmbSubject.getItems().addAll(subjects);

                String teacher = student.getTeacherName();
                String[] teachers = teacher.split("[,]");
                cmbTeacher.getItems().addAll(teachers);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void addMarksOnAction(MouseEvent mouseEvent) {
        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(new Date());
        EvaluationMark mark = new EvaluationMark(txtSearchStudentId.getText(), txtStudentName.getText(), cmbSubject.getSelectionModel().getSelectedItem(), Integer.parseInt(txtGrade.getText()), cmbMonth.getSelectionModel().getSelectedItem(), date, Integer.parseInt(txtMarks.getText()), cmbTeacher.getSelectionModel().getSelectedItem());
        try {
            if (new MarksController().addMarks(mark)) {
                Notifications information = NotificationBuilder.notifyMassage("INFORMATION", "Marks saved successfully");
                information.showInformation();
                txtSearchStudentId.clear();
                txtGrade.clear();
                txtStudentName.clear();
                txtMarks.clear();
                cmbMonth.getSelectionModel().clearSelection();
                cmbSubject.getItems().clear();
                cmbTeacher.getItems().clear();
                btnAddMarks.setDisable(true);
                loadMarksToTable(new MarksController().getMarks());
            } else {

            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void clearFieldsOnAction(MouseEvent mouseEvent) {
        txtSearchStudentId.clear();
        txtMarks.clear();
        txtStudentName.clear();
        txtGrade.clear();
        cmbMonth.getSelectionModel().clearSelection();
        cmbSubject.getItems().clear();
        cmbTeacher.getItems().clear();
        btnAddMarks.setDisable(true);
    }

    public void refreshOnAction(ActionEvent actionEvent) {
        try {
            loadMarksToTable(new MarksController().getMarks());
            txtSearch.clear();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void updateMarksOnAction(ActionEvent actionEvent) throws IOException {
        EvaluationMarkTM selectedItem = tblStudentMarks.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            Notifications error = NotificationBuilder.notifyMassage("ERROR", "No student mark raw selected.");
            error.showError();
        } else {
            FXMLLoader loader = new FXMLLoader(this.getClass().getResource("../view/UpdateStudentMarksForm.fxml"));
            Parent parent = loader.load();
            UpdateStudentMarksFormController controller = loader.getController();
            controller.txtStudentId.setText(selectedItem.getStudentId());
            controller.txtStudentName.setText(selectedItem.getStudentName());
            controller.txtGrade.setText(String.valueOf(selectedItem.getGrade()));
            controller.txtSubject.setText(selectedItem.getSubName());
            controller.cmbMonth.setValue(selectedItem.getMonth());
            controller.txtMarks.setText(String.valueOf(selectedItem.getMark()));
            controller.txtTeacher.setText(selectedItem.getTeacherName());
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setScene(new Scene(parent));
            stage.getIcons().add(new Image("assets/logo.png"));
            stage.setTitle("Update Student Marks Form");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setResizable(false);
            stage.show();

            stage.setOnHiding((e) -> {
                try {
                    loadMarksToTable(new MarksController().getMarks());
                } catch (SQLException ex) {
                    ex.printStackTrace();
                } catch (ClassNotFoundException ex) {
                    ex.printStackTrace();
                }
            });
        }
    }

    public void deleteMarksOnAction(ActionEvent actionEvent) {
        EvaluationMarkTM selectedItem = tblStudentMarks.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            Notifications error = NotificationBuilder.notifyMassage("ERROR", "No student mark raw selected.");
            error.showError();
        } else {
            try {
                if (new MarksController().deleteMarks(selectedItem)) {
                    Notifications information = NotificationBuilder.notifyMassage("INFORMATION", "Marks deleted successfully");
                    information.showInformation();
                    loadMarksToTable(new MarksController().getMarks());
                    txtSearch.clear();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
}
