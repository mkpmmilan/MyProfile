package controller;

import Database.DbConnection;
import controller.interfaces.SubjectService;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import model.Subject;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class SubjectController implements SubjectService {

    @Override
    public boolean addSubject(Subject s) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("INSERT INTO Subject VALUES(?,?)");
        stm.setObject(1, s.getSubCode());
        stm.setObject(2, s.getSubName());
        return stm.executeUpdate() > 0;
    }

    @Override
    public boolean deleteSubject(String code) throws SQLException, ClassNotFoundException {
        ButtonType yes = new ButtonType("Yes", ButtonBar.ButtonData.OK_DONE);
        ButtonType no = new ButtonType("No", ButtonBar.ButtonData.CANCEL_CLOSE);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure whether you want to delete this subject?", yes, no);
        alert.setTitle("Confirmation Alert");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.orElse(no) == yes) {
            PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("DELETE FROM Subject WHERE subId=?");
            stm.setObject(1, code);
            return stm.executeUpdate() > 0;
        }
        return false;
    }

    @Override
    public ArrayList<Subject> getAllSubjects() throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Subject");
        ResultSet rst = stm.executeQuery();
        ArrayList<Subject> subjects = new ArrayList<>();
        while (rst.next()) {
            subjects.add(new Subject(rst.getString(1), rst.getString(2)));
        }
        return subjects;
    }

    @Override
    public List<String> getSubjectNames() throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Subject");
        ResultSet rst = stm.executeQuery();
        ArrayList<String> subjectNames = new ArrayList<>();
        while (rst.next()) {
            subjectNames.add(rst.getString(2));
        }
        return subjectNames;
    }

    @Override
    public void getSubjectCount(Label lblSubjects) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT COUNT(*) FROM Subject");
        ResultSet rst = stm.executeQuery();
        while (rst.next()) {
            lblSubjects.setText(rst.getString(1));
        }
    }

    @Override
    public String setSubjectCodes() throws SQLException, ClassNotFoundException {
        ResultSet rst = DbConnection.getInstance().getConnection().prepareStatement("SELECT subId FROM Subject ORDER BY subId DESC LIMIT 1").executeQuery();
        if (rst.next()) {
            int tempId = Integer.parseInt(rst.getString(1).split("-")[1]);
            tempId = tempId + 1;
            if (tempId <= 9) {
                return "Sub-00" + tempId;
            } else if (tempId <= 99) {
                return "Sub-0" + tempId;
            } else {
                return "Sub-" + tempId;
            }
        } else {
            return "Sub-001";
        }
    }
}
