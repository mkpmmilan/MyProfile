package controller;

import Notification.NotificationBuilder;
import Validation.ValidationUtil;
import animatefx.animation.*;
import com.jfoenix.controls.JFXButton;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import model.Subject;
import org.controlsfx.control.Notifications;
import view.TM.SubjectTM;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.regex.Pattern;

public class SubjectFormController {
    public TableView<SubjectTM> tblSubjects;
    public TextField txtSubjectCode;
    public TextField txtSubjectName;
    public JFXButton btnAddSubject;
    public TableColumn colSubjectCode;
    public TableColumn colSubjectName;


    LinkedHashMap<TextField, Pattern> map = new LinkedHashMap<>();
    Pattern subNamePattern = Pattern.compile("^[A-z &-]{3,25}$");

    public void initialize() {
        try {
            setSubjectsToTable(new SubjectController().getAllSubjects());
            initTable();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        btnAddSubject.setDisable(true);
        loadSubjectCode();
        storeValidations();
        new ZoomIn(tblSubjects).play();
    }

    private void initTable() {
        colSubjectCode.setCellValueFactory(new PropertyValueFactory<>("subCode"));
        colSubjectName.setCellValueFactory(new PropertyValueFactory<>("subName"));
    }

    private void setSubjectsToTable(ArrayList<Subject> allSubjects) {
        ObservableList<SubjectTM> obList = FXCollections.observableArrayList();
        allSubjects.forEach(e -> {
            obList.add(new SubjectTM(e.getSubCode(), e.getSubName()));
        });
        tblSubjects.setItems(obList);
    }

    private void storeValidations() {
        map.put(txtSubjectName, subNamePattern);
    }

    private void loadSubjectCode() {
        try {
            txtSubjectCode.setText(new SubjectController().setSubjectCodes());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void textFieldValidationOnAction(KeyEvent keyEvent) {
        Object response = ValidationUtil.validateTextField(map, btnAddSubject);
        if (keyEvent.getCode() == KeyCode.ENTER) {
            if (response instanceof TextField) {
                TextField errorText = (TextField) response;
                errorText.requestFocus();
            } else if (response instanceof Boolean) {
                Notifications confirmation = NotificationBuilder.notifyMassage("CONFIRMATION", "All the text fields are filled successfully.");
                confirmation.showConfirm();
            }
        }
    }

    public void addSubjectOnAction(MouseEvent mouseEvent) {
        Subject sub = new Subject(txtSubjectCode.getText(), txtSubjectName.getText());
        try {
            if (new SubjectController().addSubject(sub)) {
                Notifications information = NotificationBuilder.notifyMassage("CONFIRMATION", "Subject details saved successfully");
                information.showInformation();
                txtSubjectName.clear();
                btnAddSubject.setDisable(true);
                loadSubjectCode();
                setSubjectsToTable(new SubjectController().getAllSubjects());
                initTable();
            } else {
                Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please try again");
                warning.showWarning();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void clearTextFieldOnAction(MouseEvent mouseEvent) {
        txtSubjectName.clear();
        btnAddSubject.setDisable(true);
    }

    public void tableRefreshOnAction(ActionEvent actionEvent) {
        try {
            setSubjectsToTable(new SubjectController().getAllSubjects());
            initTable();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void deleteSubjectOnAction(ActionEvent actionEvent) {
        SubjectTM subTm = tblSubjects.getSelectionModel().getSelectedItem();
        if (subTm == null) {
            Notifications error = NotificationBuilder.notifyMassage("ERROR", "No Subject raw selected.");
            error.showError();
        } else {
            try {
                if (new SubjectController().deleteSubject(subTm.getSubCode())) {
                    Notifications information = NotificationBuilder.notifyMassage("CONFIRMATION", "Subject details deleted successfully");
                    information.showInformation();
                    loadSubjectCode();
                    setSubjectsToTable(new SubjectController().getAllSubjects());
                    initTable();
                } else {

                }
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
}
