package controller;

import Database.DbConnection;
import controller.interfaces.TeacherService;
import javafx.scene.control.*;
import model.Teacher;
import model.TeacherSalary;
import model.TimeTable;
import view.TM.TeacherSalaryTM;
import view.TM.TimeTableTM;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class TeacherController implements TeacherService {
    @Override
    public String setTeacherId() throws SQLException, ClassNotFoundException {
        ResultSet rst = DbConnection.getInstance().getConnection().prepareStatement("SELECT TeacherId FROM Teacher ORDER BY TeacherId DESC LIMIT 1").executeQuery();
        if (rst.next()) {
            int tempId = Integer.parseInt(rst.getString(1).split("-")[1]);
            tempId = tempId + 1;
            if (tempId <= 9) {
                return "T00-00" + tempId;
            } else if (tempId <= 99) {
                return "T00-0" + tempId;
            } else {
                return "T00-" + tempId;
            }
        } else {
            return "T00-001";
        }
    }

    @Override
    public boolean addTeacher(Teacher teacher) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("INSERT INTO Teacher VALUES(?,?,?,?,?,?,?)");
        stm.setObject(1, teacher.getTeacherId());
        stm.setObject(2, teacher.getTeacherName());
        stm.setObject(3, teacher.getTeacherEmail());
        stm.setObject(4, teacher.getTeacherContact());
        stm.setObject(5, teacher.getTeacherAddress());
        stm.setObject(6, teacher.getSubject());
        stm.setObject(7, teacher.getClassFees());
        return stm.executeUpdate() > 0;
    }

    @Override
    public ArrayList<Teacher> getAllTeachers() throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Teacher");
        ResultSet rst = stm.executeQuery();
        ArrayList<Teacher> teachers = new ArrayList<>();
        while (rst.next()) {
            teachers.add(new Teacher(rst.getString(1), rst.getString(2), rst.getString(5), rst.getString(4), rst.getString(3), rst.getString(6), rst.getDouble(7)));
        }
        return teachers;
    }

    @Override
    public boolean updateTeacher(Teacher teacher) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("UPDATE Teacher SET TeacherName=?, teacherEmail=?, teacherContact=?, teacherAddress=?, subName=?, ClassFees=? WHERE TeacherId=?");
        stm.setObject(1, teacher.getTeacherName());
        stm.setObject(2, teacher.getTeacherEmail());
        stm.setObject(3, teacher.getTeacherContact());
        stm.setObject(4, teacher.getTeacherAddress());
        stm.setObject(5, teacher.getSubject());
        stm.setObject(6, teacher.getClassFees());
        stm.setObject(7, teacher.getTeacherId());
        return stm.executeUpdate() > 0;
    }

    @Override
    public boolean deleteTeacher(String teacherId) throws SQLException, ClassNotFoundException {
        ButtonType yes = new ButtonType("Yes", ButtonBar.ButtonData.OK_DONE);
        ButtonType no = new ButtonType("No", ButtonBar.ButtonData.CANCEL_CLOSE);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure whether you want to delete this teacher?", yes, no);
        alert.setTitle("Confirmation Alert");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.orElse(no) == yes) {
            PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("DELETE FROM Teacher WHERE TeacherId=?");
            stm.setObject(1, teacherId);
            return stm.executeUpdate() > 0;
        }
        return false;
    }

    @Override
    public void getTeacherCount(Label lblTeachers) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT COUNT(*) FROM Teacher");
        ResultSet rst = stm.executeQuery();
        while (rst.next()) {
            lblTeachers.setText(rst.getString(1));
        }
    }

    @Override
    public Teacher getTeacherDetails(String newValue) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Teacher WHERE TeacherName=?");
        stm.setObject(1, newValue);
        ResultSet rst = stm.executeQuery();
        Teacher teacher = null;
        while (rst.next()) {
            teacher = new Teacher(rst.getString(1), rst.getString(2), rst.getString(5), rst.getString(4), rst.getString(3), rst.getString(6), rst.getDouble(7));
        }
        return teacher;
    }

    @Override
    public void getSubject(String newValue, TextField txtSubject) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Teacher WHERE TeacherName=?");
        stm.setObject(1, newValue);
        ResultSet rst = stm.executeQuery();
        while (rst.next()) {
            txtSubject.setText(rst.getString(6));
        }
    }

    @Override
    public String getSubject(String newValue) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Teacher WHERE TeacherName=?");
        stm.setObject(1, newValue);
        ResultSet rst = stm.executeQuery();
        String subject = null;
        while (rst.next()) {
            subject = rst.getString(6);
        }
        return subject;
    }

    @Override
    public boolean addTeacherSalary(TeacherSalary teacherSalary) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("INSERT INTO `Teacher Salary` VALUES(?,?,?,?,?,?,?,?)");
        stm.setObject(1, teacherSalary.getTeacherName());
        stm.setObject(2, teacherSalary.getYear());
        stm.setObject(3, teacherSalary.getMonth());
        stm.setObject(4, teacherSalary.getDate());
        stm.setObject(5, teacherSalary.getTotalClassFees());
        stm.setObject(6, teacherSalary.getPercentage());
        stm.setObject(7, teacherSalary.getDeductions());
        stm.setObject(8, teacherSalary.getNetSalary());
        return stm.executeUpdate() > 0;

    }

    @Override
    public ArrayList<TeacherSalary> getAllTeacherSalary() throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM `Teacher Salary`");
        ResultSet rst = stm.executeQuery();
        ArrayList<TeacherSalary> teacherSalaries = new ArrayList<>();
        while (rst.next()) {
            teacherSalaries.add(new TeacherSalary(rst.getString(1), rst.getInt(2), rst.getString(3), rst.getString(4), rst.getDouble(5), rst.getDouble(6), rst.getDouble(7), rst.getDouble(8)));
        }
        return teacherSalaries;
    }

    @Override
    public List<TeacherSalary> searchTeacherSalary(Integer year, String month, TextField txtTeacherNetSalary) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM `Teacher Salary` WHERE Year=? AND Month=?");
        stm.setObject(1, year);
        stm.setObject(2, month);
        ResultSet rst = stm.executeQuery();
        ArrayList<TeacherSalary> teacherSalaries = new ArrayList<>();
        double netSalary = 0;
        while (rst.next()) {
            teacherSalaries.add(new TeacherSalary(rst.getString(1), rst.getInt(2), rst.getString(3), rst.getString(4), rst.getDouble(5), rst.getDouble(6), rst.getDouble(7), rst.getDouble(8)));
            netSalary = netSalary + rst.getDouble(8);
        }
        txtTeacherNetSalary.setText(String.valueOf(netSalary));
        return teacherSalaries;
    }

    @Override
    public boolean deleteSalary(TeacherSalaryTM selectedItem) throws SQLException, ClassNotFoundException {
        ButtonType yes = new ButtonType("Yes", ButtonBar.ButtonData.OK_DONE);
        ButtonType no = new ButtonType("No", ButtonBar.ButtonData.CANCEL_CLOSE);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure whether you want to delete this teacher salary?", yes, no);
        alert.setTitle("Confirmation Alert");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.orElse(no) == yes) {
            PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("DELETE FROM `Teacher Salary` WHERE TeacherName=? AND Date=? AND Month=?");
            stm.setObject(1, selectedItem.getTeacherName());
            stm.setObject(2, selectedItem.getDate());
            stm.setObject(3, selectedItem.getMonth());
            return stm.executeUpdate() > 0;
        }
        return false;
    }

    @Override
    public List<Teacher> searchTeacher(String newValue) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Teacher WHERE TeacherId LIKE '%" + newValue + "%' OR TeacherName LIKE '%" + newValue + "%' OR teacherEmail LIKE '%" + newValue + "%' OR teacherContact LIKE '%" + newValue + "%' OR teacherAddress LIKE '%" + newValue + "%' OR subName LIKE '%" + newValue + "%' OR ClassFees LIKE '%" + newValue + "%'");
        ResultSet rst = stm.executeQuery();
        ArrayList<Teacher> teachers = new ArrayList<>();
        while (rst.next()) {
            teachers.add(new Teacher(rst.getString(1), rst.getString(2), rst.getString(5), rst.getString(4), rst.getString(3), rst.getString(6), rst.getDouble(7)));
        }
        return teachers;
    }

    @Override
    public List<String> getTeacherNames() throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Teacher");
        ResultSet rst = stm.executeQuery();
        ArrayList<String> teacherNames = new ArrayList<>();
        while (rst.next()) {
            teacherNames.add(rst.getString(2));
        }
        return teacherNames;
    }

    @Override
    public List<String> getTeacherNamesBySubjects(String newValue) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Teacher WHERE subName LIKE '%" + newValue + "%'");
        ResultSet rst = stm.executeQuery();
        ArrayList<String> teacherNames = new ArrayList<>();
        while (rst.next()) {
            teacherNames.add(rst.getString(2));
        }
        return teacherNames;
    }

    @Override
    public void getClassFees(String newValue, TextField txtCash) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT ClassFees FROM Teacher WHERE TeacherName=?");
        stm.setObject(1, newValue);
        ResultSet rst = stm.executeQuery();
        while (rst.next()) {
            txtCash.setText(rst.getString(1));
        }
    }

    @Override
    public double getTotalSalary(int year, String month) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT SUM(NetSalary) FROM `Teacher Salary` WHERE Year=? && Month=? ");
        stm.setObject(1, year);
        stm.setObject(2, month);
        ResultSet rst = stm.executeQuery();
        double teacherSalary = 0;
        while (rst.next()) {
            teacherSalary = rst.getDouble(1);
        }
        return teacherSalary;
    }

    @Override
    public double getAnnualTeacherSalary(int year) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT SUM(NetSalary) FROM `Teacher Salary` WHERE Year=?");
        stm.setObject(1, year);
        ResultSet rst = stm.executeQuery();
        double teacherSalary = 0;
        while (rst.next()) {
            teacherSalary = rst.getDouble(1);
        }
        return teacherSalary;
    }

    @Override
    public double getSumOfSalary(String fDate, String tDate) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT SUM(NetSalary) FROM `Teacher Salary` WHERE Date BETWEEN ? AND ?");
        stm.setObject(1, fDate);
        stm.setObject(2, tDate);
        ResultSet rst = stm.executeQuery();
        double totalSalary = 0;
        while (rst.next()) {
            totalSalary = rst.getDouble(1);
        }
        return totalSalary;
    }
}
