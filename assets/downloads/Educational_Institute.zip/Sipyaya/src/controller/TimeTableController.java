package controller;

import Database.DbConnection;
import controller.interfaces.TimeTableService;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import model.TimeTable;
import view.TM.TimeTableTM;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class TimeTableController implements TimeTableService {

    @Override
    public boolean addToTimeTable(TimeTable timeTable) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("INSERT INTO Schedule VALUES(?,?,?,?,?,?,?)");
        stm.setObject(1, timeTable.getTeacherId());
        stm.setObject(2, timeTable.getTeacherName());
        stm.setObject(3, timeTable.getSubjectName());
        stm.setObject(4, timeTable.getDate());
        stm.setObject(5, timeTable.getStartTime());
        stm.setObject(6, timeTable.getEndTime());
        stm.setObject(7, timeTable.getGrade());
        return stm.executeUpdate() > 0;
    }

    @Override
    public ArrayList<TimeTable> getTimeTable() throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Schedule");
        ResultSet rst = stm.executeQuery();
        ArrayList<TimeTable> timeTables = new ArrayList<>();
        while (rst.next()) {
            timeTables.add(new TimeTable(rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4), LocalTime.parse(rst.getString(5)), LocalTime.parse(rst.getString(6)), rst.getInt(7)));
        }
        return timeTables;
    }

    @Override
    public List<TimeTable> getTimeTableData(LocalTime startTime, LocalDate date) throws SQLException, ClassNotFoundException {
        String d = String.valueOf(date);
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Schedule WHERE date=? AND StartTime=?");
        stm.setObject(1, d);
        stm.setObject(2, startTime);
        ResultSet rst = stm.executeQuery();
        ArrayList<TimeTable> timeTables = new ArrayList<>();
        while (rst.next()) {
            timeTables.add(new TimeTable(rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4), LocalTime.parse(rst.getString(5)), LocalTime.parse(rst.getString(6)), rst.getInt(7)));
        }
        return timeTables;
    }

    @Override
    public boolean deleteTimeTableRaw(TimeTableTM selectedItem) throws SQLException, ClassNotFoundException {
        ButtonType yes = new ButtonType("Yes", ButtonBar.ButtonData.OK_DONE);
        ButtonType no = new ButtonType("No", ButtonBar.ButtonData.CANCEL_CLOSE);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure whether you want to delete this raw?", yes, no);
        alert.setTitle("Confirmation Alert");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.orElse(no) == yes) {
            PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("DELETE FROM Schedule WHERE TeacherId=? AND TeacherName=? AND date=? AND StartTime=?");
            stm.setObject(1, selectedItem.getTeacherId());
            stm.setObject(2, selectedItem.getTeacherName());
            stm.setObject(3, selectedItem.getDate());
            stm.setObject(4, selectedItem.getStartTime());
            return stm.executeUpdate() > 0;
        }
        return false;
    }

    @Override
    public List<TimeTable> getTimeTableByTeacherName(String teacherName) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Schedule WHERE TeacherName=?");
        stm.setObject(1, teacherName);
        ResultSet rst = stm.executeQuery();
        ArrayList<TimeTable> timeTables = new ArrayList<>();
        while (rst.next()) {
            timeTables.add(new TimeTable(rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4), LocalTime.parse(rst.getString(5)), LocalTime.parse(rst.getString(6)), rst.getInt(7)));
        }
        return timeTables;
    }

    @Override
    public List<TimeTable> getTimeTableByDate(LocalDate newValue) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM Schedule WHERE date=?");
        stm.setObject(1, newValue);
        ResultSet rst = stm.executeQuery();
        ArrayList<TimeTable> timeTables = new ArrayList<>();
        while (rst.next()) {
            timeTables.add(new TimeTable(rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4), LocalTime.parse(rst.getString(5)), LocalTime.parse(rst.getString(6)), rst.getInt(7)));
        }
        return timeTables;
    }
}
