package controller;

import Notification.NotificationBuilder;
import animatefx.animation.ZoomIn;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTimePicker;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import model.Teacher;
import model.TimeTable;
import org.controlsfx.control.Notifications;
import view.TM.TimeTableTM;

import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class TimeTableManageFormController {

    public TableView<TimeTableTM> tblTimeTable;
    public ComboBox<String> cmbTeacherName;
    public TextField txtTeacherId;
    public TextField txtSubject;
    public JFXDatePicker date;
    public JFXTimePicker startTime;
    public JFXTimePicker endTime;
    public JFXButton btnAddToTimeTable;
    public ComboBox<Integer> cmbGrade;
    public TableColumn colTeacherId;
    public TableColumn colTeacherName;
    public TableColumn colSubject;
    public TableColumn colDate;
    public TableColumn colStartTime;
    public TableColumn colEndTime;
    public TableColumn colGrade;
    public ComboBox<String> cmbSearchTeacherName;
    public JFXDatePicker searchDate;

    public void initialize() {
        btnAddToTimeTable.setDisable(true);
        loadTeacherNames();
        date.setEditable(false);
        startTime.setEditable(false);
        endTime.setEditable(false);
        cmbGrade.getItems().addAll(6, 7, 8, 9, 10, 11);
        try {
            loadDataToTable(new TimeTableController().getTimeTable());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        cmbTeacherName.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            search(newValue);
            if (!cmbGrade.getSelectionModel().isEmpty() && date.getValue() != null && startTime.getValue() != null && endTime.getValue() != null) {
                btnAddToTimeTable.setDisable(false);
            }
        });
        cmbGrade.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (!cmbTeacherName.getSelectionModel().isEmpty() && date.getValue() != null && startTime.getValue() != null && endTime.getValue() != null) {
                btnAddToTimeTable.setDisable(false);
            }
        });
        date.valueProperty().addListener((observable, oldValue, newValue) -> {
            if (!cmbTeacherName.getSelectionModel().isEmpty() && !cmbGrade.getSelectionModel().isEmpty() && startTime.getValue() != null && endTime.getValue() != null && date.getValue() != null) {
                btnAddToTimeTable.setDisable(false);
            }
            if (startTime.getValue() != null && date.getValue() != null) {
                searchData(startTime.getValue(), date.getValue());
            }
        });
        startTime.valueProperty().addListener((observable, oldValue, newValue) -> {
            if (!cmbTeacherName.getSelectionModel().isEmpty() && !cmbGrade.getSelectionModel().isEmpty() && date.getValue() != null && endTime.getValue() != null && startTime.getValue() != null) {
                btnAddToTimeTable.setDisable(false);
            }
            if (date.getValue() != null && startTime.getValue() != null) {
                searchData(startTime.getValue(), date.getValue());
            }
        });
        endTime.valueProperty().addListener((observable, oldValue, newValue) -> {
            if (!cmbTeacherName.getSelectionModel().isEmpty() && !cmbGrade.getSelectionModel().isEmpty() && date.getValue() != null && startTime.getValue() != null && endTime.getValue() != null) {
                btnAddToTimeTable.setDisable(false);
            }
        });
        cmbSearchTeacherName.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (!cmbSearchTeacherName.getSelectionModel().isEmpty()) {
                searchByTeacherNameOnAction(newValue);
            }
        });
        searchDate.valueProperty().addListener((observable, oldValue, newValue) -> {
            if (searchDate.getValue() != null) {
                searchByDateOnAction(newValue);
            }
        });
        new ZoomIn(tblTimeTable).play();
    }

    private void searchData(LocalTime startTime, LocalDate date) {
        try {
            List<TimeTable> timeTables = new TimeTableController().getTimeTableData(startTime, date);
            ObservableList<TimeTableTM> obList = FXCollections.observableArrayList();
            timeTables.forEach(e -> {
                obList.add(new TimeTableTM(e.getTeacherId(), e.getTeacherName(), e.getSubjectName(), e.getDate(), e.getStartTime(), e.getEndTime(), e.getGrade()));
            });
            tblTimeTable.setItems(obList);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void loadDataToTable(ArrayList<TimeTable> timeTables) {
        ObservableList<TimeTableTM> obList = FXCollections.observableArrayList();
        timeTables.forEach(e -> {
            obList.add(new TimeTableTM(e.getTeacherId(), e.getTeacherName(), e.getSubjectName(), e.getDate(), e.getStartTime(), e.getEndTime(), e.getGrade()));
        });
        tblTimeTable.setItems(obList);
        initCols();
    }

    private void initCols() {
        colTeacherId.setCellValueFactory(new PropertyValueFactory<>("teacherId"));
        colTeacherName.setCellValueFactory(new PropertyValueFactory<>("teacherName"));
        colSubject.setCellValueFactory(new PropertyValueFactory<>("subjectName"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("date"));
        colStartTime.setCellValueFactory(new PropertyValueFactory<>("startTime"));
        colEndTime.setCellValueFactory(new PropertyValueFactory<>("endTime"));
        colGrade.setCellValueFactory(new PropertyValueFactory<>("grade"));
    }

    private void search(String newValue) {
        try {
            if (!cmbTeacherName.getSelectionModel().isEmpty()) {
                Teacher teacher = new TeacherController().getTeacherDetails(newValue);
                txtTeacherId.setText(teacher.getTeacherId());
                txtSubject.setText(teacher.getSubject());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void loadTeacherNames() {
        try {
            List<String> teacherNames = new TeacherController().getTeacherNames();
            cmbTeacherName.getItems().addAll(teacherNames);
            cmbSearchTeacherName.getItems().addAll(teacherNames);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void addToTimeTableOnAction(MouseEvent mouseEvent) {
        TimeTable timeTable = new TimeTable(txtTeacherId.getText(), cmbTeacherName.getSelectionModel().getSelectedItem(), txtSubject.getText(), String.valueOf(date.getValue()), startTime.getValue(), endTime.getValue(), cmbGrade.getSelectionModel().getSelectedItem());
        try {
            if (new TimeTableController().addToTimeTable(timeTable)) {
                Notifications information = NotificationBuilder.notifyMassage("INFORMATION", "Add to timetable successfully");
                information.showInformation();
                cmbTeacherName.getSelectionModel().clearSelection();
                cmbGrade.getSelectionModel().clearSelection();
                txtTeacherId.clear();
                txtSubject.clear();
                date.setValue(null);
                startTime.setValue(null);
                endTime.setValue(null);
                btnAddToTimeTable.setDisable(true);
                loadDataToTable(new TimeTableController().getTimeTable());
            } else {
                Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Try again");
                warning.showWarning();
            }
        } catch (SQLIntegrityConstraintViolationException e) {
            Notifications error = NotificationBuilder.notifyMassage("ERROR", "Time and Date you entered is allocated previously.Please try again");
            error.showError();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void clearOnAction(MouseEvent mouseEvent) {
        cmbTeacherName.getSelectionModel().clearSelection();
        date.setValue(null);
        startTime.setValue(null);
        endTime.setValue(null);
        txtSubject.clear();
        txtTeacherId.clear();
        btnAddToTimeTable.setDisable(true);
        try {
            loadDataToTable(new TimeTableController().getTimeTable());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void refreshTableOnAction(ActionEvent actionEvent) {
        try {
            loadDataToTable(new TimeTableController().getTimeTable());
            cmbSearchTeacherName.getSelectionModel().clearSelection();
            /*searchDate.setValue(LocalDate.now());
            searchDate.getEditor().clear();*/
            searchDate.setValue(null);

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void deleteRawOnAction(ActionEvent actionEvent) {
        TimeTableTM selectedItem = tblTimeTable.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            Notifications error = NotificationBuilder.notifyMassage("ERROR", "No raw selected.");
            error.showError();
        } else {
            try {
                if (new TimeTableController().deleteTimeTableRaw(selectedItem)) {
                    Notifications information = NotificationBuilder.notifyMassage("INFORMATION", "Raw deleted successfully");
                    information.showInformation();
                    loadDataToTable(new TimeTableController().getTimeTable());
                    cmbSearchTeacherName.getSelectionModel().clearSelection();
                    searchDate.setValue(null);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    public void searchByTeacherNameOnAction(String newValue) {
        try {
            List<TimeTable> timeTables = new TimeTableController().getTimeTableByTeacherName(newValue);
            ObservableList<TimeTableTM> obList = FXCollections.observableArrayList();
            timeTables.forEach(e -> {
                obList.add(new TimeTableTM(e.getTeacherId(), e.getTeacherName(), e.getSubjectName(), e.getDate(), e.getStartTime(), e.getEndTime(), e.getGrade()));
            });
            tblTimeTable.setItems(obList);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void searchByDateOnAction(LocalDate newValue) {
        try {
            List<TimeTable> timeTables = new TimeTableController().getTimeTableByDate(newValue);
            ObservableList<TimeTableTM> obList = FXCollections.observableArrayList();
            timeTables.forEach(e -> {
                obList.add(new TimeTableTM(e.getTeacherId(), e.getTeacherName(), e.getSubjectName(), e.getDate(), e.getStartTime(), e.getEndTime(), e.getGrade()));
            });
            tblTimeTable.setItems(obList);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
