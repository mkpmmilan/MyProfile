package controller;

import Notification.NotificationBuilder;
import Validation.ValidationUtil;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import javafx.event.ActionEvent;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import model.Employee;
import org.controlsfx.control.Notifications;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.regex.Pattern;

public class UpdateEmployeeFormController {

    public TextField txtEmployeeId;
    public TextField txtName;
    public TextField txtAddress;
    public TextField txtJobRole;
    public TextField txtContact;
    public JFXDatePicker dateOfBirth;
    public JFXComboBox<String> cmbGender;
    public JFXButton btnUpdate;

    LinkedHashMap<TextField, Pattern> map = new LinkedHashMap<>();
    Pattern employeeNamePattern = Pattern.compile("^[A-z ]{3,}$");
    Pattern jobRolePattern = Pattern.compile("^[A-z ]{3,}$");
    Pattern addressPattern = Pattern.compile("^[A-z0-9, ]{3,}$");
    Pattern contactPattern = Pattern.compile("^(07)[0-9](-)[0-9]{7}$");

    public void initialize() {
        btnUpdate.setDisable(true);
        storeValidations();
        cmbGender.getItems().addAll("Male", "Female");
    }

    private void storeValidations() {
        map.put(txtName, employeeNamePattern);
        map.put(txtAddress, addressPattern);
        map.put(txtJobRole, jobRolePattern);
        map.put(txtContact, contactPattern);
    }

    public void textFieldValidationOnAction(KeyEvent keyEvent) {
        Object response = ValidationUtil.validateTextField(map, btnUpdate);
        if (keyEvent.getCode() == KeyCode.ENTER) {
            if (response instanceof TextField) {
                TextField errorText = (TextField) response;
                errorText.requestFocus();
            } else if (response instanceof Boolean) {
                Notifications confirmation = NotificationBuilder.notifyMassage("CONFIRMATION", "All the text fields are filled successfully.");
                confirmation.showConfirm();
            }
        }
    }

    public void updateEmployeeOnAction(ActionEvent actionEvent) {
        if (dateOfBirth != null) {
            if (!cmbGender.getSelectionModel().isEmpty()) {
                Employee employee = new Employee(txtEmployeeId.getText(), txtName.getText(), txtJobRole.getText(), txtAddress.getText(), txtContact.getText(), cmbGender.getSelectionModel().getSelectedItem(), String.valueOf(dateOfBirth.getValue()));
                try {
                    if (new EmployeeController().updateEmployee(employee)) {
                        Notifications information = NotificationBuilder.notifyMassage("CONFIRMATION", "Employee details Update Successfully");
                        information.showInformation();
                        txtEmployeeId.clear();
                        txtName.clear();
                        txtAddress.clear();
                        txtJobRole.clear();
                        txtContact.clear();
                        cmbGender.getSelectionModel().clearSelection();
                        dateOfBirth.getEditor().clear();
                        btnUpdate.setDisable(true);
                    } else {
                        Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Try again");
                        warning.showWarning();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            } else {
                Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please select gender");
                warning.showWarning();
            }
        } else {
            Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please select date of birth");
            warning.showWarning();
        }

    }
}
