package controller;

import Notification.NotificationBuilder;
import Validation.ValidationUtil;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import model.Student;
import org.controlsfx.control.Notifications;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.regex.Pattern;

public class UpdateStudentFormController {

    public TextField txtStudentId;
    public TextField txtSurname;
    public TextField txtStudentName;
    public TextField txtEmail;
    public TextField txtAddress;
    public TextField txtGuardianName;
    public TextField txtGuardianContact;
    public JFXDatePicker dateOfBirth;
    public JFXComboBox<Integer> cmbGrade;
    public JFXComboBox<String> cmbGender;
    public TextField txtSubjects;
    public TextField txtTeachers;
    public JFXButton btnUpdateStudent;
    public ComboBox<String> cmbSubjects;
    public ComboBox<String> cmbTeachers;

    LinkedHashMap<TextField, Pattern> map = new LinkedHashMap<>();
    Pattern surnamePattern = Pattern.compile("^[A-z ]{3,}$");
    Pattern studentNamePattern = Pattern.compile("^[A-z ]{3,}$");
    Pattern emailPattern = Pattern.compile("^[a-z0-9]{3,}(@)[a-z]{3,}(.)[a-z]{2,3}$");
    Pattern addressPattern = Pattern.compile("^[A-z0-9, ]{3,}$");
    Pattern contactPattern = Pattern.compile("^(07)[0-9](-)[0-9]{7}$");
    Pattern guardianNamePattern = Pattern.compile("^[A-z .]{4,}$");
    Pattern teacherPattern = Pattern.compile("^[A-z, ]{3,}");
    Pattern subjectPattern = Pattern.compile("^[A-z, ]{3,}");

    public void initialize() {
        storeValidations();
        cmbGrade.getItems().addAll(6, 7, 8, 9, 10, 11);
        cmbGender.getItems().addAll("Male", "Female");
        try {
            loadSubjects();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        try {
            loadTeachers();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void storeValidations() {
        map.put(txtSurname, surnamePattern);
        map.put(txtStudentName, studentNamePattern);
        map.put(txtEmail, emailPattern);
        map.put(txtAddress, addressPattern);
        map.put(txtGuardianName, guardianNamePattern);
        map.put(txtGuardianContact, contactPattern);
        map.put(txtSubjects, subjectPattern);
        map.put(txtTeachers, teacherPattern);
    }

    private void loadTeachers() throws SQLException, ClassNotFoundException {
        List<String> teacherNames = new TeacherController().getTeacherNames();
        cmbTeachers.getItems().addAll(teacherNames);
    }

    private void loadSubjects() throws SQLException, ClassNotFoundException {
        List<String> subjectNames = new SubjectController().getSubjectNames();
        cmbSubjects.getItems().addAll(subjectNames);
    }

    public void textFieldValidationOnAction(KeyEvent keyEvent) {
        Object response = ValidationUtil.validateTextField(map, btnUpdateStudent);
        if (keyEvent.getCode() == KeyCode.ENTER) {
            if (response instanceof TextField) {
                TextField errorText = (TextField) response;
                errorText.requestFocus();
            } else if (response instanceof Boolean) {
                Notifications confirmation = NotificationBuilder.notifyMassage("CONFIRMATION", "All the text fields are filled successfully.");
                confirmation.showConfirm();
            }
        }
    }

    public void updateStudentOnAction(MouseEvent mouseEvent) {
        if (dateOfBirth.getValue() != null) {
            if (!cmbGrade.getSelectionModel().isEmpty()) {
                if (!cmbGender.getSelectionModel().isEmpty()) {
                    Student student = new Student(txtStudentId.getText(), txtSurname.getText(), txtStudentName.getText(), txtEmail.getText(), txtAddress.getText(), String.valueOf(dateOfBirth.getValue()), cmbGrade.getSelectionModel().getSelectedItem(), cmbGender.getSelectionModel().getSelectedItem(), txtGuardianName.getText(), txtGuardianContact.getText(), txtTeachers.getText(), txtSubjects.getText());
                    if (new StudentController().updateStudent(student)) {
                        Notifications information = NotificationBuilder.notifyMassage("CONFIRMATION", "Student details Update Successfully");
                        information.showInformation();
                        txtTeachers.clear();
                        txtSubjects.clear();
                        txtEmail.clear();
                        txtAddress.clear();
                        txtStudentName.clear();
                        txtGuardianContact.clear();
                        txtGuardianName.clear();
                        txtSurname.clear();
                        txtStudentId.clear();
                        dateOfBirth.getEditor().clear();
                        cmbGender.getSelectionModel().clearSelection();
                        cmbGrade.getSelectionModel().clearSelection();
                        btnUpdateStudent.setDisable(true);
                    } else {
                        Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Try again");
                        warning.showWarning();
                    }
                } else {
                    Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please select gender");
                    warning.showWarning();
                }
            } else {
                Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please select grade");
                warning.showWarning();
            }
        } else {
            Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Please select date of birth");
            warning.showWarning();
        }
    }

    public void addSubjectToTextField(MouseEvent mouseEvent) {
        String concat = txtSubjects.getText().concat(cmbSubjects.getSelectionModel().getSelectedItem());
        txtSubjects.setText(concat);
        cmbSubjects.getSelectionModel().clearSelection();
    }

    public void addTeacherToTextField(MouseEvent mouseEvent) {
        String concat = txtTeachers.getText().concat(cmbTeachers.getSelectionModel().getSelectedItem());
        txtTeachers.setText(concat);
        cmbTeachers.getSelectionModel().clearSelection();
    }
}
