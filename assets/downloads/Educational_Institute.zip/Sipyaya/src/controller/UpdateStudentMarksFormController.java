package controller;

import Notification.NotificationBuilder;
import Validation.ValidationUtil;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import model.EvaluationMark;
import org.controlsfx.control.Notifications;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.regex.Pattern;

public class UpdateStudentMarksFormController {

    public TextField txtStudentId;
    public TextField txtStudentName;
    public TextField txtSubject;
    public TextField txtGrade;
    public JFXComboBox<String> cmbMonth;
    public TextField txtMarks;
    public JFXButton btnUpdate;
    public TextField txtTeacher;

    LinkedHashMap<TextField, Pattern> map = new LinkedHashMap<>();
    Pattern marksPattern = Pattern.compile("^([0-9]{1,2}|100)$");

    public void initialize() {
        btnUpdate.setDisable(true);
        cmbMonth.getItems().addAll("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
        storeValidation();
        cmbMonth.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (!txtMarks.getText().isEmpty()) {
                btnUpdate.setDisable(false);
            }
        });
    }

    private void storeValidation() {
        map.put(txtMarks, marksPattern);
    }

    public void textFieldOnValidation(KeyEvent keyEvent) {
        Object response = ValidationUtil.validateTextField(map, btnUpdate);
        if (keyEvent.getCode() == KeyCode.ENTER) {
            if (response instanceof TextField) {
                TextField errorText = (TextField) response;
                errorText.requestFocus();
            } else if (response instanceof Boolean) {

            }
        }
    }

    public void updateMarksOnAction(MouseEvent mouseEvent) {
        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(new Date());
        EvaluationMark mark = new EvaluationMark(txtStudentId.getText(), txtStudentName.getText(), txtSubject.getText(), Integer.parseInt(txtGrade.getText()), cmbMonth.getSelectionModel().getSelectedItem(), date, Integer.parseInt(txtMarks.getText()), txtTeacher.getText());
        try {
            if (new MarksController().updateMarks(mark)) {
                Notifications information = NotificationBuilder.notifyMassage("INFORMATION", "Marks updated successfully");
                information.showInformation();
                txtStudentId.clear();
                txtStudentName.clear();
                txtGrade.clear();
                txtSubject.clear();
                txtMarks.clear();
                txtTeacher.clear();
                cmbMonth.getItems().clear();
                btnUpdate.setDisable(true);
            } else {
                Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Try again");
                warning.showWarning();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
