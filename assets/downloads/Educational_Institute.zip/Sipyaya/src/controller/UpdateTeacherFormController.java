package controller;

import Notification.NotificationBuilder;
import Validation.ValidationUtil;
import com.jfoenix.controls.JFXButton;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import model.Teacher;
import org.controlsfx.control.Notifications;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.regex.Pattern;

public class UpdateTeacherFormController {

    public TextField txtTeacherId;
    public TextField txtTeacherName;
    public TextField txtTeacherEmail;
    public TextField txtTeacherContact;
    public ComboBox<String> cmbSubjects;
    public JFXButton btnUpdateTeacher;
    public TextField txtTeacherAddress;
    public TextField txtClassFees;

    LinkedHashMap<TextField, Pattern> map = new LinkedHashMap<>();
    Pattern teacherNamePattern = Pattern.compile("^[A-z .]{3,}$");
    Pattern teacherAddressPattern = Pattern.compile("^[A-z0-9, ]{3,}$");
    Pattern teacherContactPattern = Pattern.compile("^(07)[0-9](-)[0-9]{7}$");
    Pattern teacherEmailPattern = Pattern.compile("^[a-z0-9]{3,}(@)[a-z]{3,}(.)[a-z]{2,3}$");
    Pattern classFeePattern = Pattern.compile("^[1-9][0-9]*([.][0-9]{2})?$");

    public void initialize() {
        try {
            loadSubjects();
            storeValidations();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void storeValidations() {
        map.put(txtTeacherName, teacherNamePattern);
        map.put(txtTeacherEmail, teacherEmailPattern);
        map.put(txtTeacherAddress, teacherAddressPattern);
        map.put(txtTeacherContact, teacherContactPattern);
        map.put(txtClassFees, classFeePattern);
    }

    private void loadSubjects() throws SQLException, ClassNotFoundException {
        List<String> subjectNames = new SubjectController().getSubjectNames();
        cmbSubjects.getItems().addAll(subjectNames);
    }

    public void textFieldsValidationOnAction(KeyEvent keyEvent) {
        Object response = ValidationUtil.validateTextField(map, btnUpdateTeacher);
        if (keyEvent.getCode() == KeyCode.ENTER) {
            if (response instanceof TextField) {
                TextField errorText = (TextField) response;
                errorText.requestFocus();
            } else if (response instanceof Boolean) {
                Notifications confirmation = NotificationBuilder.notifyMassage("CONFIRMATION", "All the text fields are filled successfully.");
                confirmation.showConfirm();
            }
        }
    }

    public void updateTeacherOnAction(MouseEvent mouseEvent) {
        if (!cmbSubjects.getSelectionModel().isEmpty()) {
            try {
                Teacher teacher = new Teacher(txtTeacherId.getText(), txtTeacherName.getText(), txtTeacherAddress.getText(), txtTeacherContact.getText(), txtTeacherEmail.getText(), cmbSubjects.getSelectionModel().getSelectedItem(), Double.parseDouble(txtClassFees.getText()));
                if (new TeacherController().updateTeacher(teacher)) {
                    Notifications information = NotificationBuilder.notifyMassage("CONFIRMATION", "Teacher details Update Successfully");
                    information.showInformation();
                    txtTeacherId.clear();
                    txtTeacherName.clear();
                    txtTeacherEmail.clear();
                    txtTeacherAddress.clear();
                    txtTeacherContact.clear();
                    txtClassFees.clear();
                    cmbSubjects.getSelectionModel().clearSelection();
                } else {
                    Notifications warning = NotificationBuilder.notifyMassage("WARNING", "Try again");
                    warning.showWarning();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
}
