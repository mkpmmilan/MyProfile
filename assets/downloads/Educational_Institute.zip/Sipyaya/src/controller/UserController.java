package controller;

import Database.DbConnection;
import model.User;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserController {

    public static boolean signupUser(User user) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("INSERT INTO `User detail` VALUES (?,?,?,?,?)");
        stm.setObject(1, user.getFirstName());
        stm.setObject(2, user.getLastName());
        stm.setObject(3, user.getUsername());
        stm.setObject(4, user.getPassword());
        stm.setObject(5, user.getUserType());
        return stm.executeUpdate() > 0;
    }

    public User getUser(String userName) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("SELECT * FROM `User detail` WHERE userName=?");
        stm.setObject(1, userName);
        ResultSet rst = stm.executeQuery();
        User user = null;
        while (rst.next()) {
            user = new User(rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4), rst.getString(5));
        }
        return user;
    }

    public boolean updatePassword(User user) throws SQLException, ClassNotFoundException {
        PreparedStatement stm = DbConnection.getInstance().getConnection().prepareStatement("UPDATE `User detail` SET password=? WHERE userName=?");
        stm.setObject(1, user.getPassword());
        stm.setObject(2, user.getUsername());
        return stm.executeUpdate() > 0;
    }
}
