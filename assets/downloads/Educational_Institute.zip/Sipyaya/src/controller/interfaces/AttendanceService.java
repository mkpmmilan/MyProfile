package controller.interfaces;

import model.Attendance;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public interface AttendanceService {
    boolean markAttendance(Attendance attendance) throws SQLException, ClassNotFoundException;

    ArrayList<Attendance> getAttendances() throws SQLException, ClassNotFoundException;

    boolean deleteAttendance(String studentId, String studentName, String subject, String date, String time) throws SQLException, ClassNotFoundException;

    List<Attendance> searchAttendances(String newValue) throws SQLException, ClassNotFoundException;

}
