package controller.interfaces;

import javafx.scene.control.TextField;
import model.Employee;
import model.EmployeeSalary;
import view.TM.EmployeeSalaryTM;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public interface EmployeeService {
    String setEmployeeId() throws SQLException, ClassNotFoundException;

    boolean addEmployee(Employee employee) throws SQLException, ClassNotFoundException;

    ArrayList<Employee> getAllEmployees() throws SQLException, ClassNotFoundException;

    List<Employee> search(String newValue) throws SQLException, ClassNotFoundException;

    Employee getEmployee(String employeeId) throws SQLException, ClassNotFoundException;

    boolean updateEmployee(Employee employee) throws SQLException, ClassNotFoundException;

    boolean deleteEmployee(String employeeId) throws SQLException, ClassNotFoundException;

    List<String> getEmployeeNames() throws SQLException, ClassNotFoundException;

    void getJobRole(String newValue, TextField txtSubject) throws SQLException, ClassNotFoundException;

    String getJobRole(String newValue) throws SQLException, ClassNotFoundException;

    boolean addEmployeeSalary(EmployeeSalary employeeSalary) throws SQLException, ClassNotFoundException;

    ArrayList<EmployeeSalary> getAllEmployeeSalary() throws SQLException, ClassNotFoundException;

    List<EmployeeSalary> searchEmployeeSalary(Integer year, String month, TextField txtEmployeeNetSalary) throws SQLException, ClassNotFoundException;

    boolean deleteEmployeeSalary(EmployeeSalaryTM selectedItem) throws SQLException, ClassNotFoundException;

    double getTotalSalary(int year, String month) throws SQLException, ClassNotFoundException;

    double getAnnualEmployeeSalary(int year) throws SQLException, ClassNotFoundException;

    double getSumOfSalary(String fDate, String tDate) throws SQLException, ClassNotFoundException;
}
