package controller.interfaces;

import javafx.scene.control.TextField;
import model.Expense;
import view.TM.ExpenseTM;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public interface ExpensesService {

    boolean addExpenses(Expense expense) throws SQLException, ClassNotFoundException;

    ArrayList<Expense> getAllExpenses() throws SQLException, ClassNotFoundException;

    List<Expense> getAllExpensesBySearch(LocalDate fromDate, LocalDate toDate, TextField txtTotalExpenses) throws SQLException, ClassNotFoundException;

    boolean deleteExpense(ExpenseTM selectedItem) throws SQLException, ClassNotFoundException;

    double getAllCash(String day) throws SQLException, ClassNotFoundException;

    double getExpenses(int year, String month) throws SQLException, ClassNotFoundException;

    double getAnnualExpenses(int year) throws SQLException, ClassNotFoundException;

    double getTotalExpenses(String fDate, String tDate) throws SQLException, ClassNotFoundException;
}
