package controller.interfaces;

import model.EvaluationMark;
import view.TM.EvaluationMarkTM;

import java.sql.SQLException;
import java.util.ArrayList;

public interface MarksService {
    boolean addMarks(EvaluationMark mark) throws SQLException, ClassNotFoundException;

    ArrayList<EvaluationMark> getMarks() throws SQLException, ClassNotFoundException;

    boolean updateMarks(EvaluationMark mark) throws SQLException, ClassNotFoundException;

    boolean deleteMarks(EvaluationMarkTM selectedItem) throws SQLException, ClassNotFoundException;
}
