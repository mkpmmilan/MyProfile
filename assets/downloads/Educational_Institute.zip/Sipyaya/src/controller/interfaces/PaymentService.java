package controller.interfaces;

import com.jfoenix.controls.JFXDatePicker;
import javafx.scene.control.TextField;
import model.Payment;
import model.Student;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public interface PaymentService {
    ArrayList<Payment> getAllPayments() throws SQLException, ClassNotFoundException;

    boolean deletePayment(String cardNo) throws SQLException, ClassNotFoundException;

    boolean setPayment(Payment payment) throws SQLException, ClassNotFoundException;

    List<Payment> searchPaymentsDetails(String studentId, String studentName, String subject) throws SQLException, ClassNotFoundException;

    List<Payment> searchPayments(String newValue) throws SQLException, ClassNotFoundException;

    List<Payment> getSearchPayments(LocalDate fromDateValue, LocalDate toDateValue, TextField txtTotalCash) throws SQLException, ClassNotFoundException;

    double getPayments(String monthValue, Integer yearValue, String teacherName) throws SQLException, ClassNotFoundException;

    double getPaymentCash(String day) throws SQLException, ClassNotFoundException;

    double getTotalPayment(int year, String month) throws SQLException, ClassNotFoundException;

    double getAnnualPayments(int year) throws SQLException, ClassNotFoundException;

    double getSumOfPayments(int grade, String fDate, String tDate) throws SQLException, ClassNotFoundException;
}
