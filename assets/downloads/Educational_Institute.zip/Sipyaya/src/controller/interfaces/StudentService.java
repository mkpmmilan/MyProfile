package controller.interfaces;

import javafx.scene.control.Label;
import model.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public interface StudentService {
    public String setStudentId() throws SQLException, ClassNotFoundException;

    boolean addStudent(Student student);

    ArrayList<Student> getAllStudents() throws SQLException, ClassNotFoundException;

    List<Student> searchStudents(String newValue) throws SQLException, ClassNotFoundException;

    Student getStudent(String studentId) throws SQLException, ClassNotFoundException;

    boolean updateStudent(Student student) throws SQLException, ClassNotFoundException;

    Student searchStudentWithAdmissionDate(String studentId) throws SQLException, ClassNotFoundException;

    boolean deleteStudent(String studentId) throws SQLException, ClassNotFoundException;

    ArrayList<StudentDetail> getAllStudentDetails() throws SQLException, ClassNotFoundException;

    void getStudentCount(Label lblStudents) throws SQLException, ClassNotFoundException;

    boolean updateStudentDetails(Student student) throws SQLException, ClassNotFoundException;

    boolean addStudentDetails(StudentDetail studentDetail) throws SQLException, ClassNotFoundException;

    List<StudentDetail> searchStudentDetails(String newValue) throws SQLException, ClassNotFoundException;

    double getRegistrationFees(String day) throws SQLException, ClassNotFoundException;

    double getRegistrationCash(int year, String month) throws SQLException, ClassNotFoundException;

    double getAnnualRegistrationFee(int year) throws SQLException, ClassNotFoundException;
}
