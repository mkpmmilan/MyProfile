package controller.interfaces;


import javafx.scene.control.Label;
import model.Subject;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public interface SubjectService {
    public boolean addSubject(Subject s) throws SQLException, ClassNotFoundException;

    public boolean deleteSubject(String code) throws SQLException, ClassNotFoundException;

    public ArrayList<Subject> getAllSubjects() throws SQLException, ClassNotFoundException;

    public List<String> getSubjectNames() throws SQLException, ClassNotFoundException;

    void getSubjectCount(Label lblSubjects) throws SQLException, ClassNotFoundException;

    String setSubjectCodes() throws SQLException, ClassNotFoundException;
}
