package controller.interfaces;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import model.Teacher;
import model.TeacherSalary;
import model.TimeTable;
import view.TM.TeacherSalaryTM;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public interface TeacherService {
    public String setTeacherId() throws SQLException, ClassNotFoundException;

    public boolean addTeacher(Teacher teacher) throws SQLException, ClassNotFoundException;

    public ArrayList<Teacher> getAllTeachers() throws SQLException, ClassNotFoundException;

    public boolean updateTeacher(Teacher teacher) throws SQLException, ClassNotFoundException;

    public boolean deleteTeacher(String teacherId) throws SQLException, ClassNotFoundException;

    void getTeacherCount(Label lblTeachers) throws SQLException, ClassNotFoundException;

    Teacher getTeacherDetails(String newValue) throws SQLException, ClassNotFoundException;

    void getSubject(String newValue, TextField txtSubject) throws SQLException, ClassNotFoundException;

    String getSubject(String newValue) throws SQLException, ClassNotFoundException;

    boolean addTeacherSalary(TeacherSalary teacherSalary) throws SQLException, ClassNotFoundException;

    ArrayList<TeacherSalary> getAllTeacherSalary() throws SQLException, ClassNotFoundException;

    List<TeacherSalary> searchTeacherSalary(Integer year, String month, TextField txtTeacherNetSalary) throws SQLException, ClassNotFoundException;

    boolean deleteSalary(TeacherSalaryTM selectedItem) throws SQLException, ClassNotFoundException;

    List<Teacher> searchTeacher(String newValue) throws SQLException, ClassNotFoundException;

    List<String> getTeacherNames() throws SQLException, ClassNotFoundException;

    List<String> getTeacherNamesBySubjects(String newValue) throws SQLException, ClassNotFoundException;

    void getClassFees(String newValue, TextField txtCash) throws SQLException, ClassNotFoundException;

    double getTotalSalary(int year, String month) throws SQLException, ClassNotFoundException;

    double getAnnualTeacherSalary(int year) throws SQLException, ClassNotFoundException;

    double getSumOfSalary(String fDate, String tDate) throws SQLException, ClassNotFoundException;
}
