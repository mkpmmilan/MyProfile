package controller.interfaces;

import model.TimeTable;
import view.TM.TimeTableTM;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public interface TimeTableService {
    boolean addToTimeTable(TimeTable timeTable) throws SQLException, ClassNotFoundException;

    ArrayList<TimeTable> getTimeTable() throws SQLException, ClassNotFoundException;

    List<TimeTable> getTimeTableData(LocalTime startTime, LocalDate date) throws SQLException, ClassNotFoundException;

    boolean deleteTimeTableRaw(TimeTableTM selectedItem) throws SQLException, ClassNotFoundException;

    List<TimeTable> getTimeTableByTeacherName(String teacherName) throws SQLException, ClassNotFoundException;

    List<TimeTable> getTimeTableByDate(LocalDate newValue) throws SQLException, ClassNotFoundException;
}
