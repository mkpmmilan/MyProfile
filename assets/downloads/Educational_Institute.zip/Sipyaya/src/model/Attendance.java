package model;

public class Attendance {
    private String studentId;
    private String studentName;
    private int grade;
    private String time;
    private String date;
    private String attendance;
    private String subject;

    public Attendance() {
    }

    public Attendance(String studentId, String studentName, int grade, String time, String date, String attendance, String subject) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.grade = grade;
        this.time = time;
        this.date = date;
        this.attendance = attendance;
        this.subject = subject;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getAttendance() {
        return attendance;
    }

    public void setAttendance(String attendance) {
        this.attendance = attendance;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
}
