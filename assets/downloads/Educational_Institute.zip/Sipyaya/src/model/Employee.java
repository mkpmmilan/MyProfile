package model;

public class Employee {
    private String employeeId;
    private String employeeName;
    private String jobRole;
    private String employeeAddress;
    private String contact;
    private String gender;
    private String dateOfBirth;

    public Employee() {
    }

    public Employee(String employeeId, String employeeName, String jobRole, String employeeAddress, String contact, String gender, String dateOfBirth) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.jobRole = jobRole;
        this.employeeAddress = employeeAddress;
        this.contact = contact;
        this.gender = gender;
        this.dateOfBirth = dateOfBirth;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getJobRole() {
        return jobRole;
    }

    public void setJobRole(String jobRole) {
        this.jobRole = jobRole;
    }

    public String getEmployeeAddress() {
        return employeeAddress;
    }

    public void setEmployeeAddress(String employeeAddress) {
        this.employeeAddress = employeeAddress;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }
}
