package model;

public class EmployeeSalary {
    private String employeeName;
    private String jobRole;
    private int year;
    private String month;
    private String date;
    private int workingDays;
    private double salaryPerDay;
    private double allowances;
    private double deductions;
    private double netSalary;

    public EmployeeSalary() {
    }

    public EmployeeSalary(String employeeName, String jobRole, int year, String month, String date, int workingDays, double salaryPerDay, double allowances, double deductions, double netSalary) {
        this.employeeName = employeeName;
        this.jobRole = jobRole;
        this.year = year;
        this.month = month;
        this.date = date;
        this.workingDays = workingDays;
        this.salaryPerDay = salaryPerDay;
        this.allowances = allowances;
        this.deductions = deductions;
        this.netSalary = netSalary;
    }

    @Override
    public String toString() {
        return "EmployeeSalary{" +
                "employeeName='" + employeeName + '\'' +
                ", jobRole='" + jobRole + '\'' +
                ", year=" + year +
                ", month='" + month + '\'' +
                ", date='" + date + '\'' +
                ", workingDays=" + workingDays +
                ", salaryPerDay=" + salaryPerDay +
                ", allowances=" + allowances +
                ", deductions=" + deductions +
                ", netSalary=" + netSalary +
                '}';
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getJobRole() {
        return jobRole;
    }

    public void setJobRole(String jobRole) {
        this.jobRole = jobRole;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getWorkingDays() {
        return workingDays;
    }

    public void setWorkingDays(int workingDays) {
        this.workingDays = workingDays;
    }

    public double getSalaryPerDay() {
        return salaryPerDay;
    }

    public void setSalaryPerDay(double salaryPerDay) {
        this.salaryPerDay = salaryPerDay;
    }

    public double getAllowances() {
        return allowances;
    }

    public void setAllowances(double allowances) {
        this.allowances = allowances;
    }

    public double getDeductions() {
        return deductions;
    }

    public void setDeductions(double deductions) {
        this.deductions = deductions;
    }

    public double getNetSalary() {
        return netSalary;
    }

    public void setNetSalary(double netSalary) {
        this.netSalary = netSalary;
    }
}
