package model;

public class EvaluationMark {
    private String studentId;
    private String studentName;
    private String subName;
    private int grade;
    private String month;
    private String issuedDate;
    private int mark;
    private String teacherName;

    public EvaluationMark() {
    }

    public EvaluationMark(String studentId, String studentName, String subName, int grade, String month, String issuedDate, int mark,String teacherName) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.subName = subName;
        this.grade = grade;
        this.month = month;
        this.issuedDate = issuedDate;
        this.mark = mark;
        this.setTeacherName(teacherName);
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getSubName() {
        return subName;
    }

    public void setSubName(String subName) {
        this.subName = subName;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getIssuedDate() {
        return issuedDate;
    }

    public void setIssuedDate(String issuedDate) {
        this.issuedDate = issuedDate;
    }

    public int getMark() {
        return mark;
    }

    public void setMark(int mark) {
        this.mark = mark;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }
}
