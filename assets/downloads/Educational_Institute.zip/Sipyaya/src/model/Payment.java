package model;

public class Payment {
    private String studentId;
    private String studentName;
    private String cardNo;
    private String subject;
    private int grade;
    private String date;
    private String time;
    private String month;
    private double cash;
    private String teacher;

    public Payment() {
    }

    public Payment(String studentId, String studentName, String cardNo, String subject, int grade, String date, String time, String month, double cash,String teacher) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.cardNo = cardNo;
        this.subject = subject;
        this.grade = grade;
        this.date = date;
        this.time = time;
        this.month = month;
        this.cash = cash;
        this.teacher=teacher;
    }
    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public double getCash() {
        return cash;
    }

    public void setCash(double cash) {
        this.cash = cash;
    }

    public String getTeacher() {
        return teacher;
    }

    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }
}
