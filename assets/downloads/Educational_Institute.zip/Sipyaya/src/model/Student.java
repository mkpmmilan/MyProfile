package model;

public class Student {
    private String studentId;
    private String surname;
    private String studentName;
    private String studentEmail;
    private String address;
    private String dateOfBirth;
    private int grade;
    private String gender;
    private String guardianName;
    private String guardianContact;
    private String teacherName;
    private String subjectName;
    private String admissionDate;
    private double registrationFee;

    public Student() {
    }

    public Student(String studentId, String surname, String studentName, String studentEmail, String address, String dateOfBirth, int grade, String gender, String guardianName, String guardianContact, String teacherName, String subjectName, String admissionDate) {
        this.studentId = studentId;
        this.surname = surname;
        this.studentName = studentName;
        this.studentEmail = studentEmail;
        this.address = address;
        this.dateOfBirth = dateOfBirth;
        this.grade = grade;
        this.gender = gender;
        this.guardianName = guardianName;
        this.guardianContact = guardianContact;
        this.teacherName = teacherName;
        this.subjectName = subjectName;
        this.admissionDate = admissionDate;
    }

    public Student(String studentId, String surname, String studentName, String studentEmail, String address, String dateOfBirth, int grade, String gender, String guardianName, String guardianContact, String teacherName, String subjectName) {
        this.studentId = studentId;
        this.surname = surname;
        this.studentName = studentName;
        this.studentEmail = studentEmail;
        this.address = address;
        this.dateOfBirth = dateOfBirth;
        this.grade = grade;
        this.gender = gender;
        this.guardianName = guardianName;
        this.guardianContact = guardianContact;
        this.teacherName = teacherName;
        this.subjectName = subjectName;
    }

    public Student(String studentId, String studentName, String address, String guardianContact, int grade, String subjectName, String teacherName) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.address = address;
        this.grade = grade;
        this.guardianContact = guardianContact;
        this.subjectName = subjectName;
        this.teacherName = teacherName;

    }

    public Student(String studentId, String surname, String studentName, String studentEmail, String address, String dateOfBirth, int grade, String gender, String guardianName, String guardianContact, String teacherName, String subjectName, String admissionDate, double registrationFee) {
        this.studentId = studentId;
        this.surname = surname;
        this.studentName = studentName;
        this.studentEmail = studentEmail;
        this.address = address;
        this.dateOfBirth = dateOfBirth;
        this.grade = grade;
        this.gender = gender;
        this.guardianName = guardianName;
        this.guardianContact = guardianContact;
        this.teacherName = teacherName;
        this.subjectName = subjectName;
        this.admissionDate = admissionDate;
        this.registrationFee = registrationFee;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public void setStudentEmail(String studentEmail) {
        this.studentEmail = studentEmail;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getGuardianName() {
        return guardianName;
    }

    public void setGuardianName(String guardianName) {
        this.guardianName = guardianName;
    }

    public String getGuardianContact() {
        return guardianContact;
    }

    public void setGuardianContact(String guardianContact) {
        this.guardianContact = guardianContact;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public double getRegistrationFee() {
        return registrationFee;
    }

    public void setRegistrationFee(double registrationFee) {
        this.registrationFee = registrationFee;
    }

    public String getAdmissionDate() {
        return admissionDate;
    }

    public void setAdmissionDate(String admissionDate) {
        this.admissionDate = admissionDate;
    }
}
