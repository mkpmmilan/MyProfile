package model;

public class Subject {
    private String subCode;
    private String subName;

    public Subject() {
    }

    public Subject(String subCode, String subName) {
        this.subCode = subCode;
        this.subName = subName;
    }

    public String getSubCode() {
        return subCode;
    }

    public void setSubCode(String subCode) {
        this.subCode = subCode;
    }

    public String getSubName() {
        return subName;
    }

    public void setSubName(String subName) {
        this.subName = subName;
    }
}
