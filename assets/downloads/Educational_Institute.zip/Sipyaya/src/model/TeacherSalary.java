package model;

public class TeacherSalary {
    private String teacherName;
    private int year;
    private String month;
    private String date;
    private double totalClassFees;
    private double percentage;
    private double deductions;
    private double netSalary;

    public TeacherSalary() {
    }

    public TeacherSalary(String teacherName, int year, String month, String date, double totalClassFees, double percentage, double deductions, double netSalary) {
        this.teacherName = teacherName;
        this.year = year;
        this.month = month;
        this.date = date;
        this.totalClassFees = totalClassFees;
        this.percentage = percentage;
        this.deductions = deductions;
        this.netSalary = netSalary;
    }

    @Override
    public String toString() {
        return "TeacherSalary{" +
                "teacherName='" + teacherName + '\'' +
                ", year=" + year +
                ", month='" + month + '\'' +
                ", date='" + date + '\'' +
                ", totalClassFees=" + totalClassFees +
                ", percentage=" + percentage +
                ", deductions=" + deductions +
                ", netSalary=" + netSalary +
                '}';
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public double getTotalClassFees() {
        return totalClassFees;
    }

    public void setTotalClassFees(double totalClassFees) {
        this.totalClassFees = totalClassFees;
    }

    public double getPercentage() {
        return percentage;
    }

    public void setPercentage(double percentage) {
        this.percentage = percentage;
    }

    public double getDeductions() {
        return deductions;
    }

    public void setDeductions(double deductions) {
        this.deductions = deductions;
    }

    public double getNetSalary() {
        return netSalary;
    }

    public void setNetSalary(double netSalary) {
        this.netSalary = netSalary;
    }
}
