DROP DATABASE IF EXISTS Sipyaya;
CREATE DATABASE IF NOT EXISTS Sipyaya;
SHOW DATABASES;
USE Sipyaya;

#--------------------------------------

DROP TABLE IF EXISTS `User detail`;
CREATE TABLE IF NOT EXISTS `User detail`(
    firstName VARCHAR (15),
    lastName VARCHAR (15),
    userName VARCHAR (15) PRIMARY KEY,
    password VARCHAR (15),
    userType VARCHAR (15)
);
SHOW TABLES;
DESCRIBE `User detail`;

#-------------------------------------

DROP TABLE IF EXISTS Student;
CREATE TABLE IF NOT EXISTS Student(
    Sid VARCHAR (15) NOT NULL,
    Surname TEXT,
    StudentName TEXT,
    studentEmail VARCHAR (50) default "No Email",
    Address TEXT,
    DateOfBirth DATE,
    Grade VARCHAR (10),
    Gender VARCHAR (10),
    GuardianName TEXT,
    GuardianContact VARCHAR (15),
    TeacherName TEXT,
    SubjectName TEXT,
    admissionDate DATE,
    RegistrationFee DECIMAL (20,2) NOT NULL,
    CONSTRAINT PRIMARY KEY (Sid)
);
SHOW TABLES;
DESCRIBE Student;

#-------------------------------------

DROP TABLE IF EXISTS Subject;
CREATE TABLE IF NOT EXISTS Subject(
    subId VARCHAR (15) PRIMARY KEY NOT NULL,
    subjectName TEXT NOT NULL
);
SHOW TABLES;
DESCRIBE Subject;

#-------------------------------------

DROP TABLE IF EXISTS Teacher;
CREATE TABLE IF NOT EXISTS Teacher(
    TeacherId VARCHAR (15) NOT NULL PRIMARY KEY ,
    TeacherName TEXT,
    teacherEmail VARCHAR (50) NOT NULL,
    teacherContact VARCHAR (15),
    teacherAddress TEXT,
    subName TEXT,
    ClassFees DECIMAL (20,2)
);
SHOW TABLES;
DESCRIBE Teacher;

#-------------------------------------

DROP TABLE IF EXISTS `Student Detail`;
CREATE TABLE IF NOT EXISTS `Student Detail`(
    StudentId VARCHAR (15),
    StudentName TEXT,
    TeacherName TEXT,
    Subject TEXT,
    grade VARCHAR (10),
    CONSTRAINT PRIMARY KEY (StudentId),
    CONSTRAINT FOREIGN KEY (StudentId) REFERENCES Student(Sid) ON DELETE CASCADE ON UPDATE CASCADE
);
SHOW TABLES;
DESCRIBE `Student Detail`;

#-------------------------------------

DROP TABLE IF EXISTS Payment;
CREATE TABLE IF NOT EXISTS Payment(
    studentId VARCHAR (15) NOT NULL,
    studentName TEXT,
    cardNo VARCHAR (15) PRIMARY KEY,
    subjectName TEXT,
    grade VARCHAR (10),
    Date DATE,
    Time TIME ,
    Month VARCHAR (15),
    Cash DECIMAL (20,2),
    TeacherName TEXT
);
SHOW TABLES;
DESCRIBE Payment;

#-------------------------------------

DROP TABLE IF EXISTS `Student Attendance`;
CREATE TABLE IF NOT EXISTS `Student Attendance`(
    StudentId VARCHAR (15) NOT NULL,
    StudentName TEXT,
    grade VARCHAR (10),
    Time TIME,
    Date DATE,
    Attendance VARCHAR (10),
    SubjectName TEXT
);
SHOW TABLES;
DESCRIBE `Student Attendance`;

#-------------------------------------

DROP TABLE IF EXISTS `Evaluation Mark`;
CREATE TABLE IF NOT EXISTS `Evaluation Mark`(
    StudentId VARCHAR (15) NOT NULL,
    StudentName TEXT,
    SubjectName TEXT,
    grade VARCHAR (10),
    Month VARCHAR (15),
    IssuedDate DATE,
    Marks VARCHAR (10),
    teacherName TEXT
);
SHOW TABLES;
DESCRIBE `Evaluation Mark`;

#-------------------------------------

DROP TABLE IF EXISTS Schedule;
CREATE TABLE IF NOT EXISTS Schedule(
    TeacherId VARCHAR (15),
    TeacherName TEXT,
    SubjectName TEXT,
    date DATE,
    StartTime TIME,
    EndTime TIME,
    Grade VARCHAR (10),
    CONSTRAINT PRIMARY KEY(date,StartTime,Grade)
);
SHOW TABLES;
DESCRIBE Schedule;

#-------------------------------------

DROP TABLE IF EXISTS `Teacher Salary`;
CREATE TABLE IF NOT EXISTS `Teacher Salary`(
    TeacherName TEXT,
    Year INT,
    Month VARCHAR (15),
    Date date,
    TotalClassFees DECIMAL (20,2),
    Percentage DECIMAL (10,2),
    Deductions DECIMAL (20,2),
    NetSalary DECIMAL (20,2)
);
SHOW TABLES;
DESCRIBE `Teacher Salary`;

#-------------------------------------

DROP TABLE IF EXISTS Employee;
CREATE TABLE IF NOT EXISTS Employee(
    EmployeeId VARCHAR (15) PRIMARY KEY NOT NULL,
    EmployeeName TEXT,
    EmployeeAddress TEXT,
    JobRole TEXT,
    Gender VARCHAR (10),
    DateOfBirth DATE,
    Contact VARCHAR (15)
);
SHOW TABLES;
DESCRIBE Employee;

#-------------------------------------

DROP TABLE IF EXISTS `Employee Salary`;
CREATE TABLE IF NOT EXISTS `Employee Salary`(
    EmployeeName TEXT,
    JobRole TEXT,
    Year INT,
    Month VARCHAR (15),
    Date date,
    WorkingDays INT (5),
    Salary_Per_Day DECIMAL (20,2),
    Allowances DECIMAL (20,2),
    Deductions DECIMAL (20,2),
    NetSalary DECIMAL(20,2)
);
SHOW TABLES;
DESCRIBE `Employee Salary`;

#-------------------------------------

DROP TABLE IF EXISTS Expenses;
CREATE TABLE IF NOT EXISTS Expenses(
    Date DATE,
    Description TEXT,
    Cash DECIMAL (20,2)
);
SHOW TABLES;
DESCRIBE Expenses;
