package view.TM;

public class EmployeeSalaryTM {
    private String employeeName;
    private String jobRole;
    private int workingDays;
    private double salaryPerDay;
    private String month;
    private String date;
    private double netSalary;

    public EmployeeSalaryTM() {
    }

    public EmployeeSalaryTM(String employeeName, String jobRole, int workingDays, double salaryPerDay, String month, String date, double netSalary) {
        this.employeeName = employeeName;
        this.jobRole = jobRole;
        this.workingDays = workingDays;
        this.salaryPerDay = salaryPerDay;
        this.month = month;
        this.date = date;
        this.netSalary = netSalary;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getJobRole() {
        return jobRole;
    }

    public void setJobRole(String jobRole) {
        this.jobRole = jobRole;
    }

    public int getWorkingDays() {
        return workingDays;
    }

    public void setWorkingDays(int workingDays) {
        this.workingDays = workingDays;
    }

    public double getSalaryPerDay() {
        return salaryPerDay;
    }

    public void setSalaryPerDay(double salaryPerDay) {
        this.salaryPerDay = salaryPerDay;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public double getNetSalary() {
        return netSalary;
    }

    public void setNetSalary(double netSalary) {
        this.netSalary = netSalary;
    }
}
