package view.TM;

public class EvaluationMarkTM {
    private String studentId;
    private String studentName;
    private int grade;
    private String subName;
    private String month;
    private int mark;
    private String date;
    private String teacherName;

    public EvaluationMarkTM() {
    }

    public EvaluationMarkTM(String studentId, String studentName, int grade, String subName, String month, int mark, String date,String teacherName) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.grade = grade;
        this.subName = subName;
        this.month = month;
        this.mark = mark;
        this.date=date;
        this.teacherName=teacherName;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public String getSubName() {
        return subName;
    }

    public void setSubName(String subName) {
        this.subName = subName;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public int getMark() {
        return mark;
    }

    public void setMark(int mark) {
        this.mark = mark;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }
}
