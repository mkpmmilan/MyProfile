package view.TM;

public class ExpenseTM {
    private String date;
    private String description;
    private double cash;

    public ExpenseTM() {
    }

    public ExpenseTM(String date, String description, double cash) {
        this.date = date;
        this.description = description;
        this.cash = cash;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getCash() {
        return cash;
    }

    public void setCash(double cash) {
        this.cash = cash;
    }
}
