package view.TM;

public class PaymentTM {
    private String studentId;
    private String studentName;
    private int grade;
    private String cardNo;
    private String subject;
    private String month;
    private double cash;
    private String date;
    private String teacher;

    public PaymentTM() {
    }

    public PaymentTM(String studentId, String studentName, int grade, String cardNo, String subject, String month, double cash, String date,String teacher) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.grade = grade;
        this.cardNo = cardNo;
        this.subject = subject;
        this.month = month;
        this.cash = cash;
        this.date = date;
        this.teacher=teacher;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public double getCash() {
        return cash;
    }

    public void setCash(double cash) {
        this.cash = cash;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTeacher() {
        return teacher;
    }

    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }
}
