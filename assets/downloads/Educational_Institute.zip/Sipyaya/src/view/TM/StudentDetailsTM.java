package view.TM;

public class StudentDetailsTM {
    private String studentId;
    private String studentName;
    private String teacherName;
    private String subject;
    private int grade;

    public StudentDetailsTM() {
    }

    public StudentDetailsTM(String studentId, String studentName, String teacherName, String subject, int grade) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.teacherName = teacherName;
        this.subject = subject;
        this.grade = grade;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }
}
