package view.TM;

public class StudentTM {
    private String studentId;
    private String studentName;
    private String address;
    private String guardianContact;
    private int grade;
    private String subjectName;
    private String teacherName;

    public StudentTM() {
    }

    public StudentTM(String studentId, String studentName, String address, String guardianContact, int grade, String subjectName, String teacherName) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.address = address;
        this.guardianContact = guardianContact;
        this.grade = grade;
        this.subjectName = subjectName;
        this.teacherName = teacherName;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getGuardianContact() {
        return guardianContact;
    }

    public void setGuardianContact(String guardianContact) {
        this.guardianContact = guardianContact;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }
}
