package view.TM;

public class TeacherSalaryTM {
    private String teacherName;
    private String date;
    private String month;
    private double totalClassFees;
    private double netSalary;

    public TeacherSalaryTM() {
    }

    public TeacherSalaryTM(String teacherName, String date, String month, double totalClassFees, double netSalary) {
        this.teacherName = teacherName;
        this.date = date;
        this.month = month;
        this.totalClassFees = totalClassFees;
        this.netSalary = netSalary;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public double getTotalClassFees() {
        return totalClassFees;
    }

    public void setTotalClassFees(double totalClassFees) {
        this.totalClassFees = totalClassFees;
    }

    public double getNetSalary() {
        return netSalary;
    }

    public void setNetSalary(double netSalary) {
        this.netSalary = netSalary;
    }
}
