package view.TM;

public class TeacherTM {
    private String teacherId;
    private String teacherName;
    private String teacherAddress;
    private String teacherContact;
    private String teacherEmail;
    private String subject;
    private double classFees;

    public TeacherTM() {
    }

    public TeacherTM(String teacherId, String teacherName, String teacherAddress, String teacherContact, String teacherEmail, String subject, double classFees) {
        this.teacherId = teacherId;
        this.teacherName = teacherName;
        this.teacherAddress = teacherAddress;
        this.teacherContact = teacherContact;
        this.teacherEmail = teacherEmail;
        this.subject = subject;
        this.classFees=classFees;
    }

    public String getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(String teacherId) {
        this.teacherId = teacherId;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public String getTeacherAddress() {
        return teacherAddress;
    }

    public void setTeacherAddress(String teacherAddress) {
        this.teacherAddress = teacherAddress;
    }

    public String getTeacherContact() {
        return teacherContact;
    }

    public void setTeacherContact(String teacherContact) {
        this.teacherContact = teacherContact;
    }

    public String getTeacherEmail() {
        return teacherEmail;
    }

    public void setTeacherEmail(String teacherEmail) {
        this.teacherEmail = teacherEmail;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public double getClassFees() {
        return classFees;
    }

    public void setClassFees(double classFees) {
        this.classFees = classFees;
    }
}
